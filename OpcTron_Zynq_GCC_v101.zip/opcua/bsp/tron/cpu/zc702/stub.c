#include "kernel.h"
#include "nosio.h"

int _write(int handle, const unsigned char *buf, int bufSize)
{
    int nChars = 0;

    /* Check for the command to flush all handles */
    if (handle == -1)
        return 0;

    /* Check for stdout and stderr
       (only necessary if FILE descriptors are enabled.) */
    if (handle != 1 && handle != 2)
        return -1;

    for (; bufSize > 0; --bufSize) {
        put_sio(0, *buf, TMO_FEVR); /* output to serial port */
        ++buf;
        ++nChars;
    }
    return nChars;
}

