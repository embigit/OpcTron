/* iTRON RTOS Kernel, TCP/IP Stack and System Shell Initialization
 *
 *  Copyright (c) 2021, TRONKit
 *  All rights reserved.
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "kernel.h"
#include "nonet.h"
#include "nosio.h"
#include "nonitod.h"
#include "nondhcp.h"
#include "nonteln.h"
#include "noncons.h"
#include "trnsock.h"

/* Sample Program Configuration */

#define CH_CONS     0   /* serial channel number for console */

#ifndef NFTP
#define NFTP        1   /* number of clients supported by FTP server */
#endif                  /* (NFTP >= 2 is allowed only for nofftpd.c) */

#define NTP_SRV_MAX 2   /* number of NTP server (0:unused) */
#if (NTP_SRV_MAX != 0)
#include "nonsntp.h"
#include "sntptime.h"
#include "sntpcfg.h"
const char *const sntp_srv[] = { "ntp.nict.jp", "ntp.ring.gr.jp" };
const char dns_srv[]   = "192.168.0.1"; /* when DHCP is invalid */
#endif

/* External Functions */

extern int ping_command(int, char **);
extern ER dns_resolver_byname(ID, UW, const char *, T_IPEP *, const char *);
extern int client_main(int argc, char *argv[]);
extern int server_main();

/* Control Block Structures */

T_TELNETD telnetd;      /* Telnet daemon control block */
T_CONSOLE console;      /* console control block */

/* Task Creation Information */

TASK MainTask(void);
const T_CTSK cMainTask = { TA_HLNG, NULL, (FP)MainTask, 7, 1024, NULL };

/* Local Variable */

BOOL sntp_ini;                      /* SNTP client initialized flag */

/*****************************************************************************
* Telnet Password Check
*
******************************************************************************/

const char *telnet_passwd_check(T_TELNETD *t, const char *name, const char *passwd)
{
    return ">";
}

/*****************************************************************************
* Display Error Message
*
******************************************************************************/

void print_errmsg(const char *msg, ER ercd)
{
    char s[7];

    itod(s, (short)ercd, 0);
    print(msg);
    print(" ("); print(s); print(")\r\n");
}

/*****************************************************************************
* Display IP Configuration
*
******************************************************************************/

static void print_ip(UB *ipaddr)
{
    char s[10];
    int i;

    for (i = 0; ; i++) {
        itou(s, (UH)ipaddr[i], itoulen((UH)ipaddr[i]));
        print(s);
        if (i >= 3)
            break;
        print(".");
    }
}

static void print_mac(UB *macaddr)
{
    char s[10];
    int i;

    for (i = 0; ; i++) {
        ito0X(s, (UH)macaddr[i], 2);
        print(s);
        if (i >= 5)
            break;
        print("-");
    }
}

void disp_param(int argc, char *argv[])
{
    T_NIF *nif;

    if (argc <= 1) {
        nif = getnif_default();
        if (nif == NULL) {
            print("Default network interface does not exist.\r\n");
            return;
        }
        do {
            print(nif->name); print(":\t""IP Address = ");
            print_ip(nif->ipaddr); print("\r\n");
        } while ((nif = nif->next) != NULL);

    } else {
        nif = getnif_from_name(argv[1]);
        if (nif == NULL) {
            print("No interface available.\r\n");
            return;
        }
        print(      "Ethernet Address   = "); print_mac(nif->hwaddr);
        print("\r\n""Default IP Address = "); print_ip(nif->ipaddr);
        print("\r\n""Subnet Mask        = "); print_ip(nif->mask);
        print("\r\n""Default Gateway    = "); print_ip(nif->gateway);
        print("\r\n""DHCP Server        = "); print_ip(nif->dhcp_ipaddr);
        print("\r\n""DNS Server         = "); print_ip(nif->dns_ipaddr);
        print("\r\n");
    }
}

/*****************************************************************************
* Display Local Date & Time
*
******************************************************************************/

void print_date(void)
{
    time_t t;
    tm_t *tm;

    time(&t);
    tm = (tm_t *)localtime(&t);
    print(asctime(tm));
}

/*****************************************************************************
* DHCP Client Test
*
******************************************************************************/

ER dhcp_bynif(T_NIF *nif)
{
    if (byte4_to_long(nif->dhcp_ipaddr) != 0)
        return dhcp_reb_byname(0, nif->name);
    else
        return dhcp_get_byname(0, nif->name);
}

void dhcp_command(void)
{
    T_NIF *nif;
    ER ercd;
    char *argv[2];

    for (nif = getnif_default(); nif != NULL; nif = nif->next) {
        if (nif->type == NI_ETH) {
            ercd = dhcp_bynif(nif);
            if (ercd != E_OK) {
                print_errmsg("\r\nCould not obtain IP address from DHCP server.", ercd);
            } else {
                print("\r\nSuccessfully assigned by DHCP server (");
                print(nif->name); print(")\r\n");
                argv[1] = nif->name;
                disp_param(2, argv);
            }
        }
    }
}

/*****************************************************************************
* DNS Client Test
*
******************************************************************************/

static const char msg_dns_help[] =
    "Usage: dns domain [-i nif] [dnsip]\r\n"
    "\tdomain - Domain name to be searched\r\n"
    "\tnif    - Network interface name (e.g. eth0, eth1)\r\n"
    "\tdnsip  - IP address of DNS server (e.g. 192.168.1.1)\r\n";

void dns_command(int argc, char *argv[])
{
    T_IPEP ipep;
    T_NIF *nif;
    char *domain;
    UW dnsip;
    ER ercd;
    int i;

    nif = NULL;
    domain = NULL;
    dnsip = 0;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-i") == 0) {
            if (nif != NULL) {
                print("Duplicate -i option.\r\n");
            } else {
                if ((++i < argc) && (nif = getnif_from_name(argv[i])) != NULL)
                    continue;
                print("Invalid interface name.\r\n");
            }
        } else if (argv[i][0] == '-') {
            print("Invalid option.\r\n");
        } else if (domain == NULL) {
            domain = argv[i];
            continue;
        } else if (dnsip == 0) {
            if ((dnsip = ascii_to_ipaddr(argv[i])) != 0)
                continue;
            else
                print("Invalid DNS server address.\r\n");
        } else {
            print("Too many parameters.\r\n");
        }
        return;
    }
    if (domain == NULL) {
        print(msg_dns_help);
        return;
    }
    if (nif == NULL) {
        if (dnsip == 0)
            nif = getnif_default();
        else
            nif = getnif_dstaddr(dnsip);
        if (nif == NULL) {
            print("Default network interface does not exist.\r\n");
            return;
        }
    }
    if (dnsip == 0) {
        if ((dnsip = byte4_to_long(nif->dns_ipaddr)) == 0) {
            print("DNS server is not defined for this interface.\r\n");
            return;
        }
    }

    ercd = dns_resolver_byname(0, dnsip, domain, &ipep, nif->name);
    if (ercd != E_OK) {
        print_errmsg("DNS server or domain name not found.", ercd);
        return;
    }

    print(domain);
    print(" has address ");
    long_to_byte4((UB *)&ipep.ipaddr, ipep.ipaddr);
    print_ip((UB *)&ipep.ipaddr);
    print("\r\n");
}

/*****************************************************************************
* SNTP Client Test
*
******************************************************************************/

void sntp_command(int argc, char *argv[])
{
  #if (NTP_SRV_MAX == 0)
    print("Time server is not defined.\r\n");
  #else
    UW dnsip;
    ER ercd;

    /* initialize SNTP client at first */
    if (!sntp_ini) {
        dnsip = byte4_to_long(getnif_default()->dns_ipaddr);
        if (dnsip == 0)
            dnsip = ascii_to_ipaddr(dns_srv);
        ercd = sntp_start(sntp_srv, dnsip, 1000/MSEC);
        if (ercd < 0) {
            print_errmsg("Time server is not available.", ercd);
            return;
        }
        set_timezone_ofst(DEFAULT_TZ);
        sntp_ini = TRUE;
    }

    /* execute SNTP synchronization */
    ercd = sntp_get_tim(NULL);
    if (ercd < 0)
        print_errmsg("Could not load time from time server.", ercd);
    else
        print_date();
  #endif
}

/*****************************************************************************
* OPC Client Test
*
******************************************************************************/

void client_command(int argc, char *argv[])
{
    if (argc < 2) {
        print("Usage: client opc.tcp://<IP Address>:<Port Number>\r\n");
        return;
    }
    client_main(argc, argv);
}

/*****************************************************************************
* Telnet Command Processing Routine
*
******************************************************************************/

BOOL telnetd_callback(T_TERMINAL *t, char *s)
{
    char *argv[16];
    int argc;

    for (argc = 0; argc < sizeof argv / sizeof (char *);) {
        while (*s == ' ')
            s++;
        if (*s == '\0')
            break;
        argv[argc++] = s;
        s = strchr(s, ' ');
        if (s == NULL)
            break;
        *s++ = '\0';
    }
    if (argc == 0)
        return TRUE;

    if (stricmp(argv[0], "?") == 0 || stricmp(argv[0], "help") == 0)
        print("ip     - display IP configuration\r\n"
              "ping   - ping command\r\n"
              "dhcp   - DHCP client test\r\n"
              "dns    - DNS client test\r\n"
              "sntp   - SNTP client test\r\n"
              "client - OPC client test\r\n"
              "server - OPC server test\r\n"
              "help   - display help message\r\n");
    else if (stricmp(argv[0], "ip") == 0)
        disp_param(argc, argv);
    else if (stricmp(argv[0], "ping") == 0)
        ping_command(argc, argv);
    else if (stricmp(argv[0], "dhcp") == 0)
        dhcp_command();
    else if (stricmp(argv[0], "dns") == 0)
        dns_command(argc, argv);
    else if (stricmp(argv[0], "sntp") == 0)
        sntp_command(argc, argv);
    else if (stricmp(argv[0], "client") == 0)
        client_command(argc, argv);
    else if (stricmp(argv[0], "server") == 0)
        server_main();
    else if (stricmp(argv[0], "date") == 0)
        print_date();
    else
        print("Unknown or unsupported command.\r\n");
    return TRUE;
}

/*****************************************************************************
* Main Task
*
******************************************************************************/

TASK MainTask(void)
{
    /* clear local variable */
    sntp_ini = FALSE;

    /* serial console initialization */
    if (console_ini(&console, 0, 0, CH_CONS, "38400 B8 PN S1") != E_OK)
        goto END;
    console_print(&console, "\r\n*** OPC UA Sample Program ***");

    /* protocol stack initialization */
    if (tcp_ini() < 0)
        goto END;

    /* socket wrapper initialization */
    if (sock_ini() < 0)
        goto END;

    /* get IP address from DHCP server */
  #ifdef DHCP
    dhcp_bynif(getnif_default());
  #endif

    /* Telnet daemon initialization */
    if (telnetd_ini(&telnetd, 0, 0, 0, 0) != E_OK)
        goto END;

    /* shell initialization */
    if (shell_ini(&console, 0, 0, telnet_passwd_check) != E_OK)
        goto END;
    if (shell_ini(&telnetd, 0, 0, telnet_passwd_check) != E_OK)
        goto END;

END:
    slp_tsk();
}

/*****************************************************************************
* Main Function
*
******************************************************************************/

int main(void)
{
    ID id;

    /* initialize system */
    sysini();

    /* create application task */
    id = acre_tsk(&cMainTask);

    /* start task */
    sta_tsk(id, 0);

    /* start system */
    intsta();                   /* start interval timer interrupt */
    return syssta();            /* enter into multitasking */
}

/* end */
