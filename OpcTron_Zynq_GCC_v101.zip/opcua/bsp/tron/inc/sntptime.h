/******************************************************************************
* Time Functions Header                                                       *
******************************************************************************/

#ifndef SNTPTIME_H
#define SNTPTIME_H
#ifdef __cplusplus
extern "C" {
#endif

#if !(defined(_TIME_T) || defined(__time_t_defined))
typedef W time_t;
#define _TIME_T
#endif
#define my_time_t time_t
typedef long my_clock_t;

#define HOUR_SEC    3600L       /* seconds in an hour (60*60) */
#define DAY_SEC     86400L      /* seconds in a day (60*60*24) */
#define DEFAULT_TZ  32400L      /* time zone compensation in Japan (+9*60*60) */
#define MINUS_UTC   -43200L     /* maximum negative time difference (-12*3600) */
#define PLUS_UTC    50400L      /* maximum positive time difference (+14*3600) */
#define DAYS_1970   719528L     /* days from 1970-01-01 + 1 */

#define SEC_1YEAR   31536000L   /* 365 * 24 * 60 * 60 */
#define SEC_2YEAR   63072000L   /* SEC_1YEAR * 2 */
#define SEC_3YEAR   94694400L   /* SEC_2YEAR + 366 * 24 * 60 * 60 */
#define SEC_4YEAR   126230400L  /* SEC_3YEAR + SEC_1YEAR */

#define IS_LEAPY(y)  ((y) % 4 == 0 && ((y) % 100 != 0 || (y) % 400 == 0))  /* �[�N�̃`�F�b�N */

typedef struct my_tm
{
    int tm_sec;                 /* seconds (0~61) */
    int tm_min;                 /* minutes (0~59) */
    int tm_hour;                /* hour (0~23) */
    int tm_mday;                /* day of month (1~31) */
    int tm_mon;                 /* month of year (0~11, Jan = 0) */
    int tm_year;                /* years since 1900 */
    int tm_wday;                /* day of week (0~6, Sunday = 0) */
    int tm_yday;                /* day of year (0~365, Jan 1 = 0) */
    int tm_isdst;               /* daylight savings flg */
} my_tm_t;

char *my_asctime(const my_tm_t *tms);
char *my_asctime_r(const my_tm_t *tms, char *buf);
char *my_ctime(const time_t *timer);
char *my_ctime_r(const time_t *timer, char *buf);
time_t my_time(time_t *t);
time_t my_mktime (my_tm_t *t);
my_clock_t my_clock(void);
my_tm_t *my_gmtime(const time_t *tms);
my_tm_t *my_gmtime_r(const time_t *tms, my_tm_t *tm_time);
my_tm_t *my_localtime(const time_t *tms);
my_tm_t *my_localtime_r(const time_t *tms, my_tm_t *tm_time);
ER set_timezone_ofst(W tz);
W get_timezone_ofst(void);

#ifndef SNTPTIME_C
#define clock_t              my_clock_t
#define tm_t                 my_tm_t
#define asctime(a)           my_asctime(a)
#define asctime_r(a, b)      my_asctime_r(a, b)
#define ctime(a)             my_ctime(a)
#define ctime_r(a, b)        my_ctime_r(a, b)
#define time(a)              my_time(a)
#define mktime(a)            my_mktime(a)
#define clock()              my_clock()
#define gmtime(a)            my_gmtime(a)
#define gmtime_r(a, b)       my_gmtime_r(a, b)
#define localtime(a)         my_localtime(a)
#define localtime_r(a, b)    my_localtime_r(a, b)
#endif

#ifdef __cplusplus
}
#endif
#endif /* SNTPTIME_H */
