/******************************************************************************
* SNTP Client Configuration Header                                            *
******************************************************************************/

#ifndef SNTPCFG_H
#define SNTPCFG_H
#ifdef __cplusplus
extern "C" {
#endif

typedef struct t_sntp_cfg {
    UW srv_max;
    UW sntp_tmout;
} T_SNTP_CFG;

#ifndef INCLUDED_FROM_SNTP

#ifndef NTP_SRV_MAX
#define NTP_SRV_MAX       1         /* the number of NTP servers to query */
#endif
#ifndef SNTP_TMOUT
#define SNTP_TMOUT        1000      /* SNTP timeout */
#endif

T_IPV4EP host[NTP_SRV_MAX];         /* NTP server information */
const T_SNTP_CFG SNTP_CFG = { NTP_SRV_MAX, SNTP_TMOUT };

#else

extern T_IPV4EP host[];
extern const T_SNTP_CFG SNTP_CFG;
#define NTP_SRV_MAX (int)SNTP_CFG.srv_max
#define SNTP_TMOUT  SNTP_CFG.sntp_tmout

#endif

#ifdef __cplusplus
}
#endif
#endif /* SNTPCFG_H */
