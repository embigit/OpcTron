/******************************************************************************
* Kernel Configuration Header                                                 *
******************************************************************************/

#ifndef NOCFG4_H
#define NOCFG4_H

#ifdef __cplusplus
extern "C" {
#endif

/* Including CPU-dependent header file */

#define OS_CONFIG
#include "nosys4.h"

#ifndef NULL
#define NULL    ((void *)0)
#endif

/* Constants for Configuration */

#ifndef TSKID_MAX
#define TSKID_MAX   8               /* 1 ~ 250 */
#endif
#ifndef SEMID_MAX
#define SEMID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef FLGID_MAX
#define FLGID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MBXID_MAX
#define MBXID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MBFID_MAX
#define MBFID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef PORID_MAX
#define PORID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MPLID_MAX
#define MPLID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MPFID_MAX
#define MPFID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef DTQID_MAX
#define DTQID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MTXID_MAX
#define MTXID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef ISRID_MAX
#define ISRID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef SVCFN_MAX
#define SVCFN_MAX   8               /* 1 ~ 50 */
#endif
#ifndef CYCNO_MAX
#define CYCNO_MAX   1               /* 1 ~ 250 */
#endif
#ifndef ALMNO_MAX
#define ALMNO_MAX   1               /* 1 ~ 250 */
#endif
#ifndef TPRI_MAX
#define TPRI_MAX    8               /* 1 ~ 31 */
#endif
#ifndef TMRQSZ
#define TMRQSZ      1               /* 1,2,4,8,16,32,64,128,256 */
#endif
#ifndef CYCQSZ
#define CYCQSZ      1               /* 1,2,4,8,16,32,64,128,256 */
#endif
#ifndef ALMQSZ
#define ALMQSZ      1               /* 1,2,4,8,16,32,64,128,256 */
#endif
#ifndef ISTKSZ
#define ISTKSZ      sizeof(T_CTX)*4
#endif
#ifndef TSTKSZ
#define TSTKSZ      sizeof(T_CTX)*4
#endif
#ifndef SYSMSZ
#define SYSMSZ      0               /* 0: use stack area */
#endif
#ifndef MPLMSZ
#define MPLMSZ      0               /* 0: use stack area */
#endif
#ifndef STKMSZ
#define STKMSZ      0               /* 0: use default stack area */
#endif

/* Configuration Information */

const V4_T_RCFG cdecl CFG =
{   TSKID_MAX,
    SEMID_MAX,
    FLGID_MAX,
    MBXID_MAX,
    MBFID_MAX,
    PORID_MAX,
    MPLID_MAX,
    MPFID_MAX,
    CYCNO_MAX,
    ALMNO_MAX,
    TPRI_MAX,
    TMRQSZ,
    CYCQSZ,
    ALMQSZ,
    ISTKSZ,
    TSTKSZ,
    SYSMSZ,
    MPLMSZ,
    STKMSZ,
    DTQID_MAX,
    MTXID_MAX,
    ISRID_MAX,
    SVCFN_MAX
};

const UH mSEC = MSEC;

/* Kernel Internal Data */

T_TCB SNEAR * SNEAR cdecl _pTCB[TSKID_MAX+1];
T_SEM SNEAR * SNEAR cdecl _pSEM[SEMID_MAX];
T_FLG SNEAR * SNEAR cdecl _pFLG[FLGID_MAX];
T_MBX SNEAR * SNEAR cdecl _pMBX[MBXID_MAX];
T_MBF SNEAR * SNEAR cdecl _pMBF[MBFID_MAX];
T_POR SNEAR * SNEAR cdecl _pPOR[PORID_MAX];
T_MPL SNEAR * SNEAR cdecl _pMPL[MPLID_MAX];
T_MPF SNEAR * SNEAR cdecl _pMPF[MPFID_MAX];
T_CYC SNEAR * SNEAR cdecl _pCYC[CYCNO_MAX];
T_ALM SNEAR * SNEAR cdecl _pALM[ALMNO_MAX];
T_DTQ SNEAR * SNEAR cdecl _pDTQ[DTQID_MAX];
T_MTX SNEAR * SNEAR cdecl _pMTX[MTXID_MAX];
T_ISR SNEAR * SNEAR cdecl _pISR[ISRID_MAX];
T_SVC SNEAR * SNEAR cdecl _pSVC[SVCFN_MAX];
FP SNEAR _kernel_dcall;
ID SNEAR _kernel_mbxfr;
RDVNO SNEAR _kernel_rdv_seqno;
T_ISR_ST SNEAR _kernel_ovrisr;
T_OVR SNEAR _kernel_ovr;
SYSTIME SNEAR cdecl _kernel_clk;
SYSTIME SNEAR cdecl SYSCK;
UW SNEAR cdecl IDLCNT;
T_SYSTCB SNEAR cdecl SYSTCB;
ER SNEAR cdecl SYSER;
volatile TSK_PRI SNEAR cdecl NOWPRI;
volatile B SNEAR cdecl DELAY;
volatile B SNEAR cdecl INEST;
volatile B SNEAR cdecl DDISP;
volatile TSK_ID SNEAR cdecl SDISP;
volatile B SNEAR cdecl TMREQ;
volatile TSK_ID SNEAR cdecl PREVTSK;
volatile TSK_PRI SNEAR cdecl APLPRI;
UB SNEAR cdecl TMQMS;
UB SNEAR cdecl CHQMS;
UB SNEAR cdecl AHQMS;
UINT SNEAR cdecl CTXPTN;
VP SNEAR cdecl CTXPTR;
UINT SNEAR cdecl WID;
T_NMEM SNEAR * SNEAR cdecl SYSTOP;
T_MEM PFAR * SNEAR cdecl MPLTOP;
T_MEM SFAR * SNEAR cdecl STKTOP;
TSK_ID SNEAR cdecl RDQ[TPRI_MAX+2];
TSK_ID SNEAR cdecl TMQ[TMRQSZ];
UB SNEAR cdecl CHQ[CYCQSZ];
UB SNEAR cdecl AHQ[ALMQSZ];
const char _KERNEL_NNM = 0;

#if ((SYSMSZ)/SIZEOF_INT!=0)
int SNEAR cdecl SYSMEM[(SYSMSZ)/SIZEOF_INT];
int SNEAR * const cdecl pSYSMEM = (int SNEAR * cdecl)SYSMEM;
#else
int SNEAR * const cdecl pSYSMEM = (int SNEAR * cdecl)NULL;
#endif

#if ((MPLMSZ)/SIZEOF_INT!=0)
int PFAR * const cdecl pMPLMEM = (int PFAR * cdecl)MPLMEM;
#else
int PFAR * const cdecl pMPLMEM = (int PFAR * cdecl)NULL;
#endif

#if ((STKMSZ)/SIZEOF_INT!=0)
int SFAR * const cdecl pSTKMEM = (int SFAR * cdecl)STKMEM;
#else
int SFAR * const cdecl pSTKMEM = (int SFAR * cdecl)NULL;
#endif

#undef OS_CONFIG
#ifdef __cplusplus
}
#endif
#endif  /* NOCFG4_H */
