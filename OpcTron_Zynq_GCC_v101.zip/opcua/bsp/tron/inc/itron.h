/******************************************************************************
* ITRON Common Definition and Declaration                                     *
******************************************************************************/

#ifndef ITRON_H
#define ITRON_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef NULL
#ifdef __cplusplus
#define NULL    (0)
#else
#define NULL    ((void *)0)
#endif
#endif

/************************************/
/* Processors Identification        */
/************************************/

#if defined(M_I86)                  /* MS-C */
 #define CPU_86
#elif defined(__TURBOC__)           /* TURBO-C, BORLAND-C */
 #define CPU_86
 #if defined(__HUGE__)
  #error Unsupported Model!
 #endif
#elif defined(LSI_C80)              /* LSIC-80 */
 #define CPU_Z80
#elif defined(__IAR_SYSTEMS_ICC__)  /* IAR compiler */
 #if defined(__ICCARM__)
  #if ((__CORE__==__ARM7M__)||(__CORE__==__ARM7EM__))
   #define CPU_ARM7M                /* Cortex-M3/M4 */
  #elif (__CPU_MODE__==1)
   #define CPU_THUMB
  #elif (__CPU_MODE__==2)
   #define CPU_ARM
  #else
   #error Not supported ARM!
  #endif
  #if (__CORE__==__ARM7R__)
   #define CPU_VIC                  /* Cortex-R4 has vectored interrupt controller */
  #endif
  #if (defined(__ARMVFP__)||defined(__ARM_ADVANCED_SIMD__))
   #if (((__ARMVFP__!=__ARMVFPV2__)&&!defined(__ARMVFP_D16__))||defined(__ARM_ADVANCED_SIMD__))
    #define ARM_VFP 32
   #else
    #define ARM_VFP 16
   #endif
  #endif
  #if defined(__ARM_ADVANCED_SIMD__)
   #define ARM_NEON
  #endif
  #if ((__CORE__==__ARM6__)||(__CORE__==__ARM7A__)||(__CORE__==__ARM7R__)||defined(CPU_ARM7M))
   #if (!defined(SIZEOF_ALIGN))
    #define SIZEOF_ALIGN 8
   #endif
  #endif
 #elif defined(__ICCAVR32__)
  #if (__CORE__ == __AVR32A__)
   #define CPU_AVR32A
  #else
   #error Only AVR32A core supported
  #endif
 #elif defined(__TID__)
  #if (__VER__>=122)                /* new IAR compiler */
   #define C_task
   #if ((__TID__&0x7f00)==0x0a00)
    #define CPU_H83                 /* H8/300H large */
   #elif ((__TID__&0x7f00)==0x0900) /* H8/500 */
    #define CPU_H85
    #if ((__TID__&0xff)==0x00)      /* H8/500 minimum */
     #define H85_MINIMUM
    #endif
   #elif (((__TID__&0xff)==0x11)||((__TID__&0xff)==0x21))
    #if ((__TID__&0xff)==0x21)
     #define H8S2600
    #endif
    #define CPU_H8S                 /* H8S large */
    #ifndef INTM
     #define INTM    2
    #endif
   #elif ((__TID__&0xff)==0x01)
    #define CPU_H83                 /* H8/300H large */
    #ifndef INTM
     #define INTM    1
    #endif
   #else
    #error Unsupported CPU!
   #endif
  #elif (__VER__>=111)              /* new IAR compiler for SH */
   #define C_task
   #if (__TID__==0x4600)            /* SH */
    #define CPU_SH
   #elif (__TID__==0x4610)
    #define CPU_SH
   #elif (__TID__==0x4620)
    #define CPU_SH
    #ifndef SH3
     #define SH3
    #endif
   #elif (__TID__==0x4630)
    #define CPU_SH
    #define DSP
   #elif (__TID__==0x4640)
    #define CPU_SH
    #ifndef SH3
     #define SH3
    #endif
    #define DSP
   #else
    #error Unsupported CPU!
   #endif
  #else                             /* old IAR compiler */
   #if ((__TID__&0x7f00)==0x0a00)   /* H8/300H */
    #define CPU_H83
    #define OLD_ICC_H83
   #elif ((__TID__&0x7f00)==0x1700) /* Z80 */
    #define CPU_Z80
   #else
    #error Unsupported CPU!
   #endif
  #endif
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__DCC__)              /* Diab C */
 #if defined(m68k)                  /* 68K */
  #define CPU_68K
 #elif defined(__ppc)               /* PowerPC */
  #define CPU_PPC
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__HITACHI__)          /* Renesas new version */
 #if (defined(_SH1)||defined(_SH2)||defined(_SH2DSP))
  #define CPU_SH
 #elif defined(_SH2E)
  #ifndef SH2E
   #define SH2E
  #endif
  #define CPU_SH
 #elif defined(_SH2A)
  #ifndef SH2A
   #define SH2A
  #endif
  #define CPU_SH
 #elif defined(_SH2AFPU)
  #ifndef SH2AFPU
   #define SH2AFPU
  #endif
  #define CPU_SH
 #elif (defined(_SH3)||defined(_SH3DSP))
  #ifndef SH3
   #define SH3
  #endif
  #define CPU_SH
 #elif defined(_SH3E)
  #ifndef SH3E
   #define SH3E
  #endif
  #define CPU_SH
 #elif (defined(_SH4)||defined(_SH4A)||defined(_SH4ALDSP))
  #ifndef SH4
   #define SH4
  #endif
  #define CPU_SH
 #elif defined(__300HA__)
  #define CPU_H83
  #ifndef INTM
   #define INTM    1
  #endif
 #elif (defined(__2000A__)||defined(__2600A__))
  #if defined(__2600A__)
   #define H8S2600
  #endif
  #define CPU_H8S
  #ifndef INTM
   #define INTM    2
  #endif
 #elif defined(__H8SXA__)
  #define CPU_H8SX
  #ifndef INTM
   #define INTM    2
  #endif
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__RENESAS__)
 #if defined(__RX)
  #define CPU_RX                    /* CC-RX RXv1/RXv2 */
 #else
  #error Unsupported CPU!
 #endif
#elif defined(_MICROTEC)
 #if (defined(_MCCPPC)||defined(_CCCPPC))
  #define CPU_PPC
 #elif defined(_MCC68K)             /* MCC68K */
  #define CPU_68K
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__TMS470__)           /* CCS (TI ARM compiler) */
 #if defined(__TI_TMS470_V7M3__)    /* Cortex-M3 */
  #define CPU_ARM7M
 #elif defined(__16bis__)           /* Thumb mode */
  #define CPU_THUMB
 #elif defined(__32bis__)           /* ARM mode */
  #define CPU_ARM
 #else
  #error Unsupported CPU!
 #endif
 #if defined(__TI_TMS470_V7R4__)
  #define CPU_VIC                   /* Cortex-R4 has vectored interrupt controller */
 #endif
 #if (defined(__TI_VFP_SUPPORT__)||defined(__TI_NEON_SUPPORT__))
  #if (defined(__TI_VFPV3_SUPPORT__)||defined(__TI_NEON_SUPPORT__))
   #define ARM_VFP 32
  #else
   #define ARM_VFP 16
  #endif
 #endif
 #if defined(__TI_NEON_SUPPORT__)
  #define ARM_NEON
 #endif
 #define SIZEOF_ALIGN 8
#elif defined(__GNUC__)             /* exeGCC, nios-gcc, GNU ARM */
 #if defined(__sh__)                /* SH */
  #define CPU_SH
  #if defined(_SH_)
   #if (_SH_==3)
    #ifndef SH3
     #define SH3
    #endif
   #elif (_SH_==4)
    #ifndef SH4
     #define SH4
    #endif
   #endif
  #endif
 #elif defined(__nios__)            /* Altera Nios */
  #define CPU_NIOS
  #if defined(__nios16__)
   #define CPU_NIOS16
  #elif defined(__nios32__)
   #define CPU_NIOS32
  #else
   #error Unsupported CPU!
  #endif
 #elif defined(__nios2__)           /* Altera Nios II */
  #define CPU_NIOS2
 #elif defined(__MICROBLAZE__)      /* Xilinx MicroBlaze */
  #define CPU_MB
 #elif defined(__PPC__)             /* PowerPC */
  #if !defined(CPU_PPC)             /* PowerPC on exeGCC */
   #define CPU_PPC
  #endif
 #elif defined(__arm__)             /* GNU ARM */
  #if defined(__thumb__)
   #define CPU_THUMB
  #else
   #define CPU_ARM
  #endif
  #if defined(__ARM_ARCH_7R__)
   #define CPU_VIC                  /* Cortex-R4 has vectored interrupt controller */
  #endif
  #define SIZEOF_ALIGN 8
  #if (defined(__VFP_FP__) && !defined(__SOFTFP__))
   #if defined(__ARM_NEON__)
    #define ARM_VFP 32
    #define ARM_NEON
   #else
    #define ARM_VFP 16
   #endif
  #endif
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__ghs)
 #if defined(__SH7000)              /* Green Hills C-SH */
  #define CPU_SH
  #if defined(__SH_3)
   #ifndef SH3
    #define SH3
   #endif
  #elif defined(__SH_2A)
   #ifndef SH2A
    #define SH2A
   #endif
   #if defined(SH2AFPU)
    #undef SH2A
   #endif
  #elif (defined(__SH_4)||defined(__SH_4A))
   #ifndef SH4
    #define SH4
   #endif
  #endif
 #elif (defined(__V850)||defined(__V850E)||defined(__V850E2)||defined(__V850F)) /* Green Hills V850 */
  #define CPU_V850
 #elif (defined(__V810)||defined(__V830)) /* Green Hills V800 */
  #define CPU_V800
 #elif defined(__THUMB)             /* Thumb mode on Green Hills */
  #define CPU_THUMB
  #if (defined(__ARM11))
   #if !defined(SIZEOF_ALIGN)
    #define SIZEOF_ALIGN 8
   #endif
  #endif
 #elif defined(__ARM)               /* ARM mode on Green Hills */
  #define CPU_ARM
  #if (defined(__ARM11))
   #if !defined(SIZEOF_ALIGN)
    #define SIZEOF_ALIGN 8
   #endif
  #endif
 #elif defined(__mips)              /* MIPS */
  #if defined(__mips64)
   #define MIPS64                   /* MIPS 64bit mode  */
  #endif
  #define CPU_R4000                 /* R4xxx 32bit or R3xxx 32bit */
 #elif defined(__FR)                /* Green Hills FR30 */
  #define CPU_FR
 #else
  #error Unsupported CPU!
 #endif
#elif defined(GAIO)                 /* GAIO XASS-V */
 #if defined(SH7000)                /* XASS-V(SH) */
  #define CPU_SH
 #elif defined(ARM)                 /* XASS-V(ARM) */
  #define CPU_ARM
 #elif defined(THUMB)               /* XASS-V(THUMB) */
  #define CPU_THUMB
 #elif defined(H8S_Adva)            /* XASS-V(H8S) */
  #define CPU_H8S
  #ifndef INTM
  #define INTM     2
  #endif
 #elif defined(H8S_Norm)            /* XASS-V(H8S) Normal mode not supported */
  #error Unsupported CPU!
 #elif defined(H8300H)              /* XASS-V(H8/300H) needs manual definition */
  #define CPU_H83
  #ifndef INTM
  #define INTM     1
  #endif
 #elif defined(M16C60)              /* XASS-V(M16C) */
  #define CPU_M16C
  #define LARGE
 #else
  #error Unsupported CPU on GAIO XASS-V!
 #endif
#elif defined(__CC_NORCROFT)        /* Norcroft C */
 #if defined(__thumb)               /* Thumb mode */
  #define CPU_THUMB
 #elif defined(__arm)               /* ARM mode */
  #define CPU_ARM
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__CC_ARM)             /* ARM compiler */
 #if (defined(__TARGET_ARCH_7_M)||defined(__TARGET_ARCH_7E_M)) /* Cortex-M3/M4 */
  #define CPU_ARM7M
 #elif defined(__thumb)             /* Thumb mode */
  #define CPU_THUMB
 #elif defined(__arm)               /* ARM mode */
  #define CPU_ARM
 #else
  #error Unsupported CPU!
 #endif
 #if defined(__TARGET_ARCH_7_R)
  #define CPU_VIC                   /* Cortex-R4 has vectored interrupt controller */
 #endif
 #if defined(__TARGET_FPU_VFP)
  #if (defined(__TARGET_FPU_VFPV3)||defined(__TARGET_FPU_VFPV4))
   #define ARM_VFP 32
  #else
   #define ARM_VFP 16
  #endif
 #endif
 #if defined(__ARM_NEON__)
  #define ARM_NEON
 #endif
 #if (!defined(SIZEOF_ALIGN)&&(__ARMCC_VERSION>=200000))
  #ifndef __APCS_ADSABI
   #define SIZEOF_ALIGN 8
  #endif
 #endif
#elif defined(__MWERKS__)           /* Metrowerks CodeWarrior */
 #if defined(__SH3__)
  #define CPU_SH
 #elif defined(__POWERPC__)
  #define CPU_PPC
 #elif defined(__COLDFIRE__)
  #define CPU_COLDFIRE
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__CPU__)              /* Renesas H8C */
 #ifndef __HITACHI__
  #define __HITACHI__
 #endif
 #if (__CPU__==3)                   /* H8/300H */
  #define CPU_H83
  #ifndef INTM
   #define INTM    1
  #endif
 #elif ((__CPU__==5)||(__CPU__==7)) /* H8S/2000,H8S/2600 */
  #if (__CPU__==5)
   #define H8S2600
  #endif
  #define CPU_H8S
  #ifndef INTM
   #define INTM    2
  #endif
 #else
  #error Unsupported CPU!
 #endif
#elif defined(__MEMORYMODEL__)      /* H8/500 */
 #define CPU_H85
 #if (__MEMORYMODEL__ == 0)         /* H8/500 minimum */
  #define H85_MINIMUM
 #endif
#elif defined(M16C)                 /* Renesas NC30WA */
 #define CPU_M16C
#elif defined(M32C80)               /* Renesas NC308 */
 #define CPU_M32C
 #define CPU_M16C                   /* upper compatible with M16C */
#elif defined(R32C100)              /* Renesas NC100 */
 #define CPU_R32C
 #define CPU_M16C                   /* upper compatible with M16C */
#elif defined(__M32R__)             /* Renesas CC32R */
 #define CPU_M32R
#elif defined(__CPU_FR__)           /* Softune FR */
 #define CPU_FR
#elif defined(__ADSPBLACKFIN__)     /* Analog Devices BlackFin */
 #define CPU_BLKFN
#elif (defined(__v850)&&defined(__v850__)) /* NEC CA850 */
 #define CPU_V850
 #ifndef __CA850__
  #define __CA850__
 #endif
#elif defined(_WIN32)               /* Simulator */
 #define CPU_SIM
 #define LITTLE_ENDIAN
#else                               /* Renesas SHC */
 #ifndef __HITACHI__
  #define __HITACHI__
 #endif
 #ifndef __HITACHI_VERSION__
  #define __HITACHI_VERSION__ 0x0501
 #endif
 #if (defined(_SH1)||defined(_SH2))
  #define CPU_SH
 #elif defined(_SH2E)
  #ifndef SH2E
   #define SH2E
  #endif
  #define CPU_SH
 #elif defined(_SH3)
  #ifndef SH3
   #define SH3
  #endif
  #define CPU_SH
 #elif defined(_SH3E)
  #ifndef SH3E
   #define SH3E
  #endif
  #define CPU_SH
 #elif defined(_SH4)
  #ifndef SH4
   #define SH4
  #endif
  #define CPU_SH
 #else
  #error Unsupported CPU!
 #endif
#endif

/************************************/
/* CPU Dependents                   */
/************************************/

/* Endianness */

#if (!defined(BIG_ENDIAN)&&!defined(LITTLE_ENDIAN))
 #if (defined(CPU_H83)||defined(CPU_H85)||defined(CPU_H8S)||defined(CPU_H8SX)||defined(CPU_PPC)||defined(CPU_AVR32A)||defined(CPU_M32R)||defined(CPU_68K)||defined(CPU_COLDFIRE))
  #define BIG_ENDIAN
 #elif (defined(CPU_M16C)||defined(CPU_NIOS)||defined(CPU_NIOS2)||defined(CPU_BLKFN)||defined(CPU_V850)||defined(CPU_V800)||defined(CPU_FR)||defined(CPU_86)||defined(CPU_Z80)||defined(CPU_78K0))
  #define LITTLE_ENDIAN
 #else /* bi-endian */
  #if defined(__CC_ARM) /* ARM compiler */
   #if defined(__BIG_ENDIAN)
    #define BIG_ENDIAN
   #else
    #define LITTLE_ENDIAN
   #endif
  #elif defined(__IAR_SYSTEMS_ICC__) /* IAR compiler */
   #if __LITTLE_ENDIAN__
    #define LITTLE_ENDIAN
   #else
    #define BIG_ENDIAN
   #endif
  #elif defined(__arm__) /* GNU ARM */
   #if __ARM_BIG_ENDIAN
    #define BIG_ENDIAN
   #else
    #define LITTLE_ENDIAN
   #endif
  #else /* other compilers */
   #if (defined(__BIG_ENDIAN__)||defined(ENDIAN_BIG)||defined(_BIG)||defined(__BIG)||defined(__big_endian__))
    #define BIG_ENDIAN
   #elif (defined(__LITTLE_ENDIAN__)||defined(__LITTLE_ENDIAN)||defined(_LIT)||defined(__LIT)||defined(__little_endian__))
    #define LITTLE_ENDIAN
   #else
    #error Please specify the endianess with BIG_ENDIAN or LITTLE_ENDIAN macro.
   #endif
  #endif
 #endif
#endif

/* Size of Integer and Pointer */

#ifndef SIZEOF_INT
 #if (defined(CPU_Z80)||defined(CPU_78K0))
  #define SIZEOF_INT  1
 #elif defined(CPU_R32C)
  #define SIZEOF_INT  4
 #elif (defined(CPU_86)||defined(CPU_H83)||defined(CPU_H8S)||defined(CPU_H85)||defined(CPU_M16C)||defined(CPU_NIOS16)||defined(CPU_H8SX))
  #define SIZEOF_INT  2
 #else
  #define SIZEOF_INT  4
 #endif
#endif

#if (defined(CPU_Z80)||defined(CPU_78K0))
 #define SIZEOF_PTR  2
#elif (defined(M_I86SM)||defined(M_I86MM)||defined(__SMALL__)||defined(__MEDIUM__)||defined(H85_MINIMUM)||defined(CPU_NIOS16))
 #define SIZEOF_PTR  2
#elif defined(CPU_M16C)
 #if (defined(LARGE)||defined(CPU_R32C)||defined(CPU_M32C))
  #define SIZEOF_PTR  4
 #else
  #define SIZEOF_PTR  2
 #endif
#else
 #define SIZEOF_PTR  4
#endif

/* Alignment Size for Memory Management */

#ifndef SIZEOF_ALIGN
 #if ((SIZEOF_INT<=2)&&(SIZEOF_PTR<=2))
  #define SIZEOF_ALIGN 2
 #else
  #define SIZEOF_ALIGN 4
 #endif
#endif

#if (SIZEOF_ALIGN >= (SIZEOF_PTR*2))
 #define MINIMUM_BLK 0
#else
 #define MINIMUM_BLK 1
#endif

/* 8086 & M16C Key Words */

#if defined(CPU_86)
 #define FFAR       far
 #define SFAR       far
 #define DFAR       far
 #define PFAR
 #define FNEAR      near
 #define SNEAR      near
 #define NEAR       near
 #define cdecl
 #define pascal
 #define SIZEOF_NALIGN 2
#elif defined(CPU_M16C)
 #define FFAR
 #define DFAR       far
 #ifdef CPU_R32C
  #define SFAR
 #else
  #define SFAR      near
 #endif
 #if (defined(LARGE)||defined(CPU_M32C))
  #define PFAR      far
 #else
  #define PFAR
 #endif
 #define FNEAR
 #define SNEAR      near
 #define NEAR       near
 #define cdecl
 #define pascal
 #ifdef CPU_R32C
  #define SIZEOF_NALIGN 4
 #else
  #define SIZEOF_NALIGN 2
 #endif
#else
 #define FFAR
 #define SFAR
 #define DFAR
 #define PFAR
 #define FNEAR
 #define SNEAR
 #define NEAR
 #define cdecl
 #define pascal
 #define SIZEOF_NALIGN SIZEOF_ALIGN
#endif

/************************************/
/* Data Types                       */
/************************************/

/* General-purpose Data Types */

typedef signed char B;      /* signed 8-bit integer */
typedef long W;             /* signed 32-bit integer */
typedef unsigned char UB;   /* unsigned 8-bit integer */
typedef unsigned long UW;   /* unsigned 32-bit integer */
typedef char VB;            /* unpredictable data type (8-bit size) */
typedef long VW;            /* unpredictable data type (32-bit size) */
typedef void PFAR *VP;      /* pointer to an unpredictable data type */
typedef void (FFAR *FP)();  /* program start address */

#if (SIZEOF_INT <= 2)       /* 16-bit,8-bit CPU */
typedef int H;              /* signed 16-bit integer */
typedef unsigned int UH;    /* unsigned 16-bit integer */
typedef int VH;             /* unpredictable data type (16-bit size) */
#else                       /* 32-bit CPU */
typedef short H;            /* signed 16-bit integer */
typedef unsigned short UH;  /* unsigned 16-bit integer */
typedef short VH;           /* unpredictable data type (16-bit size) */
#endif

#if (SIZEOF_PTR == 2)
typedef unsigned int SIZE;
typedef unsigned int ADDR;
#else
typedef unsigned long SIZE;
typedef unsigned long ADDR;
#endif

typedef VP VP_INT;          /* pointer to unpredictable data type or signed integer */

/* Data Types Dependent on ITRON */

#if (SIZEOF_INT == 1)       /* 8-bit CPU */
typedef signed char INT;    /* signed integer (bit width of processor) */
typedef unsigned char UINT; /* unsigned integer (bit width of processor) */
#elif defined(OLD_ICC_H83)  /* old ICC H8/300H */
typedef short INT;
typedef unsigned short UINT;
#else                       /* 16-bit,32-bit CPU */
typedef int INT;
typedef unsigned int UINT;
#endif

typedef INT BOOL;           /* boolean value TRUE(1) or FALSE(0) */
typedef INT FN;             /* function code */
typedef INT ID;             /* object ID number */
typedef INT BOOL_ID;        /* boolean value or ID number */
typedef INT HNO;            /* handler number (uITRON3.0) */
typedef INT RNO;            /* rendezvous number (uITRON3.0) */
typedef INT RDVNO;          /* rendezvous number */
typedef UINT RDVPTN;        /* rendezvous pattern */
typedef UINT ATR;           /* object or handler attribute */
typedef UINT MODE;          /* system call mode */
typedef INT ER;             /* error code */
typedef INT PRI;            /* task priority */
typedef ER ER_ID;           /* error code or object ID */
typedef UINT STAT;          /* status of object */
typedef INT ER_UINT;        /* error code or unsigned int */
typedef UINT TEXPTN;        /* causal pattern for task exception */
typedef UINT FLGPTN;        /* bit pattern for event flag */
typedef UINT INHNO;         /* interrupt handler number */
typedef UINT INTNO;         /* interrupt number */

#if (SIZEOF_INT == 1)       /* 8-bit CPU */

typedef H TMO;              /* timeout value */
typedef struct t_systime {  /* time of system clock */
    H utime;                /* upper 16 bits */
    UH ltime;               /* lower 16 bits */
} SYSTIME;
typedef SYSTIME CYCTIME;    /* time of cyclic handler */
typedef SYSTIME ALMTIME;    /* time of alarm handler */
typedef H DLYTIME;          /* time of task delay */

#else                       /* 16-bit,32-bit CPU */

typedef W TMO;              /* timeout value */
typedef struct t_systime {  /* time of system clock */
    H utime;                /* upper 16 bits */
    UW ltime;               /* lower 32 bits */
} SYSTIME;
typedef SYSTIME CYCTIME;    /* time of cyclic handler (uITRON3.0) */
typedef SYSTIME ALMTIME;    /* time of alarm handler (uITRON3.0) */
typedef W DLYTIME;          /* time of task delay (uITRON3.0) */

#endif

typedef DLYTIME RELTIM;     /* relative time (uITRON4.0) */
typedef SYSTIME V4_SYSTIM;  /* absolute time (uITRON4.0) */
typedef DLYTIME OVRTIM;     /* overrun time (uITRON4.0) */

#ifdef __cplusplus
}
#endif
#endif /* ITRON_H */
