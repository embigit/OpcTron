/******************************************************************************
* TCP/IP Stack - Multi-Channel LAN Driver Header                              *
******************************************************************************/

#ifndef NONELAN_H
#define NONELAN_H
#ifdef __cplusplus
extern "C" {
#endif

#include "nonet.h"
#include "nonets.h"

/* Driver Function Prototypes */

ER lan_ini(UB *);
ER lan_wai_rcv(TMO);
ER lan_wai_snd(TMO);
ER lan_get_len(UH *);
ER lan_get_pkt(void *, int);
ER lan_skp_pkt(int);
ER lan_get_end(void);
ER lan_set_len(int);
ER lan_put_pkt(const void *, int);
ER lan_put_dmy(int);
ER lan_put_end(void);
ER lan_ext_dev(void);
ER lan_ini_dev(UB *, int);
int lan_lnk_sts(void);
ER lan_ini_cko(UB *, UB *);
ER lan_snd_cko(UW, UW);
ER lan_add_mcst(UW);
ER lan_del_mcst(UW);
ER lan_add_mcv6(UW);
ER lan_del_mcv6(UW);
ER lan_def_cbk(FP);
ER lan_def_int(void);
void lan_intr(void);
void lan_txint(void);
void lan_rxint(void);
void PHY_write(UB, UH);
UH PHY_read(UB);
ER PHY_link(void);
ER PHY_init(BOOL, int, int);
void PHY_reset(void);

ER lan_ini1(UB *);
ER lan_wai_rcv1(TMO);
ER lan_wai_snd1(TMO);
ER lan_get_len1(UH *);
ER lan_get_pkt1(void *, int);
ER lan_skp_pkt1(int);
ER lan_get_end1(void);
ER lan_set_len1(int);
ER lan_put_pkt1(const void *, int);
ER lan_put_dmy1(int);
ER lan_put_end1(void);
ER lan_ext_dev1(void);
ER lan_ini_dev1(UB *, int);
int lan_lnk_sts1(void);
ER lan_ini_cko1(UB *, UB *);
ER lan_snd_cko1(UW, UW);
ER lan_add_mcst1(UW);
ER lan_del_mcst1(UW);
ER lan_add_mcv61(UW);
ER lan_del_mcv61(UW);
ER lan_def_cbk1(FP);
ER lan_def_int1(void);
void lan_intr1(void);
void lan_txint1(void);
void lan_rxint1(void);
void PHY_write1(UB, UH);
UH PHY_read1(UB);
ER PHY_link1(void);
ER PHY_init1(BOOL, int, int);
void PHY_reset1(void);

ER lan_ini2(UB *);
ER lan_wai_rcv2(TMO);
ER lan_wai_snd2(TMO);
ER lan_get_len2(UH *);
ER lan_get_pkt2(void *, int);
ER lan_skp_pkt2(int);
ER lan_get_end2(void);
ER lan_set_len2(int);
ER lan_put_pkt2(const void *, int);
ER lan_put_dmy2(int);
ER lan_put_end2(void);
ER lan_ext_dev2(void);
ER lan_ini_dev2(UB *, int);
int lan_lnk_sts2(void);
ER lan_ini_cko2(UB *, UB *);
ER lan_snd_cko2(UW, UW);
ER lan_add_mcst2(UW);
ER lan_del_mcst2(UW);
ER lan_add_mcv62(UW);
ER lan_del_mcv62(UW);
ER lan_def_cbk2(FP);
ER lan_def_int2(void);
void lan_intr2(void);
void lan_txint2(void);
void lan_rxint2(void);
void PHY_write2(UB, UH);
UH PHY_read2(UB);
ER PHY_link2(void);
ER PHY_init2(BOOL, int, int);
void PHY_reset2(void);

ER lan_ini3(UB *);
ER lan_wai_rcv3(TMO);
ER lan_wai_snd3(TMO);
ER lan_get_len3(UH *);
ER lan_get_pkt3(void *, int);
ER lan_skp_pkt3(int);
ER lan_get_end3(void);
ER lan_set_len3(int);
ER lan_put_pkt3(const void *, int);
ER lan_put_dmy3(int);
ER lan_put_end3(void);
ER lan_ext_dev3(void);
ER lan_ini_dev3(UB *, int);
int lan_lnk_sts3(void);
ER lan_ini_cko3(UB *, UB *);
ER lan_snd_cko3(UW, UW);
ER lan_add_mcst3(UW);
ER lan_del_mcst3(UW);
ER lan_add_mcv63(UW);
ER lan_del_mcv63(UW);
ER lan_def_cbk3(FP);
ER lan_def_int3(void);
void lan_intr3(void);
void lan_txint3(void);
void lan_rxint3(void);
void PHY_write3(UB, UH);
UH PHY_read3(UB);
ER PHY_link3(void);
ER PHY_init3(BOOL, int, int);
void PHY_reset3(void);

/* Set Default Value of NIF_NUM/DIF_NUM/ETH_CH */

#if (defined(NIF_NUM) && defined(DIF_NUM) && !defined(ETH_CH))
#define ETH_CH  DIF_NUM
#undef DIF_NUM
#endif

#ifndef NIF_NUM
#if defined(DIF_NUM)
#define NIF_NUM DIF_NUM
#elif defined(ETH_CH)
#define NIF_NUM ETH_CH
#else
#define NIF_NUM 0
#endif
#endif

#ifndef DIF_NUM
#define DIF_NUM NIF_NUM
#endif

#ifndef ETH_CH
#define ETH_CH DIF_NUM
#endif

/* Driver Function Replacement Macros */

#if (DIF_NUM == 0)

#elif (DIF_NUM == 1)
#define lan_ini      lan_ini1
#define lan_wai_rcv  lan_wai_rcv1
#define lan_wai_snd  lan_wai_snd1
#define lan_get_len  lan_get_len1
#define lan_get_pkt  lan_get_pkt1
#define lan_skp_pkt  lan_skp_pkt1
#define lan_get_end  lan_get_end1
#define lan_set_len  lan_set_len1
#define lan_put_pkt  lan_put_pkt1
#define lan_put_dmy  lan_put_dmy1
#define lan_put_end  lan_put_end1
#define lan_ext_dev  lan_ext_dev1
#define lan_ini_dev  lan_ini_dev1
#define lan_lnk_sts  lan_lnk_sts1
#define lan_ini_cko  lan_ini_cko1
#define lan_snd_cko  lan_snd_cko1
#define lan_add_mcst lan_add_mcst1
#define lan_del_mcst lan_del_mcst1
#define lan_add_mcv6 lan_add_mcv61
#define lan_del_mcv6 lan_del_mcv61
#define lan_def_cbk  lan_def_cbk1
#define lan_def_int  lan_def_int1
#define lan_intr     lan_intr1
#define lan_txint    lan_txint1
#define lan_rxint    lan_rxint1
#define PHY_write    PHY_write1
#define PHY_read     PHY_read1
#define PHY_link     PHY_link1
#define PHY_init     PHY_init1
#define PHY_reset    PHY_reset1

#elif (DIF_NUM == 2)
#define lan_ini      lan_ini2
#define lan_wai_rcv  lan_wai_rcv2
#define lan_wai_snd  lan_wai_snd2
#define lan_get_len  lan_get_len2
#define lan_get_pkt  lan_get_pkt2
#define lan_skp_pkt  lan_skp_pkt2
#define lan_get_end  lan_get_end2
#define lan_set_len  lan_set_len2
#define lan_put_pkt  lan_put_pkt2
#define lan_put_dmy  lan_put_dmy2
#define lan_put_end  lan_put_end2
#define lan_ext_dev  lan_ext_dev2
#define lan_ini_dev  lan_ini_dev2
#define lan_lnk_sts  lan_lnk_sts2
#define lan_ini_cko  lan_ini_cko2
#define lan_snd_cko  lan_snd_cko2
#define lan_add_mcst lan_add_mcst2
#define lan_del_mcst lan_del_mcst2
#define lan_add_mcv6 lan_add_mcv62
#define lan_del_mcv6 lan_del_mcv62
#define lan_def_cbk  lan_def_cbk2
#define lan_def_int  lan_def_int2
#define lan_intr     lan_intr2
#define lan_txint    lan_txint2
#define lan_rxint    lan_rxint2
#define PHY_write    PHY_write2
#define PHY_read     PHY_read2
#define PHY_link     PHY_link2
#define PHY_init     PHY_init2
#define PHY_reset    PHY_reset2

#elif (DIF_NUM == 3)
#define lan_ini      lan_ini3
#define lan_wai_rcv  lan_wai_rcv3
#define lan_wai_snd  lan_wai_snd3
#define lan_get_len  lan_get_len3
#define lan_get_pkt  lan_get_pkt3
#define lan_skp_pkt  lan_skp_pkt3
#define lan_get_end  lan_get_end3
#define lan_set_len  lan_set_len3
#define lan_put_pkt  lan_put_pkt3
#define lan_put_dmy  lan_put_dmy3
#define lan_put_end  lan_put_end3
#define lan_ext_dev  lan_ext_dev3
#define lan_ini_dev  lan_ini_dev3
#define lan_lnk_sts  lan_lnk_sts3
#define lan_ini_cko  lan_ini_cko3
#define lan_snd_cko  lan_snd_cko3
#define lan_add_mcst lan_add_mcst3
#define lan_del_mcst lan_del_mcst3
#define lan_add_mcv6 lan_add_mcv63
#define lan_del_mcv6 lan_del_mcv63
#define lan_def_cbk  lan_def_cbk3
#define lan_def_int  lan_def_int3
#define lan_intr     lan_intr3
#define lan_txint    lan_txint3
#define lan_rxint    lan_rxint3
#define PHY_write    PHY_write3
#define PHY_read     PHY_read3
#define PHY_link     PHY_link3
#define PHY_init     PHY_init3
#define PHY_reset    PHY_reset3

#else
#error DIF_NUM is out of range!
#endif

/* Bridge Function Prototypes */

ER lan_error(ER);
UH lan_received_len(void);
BOOL lan_read_pkt(void *, int);
void lan_ignore_pkt(void);
BOOL lan_read_pkt_end(void *, int, int);
BOOL lan_write_m_pkt(T_DATA *, int);
ER lan_nif_dev(T_NIF *, FN, ...);

ER lan_error1(ER);
UH lan_received_len1(void);
BOOL lan_read_pkt1(void *, int);
void lan_ignore_pkt1(void);
BOOL lan_read_pkt_end1(void *, int, int);
BOOL lan_write_m_pkt1(T_DATA *, int);
ER lan_nif_dev1(T_NIF *, FN, ...);

ER lan_error2(ER);
UH lan_received_len2(void);
BOOL lan_read_pkt2(void *, int);
void lan_ignore_pkt2(void);
BOOL lan_read_pkt_end2(void *, int, int);
BOOL lan_write_m_pkt2(T_DATA *, int);
ER lan_nif_dev2(T_NIF *, FN, ...);

ER lan_error3(ER);
UH lan_received_len3(void);
BOOL lan_read_pkt3(void *, int);
void lan_ignore_pkt3(void);
BOOL lan_read_pkt_end3(void *, int, int);
BOOL lan_write_m_pkt3(T_DATA *, int);
ER lan_nif_dev3(T_NIF *, FN, ...);

/* Bridge Function Replacement Macros */

#if (NIF_NUM == 0)

#elif (NIF_NUM == 1)
#define lan_error        lan_error1
#define lan_received_len lan_received_len1
#define lan_read_pkt     lan_read_pkt1
#define lan_ignore_pkt   lan_ignore_pkt1
#define lan_read_pkt_end lan_read_pkt_end1
#define lan_write_m_pkt  lan_write_m_pkt1
#define lan_nif_dev      lan_nif_dev1

#elif (NIF_NUM == 2)
#define lan_error        lan_error2
#define lan_received_len lan_received_len2
#define lan_read_pkt     lan_read_pkt2
#define lan_ignore_pkt   lan_ignore_pkt2
#define lan_read_pkt_end lan_read_pkt_end2
#define lan_write_m_pkt  lan_write_m_pkt2
#define lan_nif_dev      lan_nif_dev2

#elif (NIF_NUM == 3)
#define lan_error        lan_error3
#define lan_received_len lan_received_len3
#define lan_read_pkt     lan_read_pkt3
#define lan_ignore_pkt   lan_ignore_pkt3
#define lan_read_pkt_end lan_read_pkt_end3
#define lan_write_m_pkt  lan_write_m_pkt3
#define lan_nif_dev      lan_nif_dev3

#else
#error NIF_NUM is out of range!
#endif

#ifdef __cplusplus
}
#endif
#endif /* NONELAN_H */
