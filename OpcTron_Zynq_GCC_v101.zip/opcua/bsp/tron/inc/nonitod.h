/******************************************************************************
* Integer-String Convertor Functions                                          *
******************************************************************************/

#ifndef NONITOD_H
#define NONITOD_H
#ifdef __cplusplus
extern "C" {
#endif

int itoulen(unsigned short);
int ltoulen(unsigned long);
int itodlen(short);
int ltodlen(long);
int itoxlen(unsigned short);
int ltoxlen(unsigned long);
char *ito0x(char *, unsigned short, int);
char *ito0X(char *, unsigned short, int);
char *lto0x(char *, unsigned long, int);
char *lto0X(char *, unsigned long, int);
char *itod_(char *, short, int);
char *itou_(char *, unsigned short, int);
char *ito_d(char *, short, int);
char *ito_u(char *, unsigned short, int);
char *ito0u(char *, unsigned short, int);
char *ltod_(char *, long, int);
char *ltou_(char *, unsigned long, int);
char *lto_d(char *, long, int);
char *lto_u(char *, unsigned long, int);
char *lto0u(char *, unsigned long, int);
char *ito_f(char *, short, int, int);
char *ito_fu(char *, unsigned short, int, int);
char *lto_f(char *, long, int, int);
char *lto_fu(char *, unsigned long, int, int);
unsigned short xtoi(const char *);
unsigned long xtol(const char *);
long atofl(const char *, int);

#define itod(s,d,n)       itod_(s,d,n)
#define itou(s,d,n)       itou_(s,d,n)
#define ltod(s,d,n)       ltod_(s,d,n)
#define ltou(s,d,n)       ltou_(s,d,n)

#ifdef __cplusplus
}
#endif
#endif /* NONITOD_H */
