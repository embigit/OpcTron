/******************************************************************************
* SNTP Client Header                                                          *
******************************************************************************/

#ifndef NONSNTP_H
#define NONSNTP_H
#ifdef __cplusplus
extern "C" {
#endif

#define SNTP_MODE     3         /* client mode */
#define SNTP_VERSION  0x18      /* NTP version 3 (IPv4 only) */
#define SNTP_VERSION4 0x20      /* NTP version 4 */
#define LEAP_INDC     0         /* leap indicator */

#define SNTP_PORT     123       /* SNTP port number */
#define SNTP_LEN      (4*12)    /* SNTP packet length */
#define SNTP_OPT      (4*5)     /* SNTP optional length - key identifier, message digest */

#define SEC_TICK  (1000/MSEC)   /* ticks per second */

#define JAN_1970  0x83AA7E80UL  /* seconds of 1900-01-01 00:00 ~ 1970-01-01 00:00 (2208988800) */
#define CUIP      0x80000000    /* correction for UIP */

typedef struct t_ntp_stmp
{
    union{                      /* integer part */
        UW  uip;                /* unsigned */
        W   ip;                 /* signed */
    } U_ip;
    union{                      /* decimal part */
        UW  ufp;                /* unsigned */
        W   fp;                 /* signed */
    } U_fp;
    #define ntp_fp  U_fp.fp
    #define ntp_ufp U_fp.ufp
    #define ntp_uip U_ip.uip
    #define ntp_ip  U_ip.ip
} T_NTP_TIM;

typedef struct t_ntp_pkt
{
    UB pkt_lvm;                 /* leap indicator, version & mode */
    UB pkt_stm;                 /* stratum */
    UB pkt_pol;                 /* polling interval */
    B pkt_psn;                  /* precision */
    W pkt_rtdly;                /* root delay */
    UW pkt_rtdisp;              /* root dispersion */
    UW pkt_refid;               /* reference clock ID */
    T_NTP_TIM pkt_reftim;       /* reference timestamp */
    T_NTP_TIM pkt_org;          /* originate timestamp */
    T_NTP_TIM pkt_rcv;          /* receive timestamp */
    T_NTP_TIM pkt_txt;          /* transmit timestamp */
} T_NTP_PKT;

ER sntp_start(const char * const [], UW, TMO);
ER sntp_get_tim(T_NTP_TIM *);
ER ntp_get_tim(T_NTP_TIM *);
void ntp_set_tim(T_NTP_TIM *);

#ifdef __cplusplus
}
#endif
#endif /* NONSNTP_H */
