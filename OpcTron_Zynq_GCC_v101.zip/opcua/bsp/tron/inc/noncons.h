/******************************************************************************
* Serial Console Functions Header                                             *
******************************************************************************/

#ifndef NONCONS_H
#define NONCONS_H
#ifdef __cplusplus
extern "C" {
#endif

#include "nonteln.h"

/* Serial Console Control Block */

typedef struct t_console {
    BOOL (*term_print)(T_TERMINAL *, const char *);
    INT (*term_getch)(T_TERMINAL *);
    UH telnetd_tskid;
    UH shell_tskid;
    UH rx_mbfid;
    B logged_in;
    B echo_on;
    FP sigint;
    FP passwd_check;
    TMO tmo;
    const char *prompt;
    UH cepid; /* fixed to 0 in case of serial console */
    INT ch;
} T_CONSOLE;

/* Serial Console Functions */

BOOL console_print(T_CONSOLE *, const char *);
INT console_input(T_CONSOLE *, char *, int);
INT console_getch(T_CONSOLE *);
BOOL console_kbhit(T_CONSOLE *);
ER console_ini(T_CONSOLE *, ID, ID, INT, const char *);

#ifdef __cplusplus
}
#endif
#endif /* NONCONS_H */
