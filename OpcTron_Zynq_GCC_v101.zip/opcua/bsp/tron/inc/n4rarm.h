/******************************************************************************
* Kernel CPU-dependent Definitions for ARM                                    *
******************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************/
/* When Included from nonetc.h via nosys4.h for Configuration                */
/*****************************************************************************/
#ifdef NONETC_H

/* CPU-dependent TCP/IP Stack Configuration */

#ifdef ARM_NEON
#ifndef SSZ_IP_SND_TSK
#ifdef IPSEC
#define SSZ_IP_SND_TSK  (1304 + 256)
#else
#define SSZ_IP_SND_TSK  (1024 + 256)
#endif
#endif
#ifndef SSZ_IP_RCV_TSK
#ifdef IPSEC
#define SSZ_IP_RCV_TSK  (1304 + 256)
#else
#define SSZ_IP_RCV_TSK  (1024 + 256)
#endif
#endif
#endif

#endif /* NONETC_H */
/*****************************************************************************/
/* When Included from nocfg4.h via nosys4.h for Configuration                */
/*****************************************************************************/
#ifdef OS_CONFIG

/* CPU-dependent Kernel Internal Data */

extern const UW KNL_SR;     /* explicit declaration for C++ external linkage */
#ifdef CPU_ARM7M
#ifndef KNL_LEVEL           /* Cortex-M3/M4 kernel interrupt mask level */
#define KNL_LEVEL   1       /* (this is prior to default in no4cfg.h) */
#endif
UH KNL_IMASK;
const UW KNL_SR = KNL_LEVEL;
#else
#if defined(IRQ_Disable)
const UW KNL_SR = 0x00000080;
#else
const UW KNL_SR = 0x00000000;
#endif
UW INT_PSR;
UW USER_PSR;
#endif
UW IMASK;
B *ISP;

/* Extra Memory Pool and Stack Area */

#ifdef MPLMSZ
#if ((MPLMSZ)/SIZEOF_INT!=0)

#if defined(__CC_ARM)
#pragma arm section zidata="MPLMEM"
__align(SIZEOF_ALIGN)
#elif defined(__ICCARM__)
#pragma location="MPLMEM"
#pragma data_alignment=SIZEOF_ALIGN
#elif defined(__ghs)
#pragma ghs section bss=".MPLMEM"
#pragma alignvar (SIZEOF_ALIGN)
#endif
#if defined(__GNUC__)
int MPLMEM[(MPLMSZ)/SIZEOF_INT] __attribute__ ((aligned(SIZEOF_ALIGN), section(".MPLMEM"))) = {0};
#else
int MPLMEM[(MPLMSZ)/SIZEOF_INT];
#endif
#if defined(__CC_ARM)
#pragma arm section zidata
#elif defined(__ghs)
#pragma ghs section bss=default
#endif

#endif
#endif /* MPLMSZ */

#ifdef STKMSZ
#if ((STKMSZ)/SIZEOF_INT!=0)

#if defined(__CC_ARM)
#pragma arm section zidata="STKMEM"
__align(SIZEOF_ALIGN)
#elif defined(__ICCARM__)
#pragma location="STKMEM"
#pragma data_alignment=SIZEOF_ALIGN
#elif defined(__ghs)
#pragma ghs section bss=".STKMEM"
#pragma alignvar (SIZEOF_ALIGN)
#endif
#if defined(__GNUC__)
int STKMEM[(STKMSZ)/SIZEOF_INT] __attribute__ ((aligned(SIZEOF_ALIGN), section(".STKMEM"))) = {0};
#else
int STKMEM[(STKMSZ)/SIZEOF_INT];
#endif
#if defined(__CC_ARM)
#pragma arm section zidata
#elif defined(__ghs)
#pragma ghs section bss=default
#endif

#endif
#endif /* STKMSZ */

#endif /* OS_CONFIG */
/*****************************************************************************/
/* When Included from nosys4.h Normally                                      */
/*****************************************************************************/
#ifndef N4RARM_H
#define N4RARM_H

extern UW IMASK;            /* Interrupt mask/BASEPRI value of task */
extern B *ISP;              /* Pointer to interrupt stack */
#ifdef CPU_ARM7M
extern UH KNL_IMASK;        /* BASEPRI value of kernel */
#endif
extern const UW KNL_SR;     /* kernel interrupt mask level (= KNL_LEVEL) */

/************************************************/
/* Context Structure (Green Hills C)            */
/************************************************/
#if defined(__ghs)

#if (SIZEOF_ALIGN==8)
typedef struct t_ctx {
    ER ercd;    /* a1 */
    ID wid;     /* a2 */
    UINT ptn;   /* a3 */
    VP ptr;     /* a4 */
    int v1;
    int v2;
    int v3;
    int v4;
    int v5;
    int v6;
    int v7;
    int v8;
    int sp;
    FP lr;
    int dmy;    /* dummy */
    int psr;
    int ip;
    FP pc;
  #ifdef ARM_VFP
    int fpexc;
    int fpscr;
  #endif
} T_CTX;

#else
typedef struct t_ctx {
    ER ercd;    /* a1 */
    ID wid;     /* a2 */
    UINT ptn;   /* a3 */
    VP ptr;     /* a4 */
    int r4;
    int r5;
    int r6;
    int r7;
    int r8;
    int r9;
    int r10;
    int r11;
    FP lr;
    int psr;
    int r12;
    FP pc;
} T_CTX;
#endif

/************************************************/
/* Context Structure (GAIO XASS-V)              */
/************************************************/
#elif defined(GAIO)

typedef struct t_ctx {
    int ercd;   /* r0 */
    int r1;
    int r2;
    int r3;
    int r4;
    ID wid;     /* r5 */
    int r6;
    int r7;
    UINT ptn;   /* r8 */
    VP ptr;     /* r9 */
    int r10;
    int r11;
    int r12;
    int sp;
    FP lr;
    int psr;
    FP pc;
} T_CTX;

/************************************************/
/* Context Structure (RVCT, EWARM, CCS, GCC)    */
/************************************************/
#else
#ifdef CPU_ARM7M /* Cortex-M3/M4 */

typedef struct t_ctx {
  #ifdef ARM_VFP
     int aligner;
     int exc_r; /* EXC_RETURN */
  #endif
     int r4;
     int r5;
     int r6;
     int r7;
     int r8;
     int r9;
     int r10;
     int r11;
     ER ercd;   /* r0 */
     ID wid;    /* r1 */
     UINT ptn;  /* r2 */
     VP ptr;    /* r3 */
     int r12;
     FP lr;
     FP pc;
     int xpsr;
 } T_CTX;

#else /* ARM7, ARM9, ARM11, Cortex-A/R */

#if (SIZEOF_ALIGN==8)
typedef struct t_ctx {
    ER ercd;    /* a1 */
    ID wid;     /* a2 */
    UINT ptn;   /* a3 */
    VP ptr;     /* a4 */
    int v1;
    int v2;
    int v3;
    int v4;
    int v5;
    int v6;
    int v7;
    int v8;
    int sp;
    FP  lr;
    int dmy;
    int psr;
    int ip;
    FP pc;
  #ifdef ARM_VFP
    int fpexc;
    int fpscr;
  #endif
} T_CTX;

#else
typedef struct t_ctx {
    ER ercd;    /* a1 */
    ID wid;     /* a2 */
    UINT ptn;   /* a3 */
    VP ptr;     /* a4 */
    int v1;
    int v2;
    int v3;
    int v4;
    int v5;
    int v6;
    int v7;
    int v8;
    FP lr;
    int psr;
    int ip;
    FP pc;
} T_CTX;
#endif

#endif
#endif
#ifdef NOKNL4_C
/************************************************/
/* Kernel Assembly Functions (Cortex-M3/M4)     */
/************************************************/
#ifdef CPU_ARM7M /* Cortex-M3/M4 */

ER _dispatch(void);
ER _dispatch1(void);
ER _dispatch2(void);
void _dispatch3(void);
void dis_ims(void);
ER ret_ims(void);
void ret_ims2(void);
void ope_ims(void);

#if defined(__CC_ARM)     /* ARM Compiler */
ER __svc(0x00) svc_call(ER (*routine)(void));
ER __svc(0x00) svc_callv(void (*routine)(void));
#elif defined(__ICCARM__) /* EWARM */
#pragma swi_number=0x00
__swi ER svc_call(ER (*routine)(void));
#pragma swi_number=0x00
__swi ER svc_callv(void (*routine)(void));
#elif defined(__TMS470__) /* CCS */
#pragma SWI_ALIAS(svc_call, 0x00);
ER svc_call(ER (*routine)(void));
#pragma SWI_ALIAS(svc_callv, 0x00);
ER svc_callv(void (*routine)(void));
#endif

#define dispatch()      _dispatch()
#define dispatch1()     _dispatch1()
#define dispatch2()     _dispatch2()
#define dispatch3()     _dispatch3()

/*****************************************************/
/* Kernel Assembly Functions (ARM7~ARM9, Cortex-A/R) */
/*****************************************************/
#else
#ifdef __ICCARM__ /* EWARM */
__arm ER _dispatch(void);
__arm ER _dispatch1(void);
__arm ER _dispatch2(void);
__arm void _dispatch3(void);
__arm void _dis_ims(void);
__arm ER _ret_ims(void);
__arm void _ret_ims2(void);
__arm void _ope_ims(void);
#pragma swi_number=0x00
__swi __arm ER swi_call(ER (*routine)(void));
#pragma swi_number=0x00
__swi __arm ER swi_callv(void (*routine)(void));

#define dispatch()      swi_call(_dispatch)
#define dispatch1()     swi_call(_dispatch1)
#define dispatch2()     swi_call(_dispatch2)
#define dispatch3()     swi_callv(_dispatch3)
#define dis_ims()       swi_callv(_dis_ims)
#define ret_ims()       swi_call(_ret_ims)
#define ret_ims2()      swi_callv(_ret_ims2)
#define ope_ims()       swi_callv(_ope_ims)

#else /* Green Hills, XASS-V, ARM Compiler, CCS, GCC */
ER _dispatch(void);
ER _dispatch1(void);
ER _dispatch2(void);
void _dispatch3(void);
void _dis_ims(void);
ER _ret_ims(void);
void _ret_ims2(void);
void _ope_ims(void);

#if defined(__ghs) /* Green Hills */
asm ER swi_call(ER (*func)(void))
{
%reg func
    mov r0,func
    swi 0x00
%mem func
    ldr r0,func
    swi 0x00
%error
}
asm void swi_callv(void (*func)(void))
{
%reg func
    mov r0,func
    swi 0x00
%mem func
    ldr r0,func
    swi 0x00
%error
}

#elif defined(__TMS470__) /* CCS */
#pragma SWI_ALIAS(swi_call, 0x00);
ER swi_call(ER (*routine)(void));
#pragma SWI_ALIAS(swi_callv, 0x00);
ER swi_callv(void (*routine)(void));

#elif defined(__GNUC__) /* GCC */
#define swi_call(routine) ({                                 \
    register long _a1 asm("a1") = (long)routine;             \
    asm volatile("swi 0" : "=r"(_a1) : "r"(_a1) :            \
                 "memory","a2","a3","a4","ip");              \
    (ER)_a1;                                                 \
})
#define swi_callv(routine) ({                                \
    register long _a1 asm("a1") = (long)routine;             \
    asm volatile("swi 0" :: "r"(_a1) :                       \
                 "memory","a2","a3","a4","ip");              \
})

#elif !defined(GAIO) /* ARM Compiler */
ER __swi(0x00) swi_call(ER (*routine)(void));
ER __swi(0x00) swi_callv(void (*routine)(void));
#endif

#ifndef GAIO /* ARM Compiler, Green Hills */
#define dispatch()      swi_call(_dispatch)
#define dispatch1()     swi_call(_dispatch1)
#define dispatch2()     swi_call(_dispatch2)
#define dispatch3()     swi_callv(_dispatch3)
#define dis_ims()       swi_callv(_dis_ims)
#define ret_ims()       swi_call(_ret_ims)
#define ret_ims2()      swi_callv(_ret_ims2)
#define ope_ims()       swi_callv(_ope_ims)
#endif

#endif
#endif
#endif
/************************************************/
/* Interrupt Mask Operation                     */
/************************************************/

#ifdef CPU_ARM7M /* Cortex-M3/M4 */
#define syssta_sub()        (IMASK = 0)
#define unl_cpu_sub()       (IMASK = 0)
extern void chg_ims_sub(UH);
extern UH ref_ims_sub(UH);
#define ref_sys_sub(ims)    ref_ims_sub(ims)

#else /* ARM7, ARM9, ARM11, Cortex-A/R */
#define syssta_sub()        (IMASK &= ~0x80)
#define unl_cpu_sub()       (IMASK &= ~0xc0)
#define chg_ims_sub(imask)  do { if (imask) IMASK |=  0x80; \
                                 else       IMASK &= ~0x80; \
                            } while (0)
#define ref_sys_sub(imask)  ((imask & 0x80) != 0)
#define ref_ims_sub(ims)    ((ims & 0x80) != 0)
#endif

/************************************************/
/* Context Operation (Common)                   */
/************************************************/

#define ref_isr_sub()
#define cre_tsk_sub()   stksz -= sizeof(T_CTX)

/************************************************/
/* Context Operation (Cortex-M3/M4)             */
/************************************************/
#ifdef CPU_ARM7M

#ifdef ARM_VFP
#define sta_tsk_sub()   do { ctx->ercd = (ER)stacd; \
                             ctx->xpsr = 0x01000000; \
                             ctx->exc_r = 0xfffffffd; \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   do { ctx->xpsr = 0x01000000; \
                             ctx->exc_r = 0xfffffffd; \
                        } while (0)
#else
#define sta_tsk_sub()   do { ctx->ercd = (ER)stacd; \
                             ctx->xpsr = 0x01000000; \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   (ctx->xpsr = 0x01000000)
#endif
#define cre_isr_sub()

/************************************************/
/* Context Operation (ARM7~9, Cortex-A5~A9/R4)  */
/************************************************/
#else
extern UW USER_PSR;
#ifdef GAIO /* XASS-V */
#define sta_tsk_sub()   do { ctx->ercd = (ER)stacd; \
                             if (tcb->ctsk->tskatr & TA_GTHUMB) \
                                 task = (FP)((ADDR)task | 1); \
                             ctx->psr = ((ADDR)task & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->sp = (int)(ctx + 1); \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   do { ctx->sp = (int)(ctx + 1); \
                             ctx->psr = ((ADDR)rtn & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                        } while (0)
#define cre_isr_sub()   do { if (pk_cisr->istatr & TA_GTHUMB) \
                                 isr->isr = (FP)((ADDR)isr->isr | 1); \
                        } while (0)

#else /* ARM11, Cortex-A5/A7/A8/A9/R4 for ARM Compiler, EWARM, CCS, GCC */
#if (defined(__TARGET_ARCH_6)||defined(__ARM6__)||defined(__ARM11)||defined(__TARGET_ARCH_7_A)||defined(__ARM7A__)||defined(__TI_TMS470_V7A8__)||defined(__ARM_ARCH_7A__)||defined(__TARGET_ARCH_7_R)||defined(__ARM7R__)||defined(__TI_TMS470_V7R4__)||defined(__ARM_ARCH_7R__))
int vget_enb(void);
#ifdef ARM_VFP
#if (ARM_VFP == 32)
#define VFP_REGSZ       (8 * 32)
#else
#define VFP_REGSZ       (8 * 16)
#endif
#define sta_tsk_sub()   do { if (tcb->ctsk->tskatr & TA_VPU) { \
                                 ctx = (T_CTX *)((ADDR)ctx - VFP_REGSZ); \
                                 ctx->sp = (int)(ctx + 1) + VFP_REGSZ; \
                                 ctx->fpexc = 0x40000000; \
                                 ctx->fpscr = 0x03000000; \
                             } else { \
                                 ctx->sp = (int)(ctx + 1); \
                                 ctx->fpexc = 0x00000000; \
                             } \
                             ctx->ercd = (ER)stacd; \
                             ctx->psr = ((ADDR)task & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->psr |= vget_enb(); \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   do { if (tcb->excb->dtex->texatr & TA_VPU) { \
                                 ctx = (T_CTX *)((ADDR)ctx - VFP_REGSZ); \
                                 ctx->sp = (int)(ctx + 1) + VFP_REGSZ; \
                                 ctx->fpexc = 0x40000000; \
                                 ctx->fpscr = 0x03000000; \
                             } else { \
                                 ctx->sp = (int)(ctx + 1); \
                                 ctx->fpexc = 0x00000000; \
                             } \
                             ctx->psr = ((ADDR)rtn & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->psr |= vget_enb(); \
                        } while (0)
#define cre_isr_sub()

#else /* ARM_VFP undefined */
#define sta_tsk_sub()   do { ctx->sp = (int)(ctx + 1); \
                             ctx->ercd = (ER)stacd; \
                             ctx->psr = ((ADDR)task & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->psr |= vget_enb(); \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   do { ctx->sp = (int)(ctx + 1); \
                             ctx->psr = ((ADDR)rtn & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->psr |= vget_enb(); \
                        } while (0)
#define cre_isr_sub()

#endif

#else /* ARM7, ARM9 for ARM Compiler, EWARM, CCS */
#if (SIZEOF_ALIGN == 8)
#define sta_tsk_sub()   do { ctx->sp = (int)(ctx + 1); \
                             ctx->ercd = (ER)stacd; \
                             ctx->psr = ((ADDR)task & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   do { ctx->sp = (int)(ctx + 1);                     \
                             ctx->psr = ((ADDR)rtn & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                        } while (0)
#define cre_isr_sub()

#else
#define sta_tsk_sub()   do { ctx->ercd = (ER)stacd; \
                             ctx->psr = ((ADDR)task & 1) ? (USER_PSR|0x00000020) : USER_PSR; \
                             ctx->lr = (FP)v4_ext_tsk; \
                        } while (0)
#define ras_tex_sub()   (ctx->psr = ((ADDR)rtn & 1) ? (USER_PSR|0x00000020) : USER_PSR)
#define cre_isr_sub()

#endif
#endif
#endif
#endif
/************************************************/
/* Stack Area Initialization                    */
/************************************************/

#ifdef __ghs
extern signed char *init_ISP;
#define c_sysini_sub()  do { ISP = init_ISP - CFG.tstksz; \
                             if (pSTKMEM != NULL) { \
                                 stktop = (B *)pSTKMEM; \
                                 sp = stktop + CFG.stkmsz; \
                             } \
                             else \
                                 sp = ISP - CFG.istksz; \
                        } while (0)

#else
#define c_sysini_sub()  do { if (pSTKMEM != NULL) { \
                                 stktop = (B *)pSTKMEM; \
                                 sp = stktop + CFG.stkmsz; \
                             } \
                             else \
                                 sp -= CFG.tstksz; \
                             ISP = sp; \
                             i = CFG.istksz; \
                             while (i-- != 0) \
                                 *--sp = 0x00; \
                        } while (0)
#endif

#endif /* N4RARM_H */
#ifdef __cplusplus
}
#endif
