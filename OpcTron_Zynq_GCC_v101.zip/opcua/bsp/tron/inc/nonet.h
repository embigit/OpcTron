/******************************************************************************
* TCP/IP Stack Common Definition and Declaration                              *
******************************************************************************/

#ifndef NONET_H
#define NONET_H
#ifdef __cplusplus
extern "C" {
#endif

#define VP  void *

/************************************/
/* Data Structure                   */
/************************************/

/* for set configuration of CEP option to IP Address and Mask */
typedef struct t_net_addr {
    UB ipaddr[4];
    UB ipmask[4];
} T_NET_ADDR;

/* Packet to Store IP Address and Port Number */
typedef struct t_ipep {
    UW ipaddr;              /* IP Address */
    UH portno;              /* Port Number */
#ifdef DUAL_STK
    UW ip6addr[4];          /* IP6 Address */
    BOOL type;              /* Flag to get IP4/6 Address */
#endif
} T_IPEP;

#define T_IPV4EP T_IPEP

/* for set configuration of RAW communication End Point */

/* Data Link(Ethernet)/IP layer ID. */
#define RAW_LAYER_NONE      0   /* not connect */
#define RAW_LAYER_ETHER     1   /* Ethernet(Data Link) layer */
#define RAW_LAYER_IP        2   /* IP layer */

#define RAW_NIF_NAME        8   /* Network I/F Name */
#define RAW_ETHADDR_LEN     6   /* Ethernet address length */

/* Packet Types */
#define RAW_PACKET_HOST         0   /* to host  */
#define RAW_PACKET_BORADCAST    1   /* to all   */
#define RAW_PACKET_MULTICAST    2   /* to group */

typedef struct t_raw_ccep {
    ATR  cepatr;                 /* RAW communication End Point Attribute */
    UH   layer;                  /* connection layer (IP or Ethernet(Data Link)) */
    UH   prot;                   /* Ethernet Type(ETYPE_ID)/Protocol Number(PROT_ID) */
    const char *nif_name;        /* Network I/F Name: (RAW_NIF_NAME) */
    FP   callback;               /* Address of Callback Routine */
} T_RAW_CCEP;

/* Packet to Store Ethernet Address and IP Address */
typedef struct t_rawep {
   UH   pkttype;                 /* packet type (RAW_PACKET_HOST...) */
   UB   da[RAW_ETHADDR_LEN];     /* Destination MAC Address */
   UB   sa[RAW_ETHADDR_LEN];     /* Source MAC Address */
   UH   prot;                    /* Ethernet Type(etype) */
} T_RAWEP;

typedef struct t_rawipep {
   T_RAWEP eth;                 /* Ethernet Address */
   T_IPEP  ip;                  /* Local IP Address and Port Number */
} T_RAWIPEP;

/* Packet to Create TCP Reception Point */
typedef struct t_tcp_crep {
    ATR repatr;           /* TCP Reception Point Attribute */
    T_IPEP myaddr;        /* Local IP Address and Port Number */
} T_TCP_CREP;

/* Packet to Create TCP Communication End Point */
typedef struct t_tcp_ccep {
    ATR cepatr;             /* TCP Communication End Point Attribute */
    VP sbuf;                /* Top Address of Sending Window Buffer */
    INT sbufsz;             /* Size of Sending Window Buffer */
    VP rbuf;                /* Top Address of Receiving Window Buffer */
    INT rbufsz;             /* Size of Receiving Window Buffer */
    FP callback;            /* Address of Callback Routine */
} T_TCP_CCEP;

/* Packet to Create UDP Communication End Point */
typedef struct t_udp_ccep {
    ATR cepatr;             /* UDP Communication End Point Attribute */
    T_IPEP myaddr;          /* Local IP Address and Port Number */
    FP callback;            /* Address of Callback Routine */
} T_UDP_CCEP;

#ifdef DUAL_STK
typedef void (*IPV6_ADDR_CHG_CALLBACK)(int ch, const char *if_name);

typedef struct t_ipv6_addr {
    UW addr[4];
    UH scope;
    UW prefix_len;
    B  status;
} T_IPV6_ADDR;

/* Unicast address structure */
typedef struct t_uaddr {
    UW addr[4];      /* 128-bit address */
    UH scope;        /* Scope of the address */
    UW prefix;
    UW prfrd_lft;    /* preferred life time */
    UW valid_lft;    /* valid life time */
    ID DADtskid;     /* DAD probe task ID. Probe count is fixed as 1 now */
    B  flag;         /* Address Flag */
} T_UADDR;

typedef struct t_mld2_src{
    UW ip6addr[4];          /* Ipv6 source address */
    struct t_mld2_src *nxt; /* Pointer to next SRC entry if present or NULL */
    UH qry_flg;             /* Two values QUERIED/ NOT_QUERIED */
    UB ret_cnt;             /* Counter for retransmission=robust variable */
    UB src_mode;            /* Set to ALLOW/BLOCK/NOT_APPLICABLE for retransmission */
} T_MLD2_SRC;

/* Multicast address structure */
typedef struct t_maddr {
    UW addr[4];                     /* 128-bit address */
    UH scope;                       /* Scope of the address */
    UH mld_dly;                     /* Randomn delay to send MLD report. For unsolicited, MLD_UNSOL_DLY used*/
    UB mld_last_node;               /* To check whether it is the last node to send the report */
                                    /* This field of all-node link-local address used as flag for timer check*/
    UB mld_state;                   /* 0->Special_listener; 1->IDLE_listener; 2->DELAY listener */
    UB filt_mode;                   /* Mode of the multicast adress MODE_IS_INCLUDE or MODE_IS_EXCLUDE */
    UB res_typ;                     /* PEND_RESP_GRP_SPECIFIC_QUERY  /PEND_RESP_GRP_SRC_SPECIFIC_QUERY  /NOT_IN_USE*/
    struct t_maddr  *nxt_retrans;   /* This is used for maintaining pending retransmission list */
    struct t_maddr  *nxt_resp;      /* This is used for maintaining pending response list for group, group and source specific query */
    T_MLD2_SRC *src;                /* Pointer to source entry */
    UB ret_cnt;                     /* Counter for retransmission */
    UW corresponding_uaddr_cnt;
} T_MADDR;

/* MLD Internal Defintions */
#define MLD_SPECIAL_LISTENER 0 /* Link local all node multicast address: FF02::1 */
#define MLD_IDLE_LISTENER    1
#define MLD_DELAY_LISTENER   2

#define MLD_UNSOL_DLY        2 /* Re-transmit delay for Unsolicited report sending */

#define MAX_ADDR_CNT    4

#define MLD1_QRY                     1
#define MLD2_GEN_QRY                 2
#define MLD2_GRP_QRY                 3
#define MLD2_SRC_QRY                 4
#define MLD2_VERSION_1               1
#define MLD2_VERSION_2               2
#define MLD2_ROUTER_QUERY_INTERVAL 125
#define MLD2_ROBUSTNESS              2
#define MLD2_MAX_RESP               10
#endif

/* Definitions for IGMPv3 */
#define IGMP_VER_2                   2
#define IGMP_VER_3                   3
#define IGMP_ROUTER_QUERY_INTERVAL 125
#define IGMP_ROBUSTNESS              2
#define IGMP_MAX_RESP               10

#define IGMP3_GEN_QRY                1
#define IGMP3_GRP_QRY                2
#define IGMP3_SRC_QRY                3

/* Structure for MLDv2/IGMPv3 Querier information */
typedef struct t_router_info {
    UW max_res_time; /* Max response time */
    UW compt_timer;  /* Timer for the interface to shift back to MLDv2 mode */
    UB compt_mode;   /* Indicates mode of the interface MLDv2/MLDv1 */
    UB qrv;          /* Robustness read from the router */
    UB qqi;          /* Queriers query interval */
} T_ROUTER_INFO;

/* IGMP3 Source structure */
typedef struct t_igmp3_src {
    UW ipaddr;               /* Source IP address */
    struct t_igmp3_src *nxt; /* Next pointer */
    UH qry_flg;              /* For, pending response. QUERIED/ NOT_QUERIED */
    UB ret_cnt;              /* Counter for retransmission. Robust variable */
    UB src_mode;             /* Set to ALLOW/BLOCK/NOT_APPLICABLE. For, retransmission */
} T_IGMP3_SRC;

/* IGMPv3 Mulitcas Address Structure */
typedef struct t_gaddr {
    UW  ipaddr;                /* 32-bit Multicast Address */
    struct t_gaddr *nxt;       /* Next pointer */
    struct t_gaddr *nxt_ipret; /* For pending retransmission list(State Change) */
    struct t_gaddr *nxt_ipres; /* For pending response list(Query) */
    T_IGMP3_SRC *src_list;     /* Source List for this MCast Addr */
    UW grp_tmr;                /* Timer for GRP and GRP & SRC specific response */
    UB ret_cnt;                /* Counter for retransmission */
    UB filt_mode;              /* MODE_IS_INCLUDE or MODE_IS_EXCLUDE */
    UB res_type;               /* Type of pending response */
    UB leave_flag;             /* Flag to check Leave Group is called */
} T_GADDR;

/* Configurable entities for IP */
typedef struct t_nif_ip {
    UB ttl;         /* TTL value for IP packets */
    UB m_ttl;       /* TTL value for multicast packets */
    UH reasm_tmo;   /* IP reassembly process timeout */
#define IGMPV1_ROUTER_EXISTS 0x0010
    UH igmp_flag;   /* TRUE if IGMPV1 Router exists in the network */
    UH igmpv1_tmo;  /* Timeout to hold igmp_ver as TRUE */
} T_NIF_IP;

/* Configurable entities for TCP */
typedef struct t_nif_tcp {
    UH syn_rcnt;    /* Max of TCP SYN retransmission */
    UH dat_rcnt;    /* Max of TCP data retransmission */
    UW rto_ini;     /* TCP Initial retransmission timeout */
    UW rto_min;     /* TCP Max retransmission timeout */
    UW rto_max;     /* TCP Min retransmission timeout */
    UW ktime_tmo;   /* TCP Initial keep alive timeout */
    UW ktime_pro;   /* TCP keep alive probing timeout */
    UW ktime_suc;   /* TCP Keep alive probe interval */
    UH dack_tmo;    /* TCP Delay ACK timeout         */
    UH dup_ack;     /* TCP Duplicate ACK count       */
} T_NIF_TCP;

/* Function Type and Structure used in T_CTL_HEADER & T_NIF */
typedef ER (*TCP_CALLBACK)(ID, FN, VP);
typedef struct t_nif T_NIF;
struct t_arp_table;

/* Header for Internal Control */
typedef struct t_ctl_header {
    UB rcheck;                  /* reassembly check */
    UB hedflg;                  /* IP header setup flag */
    UH pad1;
    VP cep;                     /* pointer to communication end point control block */
    T_NIF *nif;                 /* pointer to network interface control block */
    UH tskid;                   /* task ID to wake up */
    UH mpfid;                   /* memory pool ID to release this packet */
    H fncd;                     /* function or event code for callback */
    H arprty;                   /* ARP retry count */
    INT parblk;                 /* pointer to parameter block for callback */
  #if (SIZEOF_INT == 2)
    UH pad2;
  #endif
    TCP_CALLBACK callback;      /* function pointer to callback */
} T_CTL_HEADER;

typedef struct t_ctl_pkt {
    struct t_ctl_pkt *next;     /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
} T_CTL_PKT;

/* Network I/F control block */
struct t_nif {
    struct t_nif *next;                     /* Pointer to Next Parameter Block */
    B   ch;                                 /* Channel Number */
#define NIF_NAME_MAX_LEN 7
    char name[NIF_NAME_MAX_LEN+1];          /* Channel Name */
    UH  multihome;                          /* Number of CEPs using non-default IP address */
    H   arp_index;                          /* ARP table index value */
    UB  hwaddr[6];                          /* Hardware Address ex. MAC Address */
    UB  ipaddr[4];                          /* Default IP Address */
    UB  gateway[4];                         /* Default Gateway */
    UB  mask[4];                            /* Subnet Mask */
    T_GADDR *gaddr_list;                    /* IGMPv3 Multicast Address list head */
    T_GADDR *ipret_list;                    /* Pending retransmission(State change) list head */
    T_GADDR *ipres_list;                    /* Pending response(Query) list head */
    T_ROUTER_INFO iprinfo;                  /* Information related to Querier */
    UW ipif_tmr;                            /* Interface Timer for Genral Query */
    UW tcp_tmout;                           /* TCP timeout time */
#ifdef DUAL_STK
    UB  host_id[6];                         /* Host I/F ID */
    T_UADDR uaddr_list[MAX_ADDR_CNT];       /* list of unicast address*/
    T_MADDR maddr_list[MAX_ADDR_CNT];       /* list of multicast address*/
    UW rch_time;                            /* Reachable Time */
    UW retr_timer;                          /* Retrans Time */
    UH path_mtu6;                           /* IPV6 Path MTU Size of Interface */
    T_MADDR *retr_list;                     /* List indicating pending retransmission reports due to state change */
    T_MADDR *resp_list;                     /* List indicating pending responses for queries GRP or SRC specific queries */
    T_ROUTER_INFO info;                     /* To maintain the information related to querier */
    UH interf_timer;                        /* To send the current state report of the interface */
    IPV6_ADDR_CHG_CALLBACK ipv6_addr_st_chg_cbk;
    BOOL ipv6_addr_st_chg_flag;
#endif
    ER  (*func)(struct t_nif *, FN, ...);   /* Pointer Network I/F Function */
#define NI_ETH      1
#define NI_PPP      2
#define NI_LOOP     3
#define NI_PPPOE    4
    UB type;                                /* Type of Data Link Layer */
    UH  stskid;                             /* ID of IP Send Task */
    UH  rtskid;                             /* ID of IP Receive Task */
    UH  smbxid;                             /* ID of Send Mail Box */
    UH  tcp_tmout_cepid;                    /* CEP ID of TCP timeout */
    T_NIF_IP  ip;                           /* IP specific for this interface */
    T_NIF_TCP tcp;                          /* TCP specific for this interface */
    UH  mtu;                                /* MTU size of the interface */
    UH  path_mtu;                           /* Path MTU Size of Interface */
    UB dhcp_ipaddr[4];                      /* DHCP ipaddr of this Interface */
    UB dns_ipaddr[4];                       /* DNS ipaddr of this Interface */
    VP pppoe_sess_info;                     /* PPPoE session infomation */
    struct t_arp_table *arp_table;
    T_CTL_PKT tim_pkt;                      /* dummy packet to wake IP send task up */
    VP retry_pkt;                           /* retransmit packets queue */
    VP arp_waiting;                         /* ARP response waiting packets queue */
    UW icmpdu;                              /* replied time of ICMP destination unreachable */
#ifdef DUAL_STK
    VP na_waiting;                          /* Neighbor Advertisement waiting packets queue */
#endif
};

/* Network I/F Address data */
typedef struct t_nif_addr {
    UB *hwaddr;     /* Hardware Address ex. MAC Address */
    const UB *ipaddr;     /* Default IP Address */
    const UB *gateway;    /* Default Gateway */
    const UB *mask;       /* Subnet Mask */
#ifdef DUAL_STK
    const UB *host_id;    /* Host I/F ID */
#endif
} T_NIF_ADDR;

/* IPv4 Static Routing Information */
typedef struct t_route_info {
    T_NIF *nif;         /* Network I/F Control Block Ponter */
    UW    dstnet;       /* Destination Network */
    UW    netmask;      /* Network Mask */
    UW    gwaddr;       /* Gateway Address */
} T_ROUTE_INFO;

/* IPv6 Static Routing Information */
typedef struct t_route6_info {
    T_NIF *nif;         /* Network I/F Control Block Ponter */
    UW    dstnet[4];    /* Destination Network Prefix */
    UW    pfxlen;       /* Prefix Length */
    UW    gwaddr[4];    /* Gateway Address */
} T_ROUTE6_INFO;

/************************************/
/* Common Constants                 */
/************************************/

/* TCP Function Codes */
#define TFN_TCP_CRE_REP (-0x201)
#define TFN_TCP_DEL_REP (-0x202)
#define TFN_TCP_CRE_CEP (-0x203)
#define TFN_TCP_DEL_CEP (-0x204)
#define TFN_TCP_ACP_CEP (-0x205)
#define TFN_TCP_CON_CEP (-0x206)
#define TFN_TCP_SHT_CEP (-0x207)
#define TFN_TCP_CLS_CEP (-0x208)
#define TFN_TCP_SND_DAT (-0x209)
#define TFN_TCP_RCV_DAT (-0x20a)
#define TFN_TCP_GET_BUF (-0x20b)
#define TFN_TCP_SND_BUF (-0x20c)
#define TFN_TCP_RCV_BUF (-0x20d)
#define TFN_TCP_REL_BUF (-0x20e)
#define TFN_TCP_SND_OOB (-0x20f)
#define TFN_TCP_RCV_OOB (-0x210)
#define TFN_TCP_CAN_CEP (-0x211)
#define TFN_TCP_SET_OPT (-0x212)
#define TFN_TCP_GET_OPT (-0x213)
#define TFN_TCP_ALL     0

/* UDP Function Codes */
#define TFN_UDP_CRE_CEP (-0x221)
#define TFN_UDP_DEL_CEP (-0x222)
#define TFN_UDP_SND_DAT (-0x223)
#define TFN_UDP_RCV_DAT (-0x224)
#define TFN_UDP_CAN_CEP (-0x225)
#define TFN_UDP_SET_OPT (-0x226)
#define TFN_UDP_GET_OPT (-0x227)
#define TFN_UDP_ALL     0

/* RAW Function Codes */
#define TFN_RAW_CRE_CEP (-0x401)
#define TFN_RAW_DEL_CEP (-0x402)
#define TFN_RAW_SND_DAT (-0x403)
#define TFN_RAW_RCV_DAT (-0x404)
#define TFN_RAW_ALL     0

/* TCP/IP Timer function code */
#define TFN_IP_TIM_ON   (-0x300)

/* Network I/F Function Codes */
#define TFN_GET_NIF_NUM         0
#define TFN_NET_INI             1
#define TFN_NET_WAI_RCV         2
#define TFN_NET_WAI_SND         3
#define TFN_NET_RED_PKT         4
#define TFN_NET_RED_PKT_END     5
#define TFN_NET_WRI_PKT         6
#define TFN_NET_RCV_LEN         7
#define TFN_NET_IGN_PKT         8
#define TFN_NET_ERR             9
#define TFN_NET_WRI_M_PKT       10
#define TFN_NET_EXT             11
#define TFN_CONNECT             20
#define TFN_PPPOE_SESSION_MATCH 21
#define TFN_PPPOE_RECEPTION     22
#define TFN_PPP_MDM_INI         23

/* Event Codes */
#define TEV_TCP_RCV_OOB   0x201 /* Urgent Data Received */
#define TEV_TCP_TMO_KTIME 0x202 /* TCP Keep Alive Timer timeout */
#define TEV_UDP_RCV_DAT   0x221 /* UDP Packet Received */
#define TEV_RAW_RCV_DAT   0x222 /* RAW Packet Received */
#define TEV_UDP_RCV_MCAST 0x223 /* UDP Multicast Packet Data Passed */

/* Main Error Codes */
#ifndef E_OK
#define E_OK        0       /* Normal Completion */
#define E_SYS       (-5)    /* System Error */
#define E_NOMEM     (-33)   /* Insufficient Memory */
#define E_NOSPT     (-9)    /* Feature Not Supported */
#define E_RSATR     (-11)   /* Reserved Attribute */
#define E_PAR       (-17)   /* Parameter Error */
#define E_ID        (-18)   /* Invalid ID Number */
#define E_NOEXS     (-42)   /* Object Not Existent */
#define E_OBJ       (-41)   /* Invalid Object State */
#define E_MACV      (-26)   /* Memory Access Violation */
#define E_QOVR      (-43)   /* Queuing Overflow */
#define E_DLT       (-51)   /* Object Deleted While Waiting */
#define E_TMOUT     (-50)   /* Polling Failure or Timeout Exceeded */
#define E_RLWAI     (-49)   /* Process Cancelled or Waiting State Forcibly Released */
#endif
#ifndef E_WBLK
#define E_WBLK      (-83)   /* Non-blocking Call Accepted */
#define E_CLS       (-87)   /* Connection Disconnected */
#define E_BOVR      (-89)   /* Buffer Overflow */
#endif

#define E_LNK       (-190)  /* Network Interface not exists */
#define E_ADDR      (-191)  /* Interface address has been changed */

/* Timeout Specifications */
#ifndef TMO_POL
#define TMO_POL     0L      /* Polling */
#define TMO_FEVR    (-1L)   /* Wait Forever */
#endif
#ifndef TMO_NBLK
#define TMO_NBLK    (-2L)   /* Non-Blocking Call */
#endif

/* Special IP Address and Port Number */
#define IPV4_ADDRANY    0           /* IP Address Specification Omitted */
#define TCP_PORTANY     0           /* TCP Port Number Specification Omitted */
#define UDP_PORTANY     0           /* UDP Port Number Specification Omitted */
#define IPV6_ADDRANY    {0,0,0,0}   /* IP6 Address Specification Omitted */

/* Address and End Point Types */
#define IPV4_ADDR       0
#define IPV6_ADDR       1

/* IPv6 Address flags */
#define ADDR_TENTATIVE  (8)
#define ADDR_PREFERRED  (1) /* SNMP_ADDR_PREFERRED */
#define ADDR_DEPRECATED (2) /* SNMP_ADDR_DEPRECATED */
#define ADDR_INVALID    (3) /* SNMP_ADDR_INVALID */
                            /* SNMP_ADDR_INACCESSIBLE == 4 */
                            /* SNMP_ADDR_UNKNOWN == 5 */
#define ADDR_VALID      (6) /* ADDR_PREFERRED or ADDR_DEPRECATED */
#define ADDR_PERMANENT  (7) /* SNMP_ADDR_PREFERRED */

/* IPv6 Address Type */
#define ADDR_UNICAST      0x0001
#define ADDR_MULTICAST    0x0002
#define ADDR_ANYCAST      0x0004
#define ADDR_V4COMPAT     0x0010
#define ADDR_V4MAPPED     0x0020
#define ADDR_UNSPEC       0x0040

/* IPv6 Address Scope */
#define ADDR_IF_LOCAL     0x0100
#define ADDR_LINK_LOCAL   0x0200
#define ADDR_ADMIN_LOCAL  0x0400
#define ADDR_SITE_LOCAL   0x0800
#define ADDR_ORG_LOCAL    0x1000
#define ADDR_GLOBAL       0x2000
#define ADDR_UNIQUE_LOCAL 0x4000
#define ADDR_LOOPBACK     0x8000

/************************************/
/* Utility Macros or Functions      */
/************************************/

/* Convert Byte Order */
#ifdef DUAL_STK
UW *htonl6(const UW *hl, UW *nl);
#define ntohl6(x, y)   htonl6(x, y)
#endif

UW htonl(UW);
UH htons(UH);
#define ntohl(x)    htonl(x)
#define ntohs(x)    htons(x)

/* Obtain Error Codes */
#define mainercd(x) ((int)((B)(x)))
#define subercd(x)  ((int)((B)((x)>>8)))

/************************************/
/* Service Call Prototypes          */
/************************************/

/* Network I/F Function */
typedef ER (*NIF_FP)(T_NIF *, FN, ...);

/* TCP/IP Stack Unique */
ER tcp_ini(void);
ER tcp_dev_ini(T_NIF *nif, const char *name, NIF_FP func, T_NIF_ADDR *addr);
ER tcp_nif_ini(T_NIF *nif, const char *name, NIF_FP func, T_NIF_ADDR *addr);
ER tcp_ext(T_NIF *nif);

ER net_set_opt(INT optname, const VP optval, INT optlen);
ER net_get_opt(INT optname, const VP optval, INT optlen);
ER net_chg_ipa(T_NIF_ADDR *addr, UB level);

ER netif_set_opt(T_NIF *nif, INT optname, const VP optval, INT optlen);
ER netif_get_opt(T_NIF *nif, INT optname, const VP optval, INT optlen);
ER netif_chg_ipa(T_NIF *nif, T_NIF_ADDR *addr, UB level);

ER netif_set_byname(const char *, INT optname, const VP optval, INT optlen);
ER netif_get_byname(const char *, INT optname, const VP optval, INT optlen);
ER netif_ipa_byname(const char *, T_NIF_ADDR *addr, UB level);

ER lan_nif_dev1(T_NIF *, FN, ...);
ER lan_nif_dev2(T_NIF *, FN, ...);
ER lan_nif_dev3(T_NIF *, FN, ...);

/* Network Interface Functions */
T_NIF *getnif_from_name(const char *name);
T_NIF *getnif_from_ch(int ch);
T_NIF *getnif_default(void);
T_NIF *getnif_ppp(void);
T_NIF *getnif_loop(void);
T_NIF *getnif_addr(UW);
T_NIF *getnif_dstaddr(UW);
T_NIF *getnif_dstxaddr(T_IPEP *);

#ifdef DUAL_STK
T_NIF *getnif_ip6addr(const UW *addr);
T_NIF *getnif_dst6addr(const UW *dst6addr);
ER ipv6_add_addr_by_name(const char *if_name, UW *addr, UW prefix_len);
ER ipv6_add_addr_by_ch(int ch, UW *addr, UW prefix_len);
ER ipv6_add_addr(T_NIF *nif, UW *addr, UW prefix_len);
ER ipv6_del_addr_by_name(const char *if_name, UW *addr);
ER ipv6_del_addr_by_ch(int ch, UW *addr);
ER ipv6_del_addr(T_NIF *nif, UW *addr);
ER ipv6_get_addr_by_name(const char *if_name, T_IPV6_ADDR *buf, UW buf_size, UW *found_num, UH addr_type_flag);
ER ipv6_get_addr_by_ch(int ch, T_IPV6_ADDR *buf, UW buf_size, UW *found_num, UH addr_type_flag);
ER ipv6_get_addr(T_NIF *nif, T_IPV6_ADDR *buf, UW buf_size, UW *found_num, UH addr_type_flag);
ER ipv6_def_addr_chg_cbk_by_name(const char *if_name, IPV6_ADDR_CHG_CALLBACK func);
ER ipv6_def_addr_chg_cbk_by_ch(int ch, IPV6_ADDR_CHG_CALLBACK func);
ER ipv6_def_addr_chg_cbk(T_NIF *nif, IPV6_ADDR_CHG_CALLBACK func);
ER add_route6(T_NIF *nif, UW *dstnet, UW pfxlen, UW *gwaddr);
ER del_route6(T_NIF *nif, UW *dstnet, UW pfxlen);
#endif

/* TCP Service Calls */
ER tcp_cre_rep(ID, const T_TCP_CREP *);
ER tcp_vcre_rep(const T_TCP_CREP *pk_crep);
ER tcp_del_rep(ID);
ER tcp_cre_cep(ID, const T_TCP_CCEP *);
ER tcp_vcre_cep(const T_TCP_CCEP *pk_ccep);
ER tcp_del_cep(ID);
ER tcp_acp_cep(ID, ID, T_IPV4EP *, TMO);
ER tcp_con_cep(ID, const T_IPV4EP *, T_IPV4EP *, TMO);
ER tcp_sht_cep(ID);
ER tcp_cls_cep(ID, TMO);
ER tcp_snd_dat(ID, const VP, INT, TMO);
ER tcp_rcv_dat(ID, VP, INT, TMO);
ER tcp_get_buf(ID, VP *, TMO);
ER tcp_snd_buf(ID, INT);
ER tcp_rcv_buf(ID, VP *, TMO);
ER tcp_rel_buf(ID, INT);
ER tcp_snd_oob(ID, const VP, INT, TMO);
ER tcp_rcv_oob(ID, VP, INT);
ER tcp_can_cep(ID, FN);
ER tcp_set_opt(ID, INT, const VP, INT);
ER tcp_get_opt(ID, INT, VP, INT);
ER tcp_ref_cep(ID, T_IPV4EP *);

/* UDP Service Calls */
ER udp_cre_cep(ID, const T_UDP_CCEP *);
ER udp_vcre_cep(const T_UDP_CCEP *pk_ccep);
ER udp_del_cep(ID);
ER udp_snd_dat(ID, const T_IPV4EP *, const VP, INT, TMO);
ER udp_rcv_dat(ID, T_IPV4EP *, VP, INT, TMO);
ER udp_can_cep(ID, FN);
ER udp_set_opt(ID, INT, const VP, INT);
ER udp_get_opt(ID, INT, VP, INT);

/* RAW Service Calls */
ER raw_cre_cep(ID, const T_RAW_CCEP *);
ER raw_vcre_cep(const T_RAW_CCEP *pk_ccep);
ER raw_del_cep(ID);
ER raw_snd_dat(ID, const T_RAWEP *, const VP, INT, TMO);
ER raw_rcv_dat(ID, T_RAWEP *, VP, INT, TMO);

/* ARP API's */
ER arp_snd_req(UW);
ER arp_add_entry(UW, UB *, UW);
ER arp_del_entry(UW);
ER arp_req_byname(const char *, UW);
ER arp_add_byname(const char *, UW, UB *, UW);
ER arp_del_byname(const char *, UW);
ER ini_arp_table(void);

/* IPv4 Static Routing APIs */
ER add_route(T_NIF *nif, UW dstnet, UW netmask, UW gwaddr);
ER del_route(T_NIF *nif, UW dstnet, UW netmask);

/* etc. */
ER landump_ini(ID, ID, ID);
UW byte4_to_long(const UB *);
void long_to_byte4(UB *, UW);
UW ascii_to_ipaddr(const char *);
ER ascii_to_ipxaddr(const char *, T_IPEP *);
INT ip4addr_to_ascii(char *, UW);
INT ipaddr_to_ascii(char *, UW);
UH tcp_portany(void);
#define udp_portany() tcp_portany()   /* 11/Jul/02 - Modified AK */
void tcp_set_iss(UW);

#ifdef DUAL_STK
ER ascii_to_ip6addr_sub(const char *str, UW *ipaddr);
void ascii_to_ip6addr(const char *str, UW *ipaddr);
INT ip6addr_to_ascii(char *str, const UW *ipaddr);
UH addr_type(const UW *addr);
#endif

/************************************/
/* TCP Well-known Port Numbers      */
/************************************/

#define TCP_PORT_MUX        1       /* TCP Multiplexor */
#define TCP_PORT_RJE        5       /* Remote Job Entry */
#define TCP_PORT_ECHO       7       /* Echo */
#define TCP_PORT_DISCARD    9       /* Discard */
#define TCP_PORT_SYSTAT     11      /* Active Users */
#define TCP_PORT_DAYTIME    13      /* Daytime */
#define TCP_PORT_NETSTAT    15      /* Network Status Program */
#define TCP_PORT_QOTD       17      /* Quote Of The Day */
#define TCP_PORT_CHARGEN    19      /* Character Generator */
#define TCP_PORT_FTPDATA    20      /* File Transfer Protocol (data) */
#define TCP_PORT_FTP        21      /* File Transfer Protocol */
#define TCP_PORT_TELNET     23      /* Terminal Connection */
#define TCP_PORT_SMTP       25      /* Simple Mail Transport Protocol */
#define TCP_PORT_TIME       37      /* Time */
#define TCP_PORT_NAME       42      /* Host Name Server */
#define TCP_PORT_WHOIS      43      /* Who Is */
#define TCP_PORT_NAMESERVER 53      /* Domain Name Server */
#define TCP_PORT_FINGER     79      /* Finger */
#define TCP_PORT_DCP        93      /* Device Control Protocol */
#define TCP_PORT_SUPDUP     95      /* SUPDUP Protocol */
#define TCP_PORT_HOSTNAMES  101     /* NIC Host Name Server */
#define TCP_PORT_ISOTSAP    102     /* ISO-TSAP */
#define TCP_PORT_X400       103     /* X-400 Mail Service */
#define TCP_PORT_X400SND    104     /* X-400 Mail Sending */
#define TCP_PORT_POP3       110     /* Post Office Protocol version3 */
#define TCP_PORT_SUNRPC     111     /* SUN Remote Procedure Call */
#define TCP_PORT_AUTH       113     /* Authentication Service */
#define TCP_PORT_UUCPPATH   117     /* UUCP Path Service */
#define TCP_PORT_NNTP       119     /* USENET News Transfer Protocol */
#define TCP_PORT_PWDGEN     129     /* Password Generator Protocol */
#define TCP_PORT_NETBIOSSSN 139     /* NETBIOS Session Service */

/************************************/
/* UDP Well-known Port Numbers      */
/************************************/

#define UDP_PORT_ECHO       7       /* Echo */
#define UDP_PORT_DISCARD    9       /* Discard */
#define UDP_PORT_SYSTAT     11      /* Active Users */
#define UDP_PORT_DAYTIME    13      /* Daytime */
#define UDP_PORT_NETSTAT    15      /* Who Is Up Or NETSTAT */
#define UDP_PORT_QOTD       17      /* Quote Of The Day */
#define UDP_PORT_CHARGEN    19      /* Character Generator */
#define UDP_PORT_TIME       37      /* Time */
#define UDP_PORT_NAME       42      /* Host Name Server */
#define UDP_PORT_WHOIS      43      /* Who Is */
#define UDP_PORT_NAMESERVER 53      /* Domain Name Server */
#define UDP_PORT_BOOTPS     67      /* Bootstrap Protocol Server */
#define UDP_PORT_BOOTPC     68      /* Bootstrap Protocol Client */
#define UDP_PORT_TFTP       69      /* Trivial File Transfer */
#define UDP_PORT_SUNRPC     111     /* Sun Microsystems RPC */
#define UDP_PORT_NTP        123     /* Network Time Protocol */
#define UDP_PORT_SNMP       161     /* SNMP Net Monitor */
#define UDP_PORT_SNMP_TRAP  162     /* SNMP Trap */
#define UDP_PORT_BIFF       512     /* Unix Comsat */
#define UDP_PORT_WHO        513     /* Unix Rwho Daemon */
#define UDP_PORT_SYSLOG     514     /* System Log */
#define UDP_PORT_TIMED      525     /* Time Daemon */
#define UDP_PORT_EPHEMERAL  1050    /* Top Number of Ephemeral Port */

/************************************/
/* Misc. Macros                     */
/************************************/

#define ETHERNET_MTU          1500         /* Maximum MTU size of an Interface */
#define NIF_MTU_MIN           128          /* Minimum MTU size of an Interface */
#define IP_DEF_MTTL           1            /* IP Multicast TimetoLive  */
#define ETHERNET_PAYLOAD_MIN  46           /* Minimum Ethenet Payload */
#define ETHERNET_PAYLOAD_MAX  ETHERNET_MTU /* Maximum Ethenet payload */

/************************************/
/* User Defined Address             */
/************************************/

extern UB ethernet_addr[6];
extern UB default_ipaddr[4];
extern UB subnet_mask[4];
extern UB default_gateway[4];
extern UB dhcp_ipaddr[4];
extern UB dns_ipaddr[4];

/* Definitions for General Interface Options */
#define SET_IF_MTU              0x01    /* To set specific Interface MTU value */
#define SET_IP_TTL              0x02    /* To set TTL value */
#define SET_IP_MTTL             0x03    /* To set Multicast TTL value */
#define SET_IP_REASM_TMO        0x04    /* To set IP reassembly process timeout value */
#define SET_TCP_SYN_RCNT        0x05    /* To set Number of TCP SYN retransmissions */
#define SET_TCP_DAT_RCNT        0x06    /* To set Number of TCP DATA or FIN retransmissions */
#define SET_TCP_RTO_INI         0x07    /* To set TCP initial retransmission timeout value */
#define SET_TCP_RTO_MIN         0x08    /* To set the lowest value for TCP retransmissions */
#define SET_TCP_RTO_MAX         0x09    /* To set the highest value for TCP retransmissions */
#define SET_TCP_KEEPALIVE_TMO   0x10    /* To set TCP Keep Alive timeout */
#define SET_TCP_KEEPALIVE_PRO   0x11    /* To set TCP Keep Alive probe interval timeout */
#define SET_TCP_KEEPALIVE_SUC   0x12    /* To set total timeout for Keep Alive probe */
#define SET_TCP_MSS             0x13    /* To set TCP MSS size for the interface */
#define SET_TCP_MTU     SET_TCP_MSS     /* for compatibility with old version */
#define SET_TCP_DACK_TMO        0x14    /* To set TCP Delay ACK timeout */
#define SET_TCP_DUP_ACK         0x15    /* To set TCP Duplicate ACK count */
#define SET_TCP_TSOPT           0x16    /* set enable time stamp option */

/* TCP/UDP specific */
#define IP_ADD_MEMBERSHIP       0x14    /* Add  an IP Group Membership */
#define IP_DROP_MEMBERSHIP      0x15    /* Drop an IP group membership */
#define IP_BROADCAST            0x16    /* IP Broad cast on/off */
#define IP_IF_NAME              0x17    /* Device interface name */
#define IP_IF_CH                0x18    /* Device interface index */
#define SET_IP_TOS              0x19    /* To set TOS value for UDP cep */
#define SET_UDP_RPKT_OPT        0x20    /* To enable the option for fetch information from rx UDP packet */
#define SET_UDP_SND_IF          0x21    /* To set Interface for outgoing UDP packet */
#define IPV6_JOIN_GROUP         0x22    /* Add an IPv6 Group Membership */
#define IPV6_LEAVE_GROUP        0x23    /* Drop an IPv6 Group Membership */
#define MCAST_INCLUDE           0x24    /* Allow the source */
#define MCAST_EXCLUDE           0x25    /* Block the sources */
#define ALLOW_SOURCES           0x26
#define BLOCK_SOURCES           0x27
#define IP_BROAD_FOR_DHCP       0x28    /* Receive IP directed-broadcast on/off for DHCP(relay agent) */
#define IP_MCAST_INCLUDE        0x29    /* IGMPv3 Add Sources in INCLUDE mode */
#define IP_MCAST_EXCLUDE        0x30    /* IGMPv3 Add Sources in EXCLUDE mode */
#define IP_ALLOW_SOURCES        0x31    /* IGMPv3 Allow the source */
#define IP_BLOCK_SOURCES        0x32    /* IGMPv3 Block the sources */
#define IP_REUSEPORT            0x33    /* Allow duplicate address and port */

#ifdef __cplusplus
}
#endif
#endif /* NONET_H */
