/******************************************************************************
* TCP/IP Stack Internal Definition and Declaration                            *
******************************************************************************/

#ifndef NONETS_H
#define NONETS_H
#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************/
/* Common Definitions                                                        */
/*****************************************************************************/

/* Constants */

#define AUTO_ID         0       /* object ID auto assignment */

#define NIF_TSK_NUM     2       /* number of tasks for NIF (network interface) */
#define NIF_MBX_NUM     1       /* number of mailboxes for NIF */

/* Data Blocks to Send Data to LAN Driver */

typedef struct t_data {
    void *data;                 /* pointer to data buffer */
    int len;                    /* size of data buffer */
} T_DATA;

/* Internal Data */

extern const UB unknown_addr[6];

/* Return The Greater/Smaller of Two Numbers */

#define MIN(x, y)   (((x) < (y)) ? (x) : (y))
#define MAX(x, y)   (((x) > (y)) ? (x) : (y))

/* miscellaneous flag */

#define IGMP_MEMBER_EXISTS 0x01
#define ETH_QLACK          0x02 /* lack of memory to queue Ethernet frames */

/*****************************************************************************/
/* Definitions for Ethernet                                                  */
/*****************************************************************************/

/* Ethernet Types */

#define ETYPE_IP4       0x0800  /* Ethernet type of IP protocol */
#define ETYPE_ARP       0x0806  /* Ethernet type of ARP protocol */
#define ETYPE_IP6       0x86DD  /* Ethernet type of IPv6 protocol */
#define ETYPE_DISCOVERY 0x8863  /* Ethernet type of PPPoE discovery packet */
#define ETYPE_SESSION   0x8864  /* Ethernet type of PPPoE session packet */

/* Ethernet Header */

typedef struct t_eth_header {
    UH len;                     /* received Ethernet frame length (and filler) */
    UB da[6];                   /* destination MAC address */
    UB sa[6];                   /* source MAC address */
    UH etype;                   /* Ethernet type */
} T_ETH_HEADER;

#define ETH_HEADER_SZ   ((int) sizeof (T_ETH_HEADER) - 2)

/* Ethernet Frame */

typedef struct t_eth {
    struct t_eth *next;         /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    UB data[ETHERNET_MTU];      /* data */
} T_ETH;

/*****************************************************************************/
/* Definitions for RAW                                                       */
/*****************************************************************************/

/* RAW Packet */

typedef struct t_raw_pkt {
    struct t_raw_pkt *next;     /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    UH dlen;                    /* data length */
    UB *data;                   /* pointer to RAW data */
} T_RAW_PKT;

/* RAW Communication End Point Control Block */

typedef struct t_raw_cep {
    struct t_raw_cep *next;     /* pointer to next block */
    UH cepid;                   /* RAW communication end point ID */
    UH layer;                   /* connection layer (IP or Ethernet (data link)) */
    UH prot;                    /* Ethernet type (ETYPE_ID)/protocol number (PROT_ID) */
    UH pkttype;                 /* packet type (PACKET_HOST) */
    UH id_raw_rcv_mbx;          /* receive packet mailbox */
    UH id_raw_snd_mpf;          /* send packet fixed memory pool */
    T_RAW_PKT *pkt;             /* target RAW packet address */
    TCP_CALLBACK callback;      /* function pointer to callback */
    T_NIF *nif;                 /* pointer to network interface control block */
    ER ercd;                    /* status of the interface */
} T_RAW_CEP;

/* RAW Reception Request Message */

typedef struct t_raw_rcv {
    struct t_raw_rcv *next;     /* queuing pointer for mailbox internal use */
    T_RAWEP *p_dstaddr;         /* destination address */
    ER *p_ercd;                 /* error code or data length */
    VP buf;                     /* buffer address */
    UH size;                    /* buffer size */
    UH tskid;                   /* task ID */
} T_RAW_RCV;

/*****************************************************************************/
/* Definitions for ARP                                                       */
/*****************************************************************************/

/* Constants */

#define ARP_RETRY       3       /* ARP retry count */

#define ARP_HEADER_SZ   28
#define ARP_PACKET_SZ   (ETH_HEADER_SZ + ARP_HEADER_SZ)

#define IP_ARP_TIMER    1000    /* IP_ARP_timer interval 1000 msec */

/* Operation */

#define ARP_REQ         1       /* ARP request */
#define ARP_RES         2       /* ARP response */

/* ARP Packet */

typedef struct t_arp {
    struct t_arp *next;         /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    UH htype;                   /* hardware address type (1) */
    UH ptype;                   /* protocol address type (ETYPE_IP) */
    UB hlen;                    /* hardware address length (6) */
    UB plen;                    /* protocol address length (4) */
    UH ope;                     /* operation (ARP_REQ or ARP_RES) */
    UB sha[6];                  /* source hardware address */
    UB spa[4];                  /* source protocol address */
    UB tha[6];                  /* target hardware address */
    UB tpa[4];                  /* target protocol address */
    UB pad[18];
} T_ARP;

/* Address Type */

#define ARP_UNKNOWN  0x00
#define ARP_DYNAMIC  0x02
#define ARP_STATIC   0x04
#define ARP_PROCESS  0x08

/* ARP Table */

typedef struct t_arp_table {
    UW ipaddr;                  /* network address */
    UW etime;                   /* elapsed time for ARP refresh */
    UW ftime;                   /* ARP force timeout */
    UH atype;                   /* address type */
    UB macaddr[6];              /* interface address */
    UB ch;                      /* interface channel */
    UB pad1;
    UH rtycnt;                  /* retry counter */
} T_ARP_TABLE;

/* ARP Control Block */

typedef struct t_arp_cb {
    struct t_arp_cb *next;      /* pointer to next control block */
    FP callback;                /* IP callback routine */
} T_ARP_CB;

/* ARP Callback Function Type */

typedef VP (*ARP_CALLBACK)(T_ARP *arp_pkt);

/*****************************************************************************/
/* Definitions for IPv4                                                      */
/*****************************************************************************/

/* Constants */

#define IP4_HEADER_SZ   20      /* sizeof (T_IP4_HEADER) */
#define PATH_MTU4 (ETHERNET_MTU - IP4_HEADER_SZ)

/* Version, IP Header Length */

#define MASK_IP_HEADER_LEN 0x0F /* mask for IP header length */

/* Protocol Numbers */

#define PROT_ICMP       1
#define PROT_IGMP       2
#define PROT_TCP        6
#define PROT_UDP        17

/* Flags, Fragment Offset */

#define IP_DF           0x4000  /* IP don't fragment flag */
#define IP_MF           0x2000  /* IP more fragment flag */
#define IP_OFFSET       0x1FFF  /* mask for fragment offset */

/* IPv4 Header */

typedef struct t_ip4_header {
    UB ver;                     /* version, IP header length */
    UB tos;                     /* type of service */
    UH tl;                      /* total length */
    UH id;                      /* identification */
    UH fo;                      /* flags, fragment offset */
    UB ttl;                     /* time to live */
    UB prot;                    /* protocol number */
    UH hc;                      /* header checksum */
    UW sa;                      /* source IP address */
    UW da;                      /* destination IP address */
} T_IP4_HEADER;

/* IPv4 Packet */

typedef struct t_ip4 {
    struct t_ip4 *next;         /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    T_IP4_HEADER ip;            /* IPv4 header (without option data) */
    B data[PATH_MTU4];          /* data (variable size) */
} T_IP4;

#define T_IP            T_IP4

/* IP Control Block */

typedef struct t_ip_cb {
    struct t_ip_cb *next;       /* pointer to next control block */
    FP callback;                /* IP callback routine */
} T_IP_CB;

/* IP Callback Function Type */

typedef VP (*IP_CALLBACK)(T_IP4 *);

/*****************************************************************************/
/* Definitions for IP Fragment                                               */
/*****************************************************************************/

/* Constants */

#define IPF_MREQ_BLK    3       /* min memory blocks required for IP reassembly */
#define IPF_UMEM_BLK    9       /* IP reassembly upper threshold value */

/* IP Fragment Header */

typedef struct t_ipf {
    struct t_ipf *fl_next;      /* pointer to next fragment list */
    UB rsv1;                    /* required for align with T_CTL header */
    UB rsv2;                    /* required for align with T_CTL header */
    UH pad;
    struct t_ipf *fl_prev;      /* pointer to previous fragment list */
    T_NIF *nif;                 /* interface address */
    struct t_ipf *nextf;        /* pointer to next fragment */
    UH tl;                      /* total length of original datagram */
    UH rtime;                   /* time for reassembling process */
    UW id;                      /* ID of fragment header (use IPv6 stack) */
    UH ofs;                     /* offset of fragment */
    UH len;                     /* length of fragment */
} T_IPF;

/*****************************************************************************/
/* Definitions for ICMP                                                      */
/*****************************************************************************/

/* ICMP Types */

#define TYPE_ECHO_REQ       8   /* echo request */
#define TYPE_ECHO_REP       0   /* echo reply */
#define TYPE_UNREACHABLE    3   /* destination unreachable */

/* ICMP Header */

typedef struct t_icmp_header {
    UB type;                    /* ICMP type */
    UB code;                    /* ICMP code */
    UH cs;                      /* checksum */
    UH id;                      /* identifier */
    UH seq;                     /* sequence number */
} T_ICMP_HEADER;

/* ICMP Message */

typedef struct t_icmp_msg {
    UB type;                    /* ICMP type */
    UB code;                    /* ICMP code */
    UH cs;                      /* checksum */
    UH id;                      /* identifier */
    UH seq;                     /* sequence number */
    UB data[IP4_HEADER_SZ+8];   /* option data (variable size) */
} T_ICMP_MSG;

/* ICMP Control Block */

typedef struct t_icmp_cb {
    struct t_icmp_cb *next;     /* pointer to next control block */
    FP callback;                /* ICMP callback routine */
    UH id;                      /* ICMP identifier (using task ID) */
} T_ICMP_CB;

/* ICMP Callback Function Type */

typedef VP (*ICMP_CALLBACK)(T_ICMP_CB *, T_IP4 *, T_ICMP_MSG *, INT);

/*****************************************************************************/
/* Definitions for IPv6                                                      */
/*****************************************************************************/

/* Constants */

#define IP6_HEADER_SZ   40      /* sizeof (T_IP6_HEADER) */

#ifdef DUAL_STK

#ifndef UW_MAX
#define UW_MAX          0xFFFFFFFF
#endif

#define IP6_ADDR_SZ     16
#define PATH_MTU6       (ETHERNET_MTU - IP6_HEADER_SZ)
#define MIN_PATH_MTU6   1240

#define IP6F_MREQ_BLK   3       /* min memory blocks required for IP reassembly */
#define IP6F_UMEM_BLK   9       /* IP reassembly upper threshold value */

#define IPV6_CYC_TIMER  100     /* interval:100 msec */
#define IPV6_LLADDR_BUF_MAX  6
#define IPV6_ADDR_BIT_SZ   128
#define IPV6_DEFAULT_PREFIX_BIT_SZ  64

/* Protocol Numbers */

#define PROT_AH         51
#define PROT_ESP        50
#define PROT_ICMPV6     58

/* Next Header Type */

#define HDR_HOP         0
#define HDR_ROUT        43
#define HDR_FRAG        44
#define HDR_NONXT       59
#define HDR_DSTOPT      60
#define HDR_AH          PROT_AH
#define HDR_ESP         PROT_ESP
#define HDR_ICMP6       PROT_ICMPV6
#define HDR_TCP         PROT_TCP
#define HDR_UDP         PROT_UDP

/* IPv6 Header */

typedef struct t_ip6_header {
    UW ver_tc_fl;               /* version, traffic class, flow label */
    UH pl;                      /* payload length */
    UB nxt;                     /* next header type */
    UB hlim;                    /* hop limit field */
    UW sa[IP6_ADDR_SZ/4];       /* source IPv6 address */
    UW da[IP6_ADDR_SZ/4];       /* destination IPv6 address */
} T_IP6_HEADER;

/* IPv6 Packet */

typedef struct t_ip6 {
    struct t_ip6 *next;         /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    T_IP6_HEADER ip6;           /* IPv6 header (without option data) */
    B data[PATH_MTU6];          /* data (variable size) */
} T_IP6;

/* Fragmentation Header */

typedef struct t_frag_header {
    UB nxt;                     /* next header field */
    UB resrvd;                  /* reserved */
    UH off_res_m;               /* fragment offset field */
    UW id;                      /* identification field */
} T_FRAG_HEADER;

/* IPv6 Extension Header : Option Types */

#define PAD1                    0
#define PADn                    1
#define HOP_ROUTER_ALERT_OPT    5
#define HOP_MLD_VALUE           0

#endif
/*****************************************************************************/
/* Definitions for ICMPv6                                                    */
/*****************************************************************************/
#ifdef DUAL_STK

/* Constants */

#define NOT_FORWARDED_BY_ROUTER 255

/* Error Flags */

#define ICMPV6_CHK_OK           0
#define ICMPV6_CHKSUM_ERR       1
#define ICMPV6_CODE_ERR         2
#define ICMPV6_HLIM_ERR         4
#define ICMPV6_SIZE_ERR         8

/* ICMPv6 Types */

#define ICMPV6_DST_UNREACHABLE  1
#define ICMPV6_PKT_TOO_BIG      2
#define ICMPV6_TIME_EXCEEDED    3
#define ICMPV6_PARAM_PBLM       4
#define ICMPV6_ECHO_REQUEST     128
#define ICMPV6_ECHO_REPLY       129
#define ICMPV6_MLD_QUERY        130
#define ICMPV6_MLD_REPORT       131
#define ICMPV6_MLD_DONE         132
#define ICMPV6_ROUTER_SOL       133
#define ICMPV6_ROUTER_ADV       134
#define ICMPV6_NEIGH_SOL        135
#define ICMPV6_NEIGH_ADV        136
#define ICMPV6_REDIRECT         137
#define ICMPV6_MLDV2_QUERY      ICMPV6_MLD_QUERY
#define ICMPV6_MLDV2_REPORT     143

/* Neighbor Advertisement Message Flags */

#define RTR_FLAG        0x80
#define SOL_FLAG        0x40
#define OVR_FLAG        0x20

/* ICMPv6 Header */

typedef struct t_icmpv6_hdr {
    UB type;                    /* type */
    UB code;                    /* code */
    UH chksum;                  /* checksum */
    union {                     /* message specific 4 bytes */
      struct t_echo_info {      /* echo message */
        UH id;                  /* identifier */
        UH seq_no;              /* sequence number */
      } echo;
      UW  unused;               /* unused for NS & RS */
      struct t_rtr_adv_info {   /* RA message */
        UB hop_lim;             /* current hop limit */
        UB rtr_flag;
        UH rtr_ltime;           /* router lifetime */
      } ra;
      struct t_neigh_adv_info { /* NA message */
        UB nda_flag;
        UB reserved[3];
      } na;
      struct t_mld_info {       /* MLD message */
        UH max_resp_dly;        /* maximum response delay */
        UH reserved;            /* reserved */
      } mld;
      struct t_mld2_info {      /* MLDv2 message */
        UH reserved;
        UH num_rec;             /* number of records present */
      } mld2;
      struct t_mld2_query_info {/* this is to store query information */
        UH mrc;                 /* max response code */
        UH reserved;
      } mld2_qry_mrc;
    } info;
} T_ICMPV6_HEADER;

#define rsrvd       info.unused
#define echo_id     info.echo.id
#define echo_seqno  info.echo.seq_no

/* ICMP6 Message */

typedef struct t_icmp6_msg {
    T_ICMPV6_HEADER icmpv6;
    UB data[IP6_HEADER_SZ + 8];
} T_ICMP6_MSG;

#define icmp_type   icmpv6.type
#define icmp_code   icmpv6.code
#define icmp_chksum icmpv6.chksum
#define curhoplim   icmpv6.info.ra.hop_lim
#define rtrltime    icmpv6.info.ra.rtr_ltime
#define na_flag     icmpv6.info.na.nda_flag

/* ICMPv6 Control Block */

typedef struct t_icmp6_cb {
    struct t_icmp6_cb *next;    /* pointer to next control block */
    FP callback;                /* ICMP callback routine */
} T_ICMP6_CB;

/* ICMPv6 Callback Function Type */

typedef VP (*ICMP6_CALLBACK)(T_ICMP6_CB *, T_IP6 *, T_ICMP6_MSG *, INT);

/* Option Codes */

#define OPT_SRC_LL_ADDR     1
#define OPT_DST_LL_ADDR     2
#define OPT_PREFIX_INFO     3
#define OPT_REDIRECT_HDR    4
#define OPT_MTU             5

/* Link Local Address Option */

typedef struct t_lladdr_opt {
    UB type;
    UB len;
    UB lladdr[IPV6_LLADDR_BUF_MAX];
} T_LLADDR_OPT;

/* Prefix Flags */

#define ONLNK_FLAG          0x80
#define AUTON_FLAG          0x40

/* Lifetime */

#define PREFIX_VALID_LIFETIME_BORDER_VALUE  7200

/* Prefix Option */

typedef struct t_prefix_opt {
    UB type;
    UB len;
    UB prefix_len;
    UB pfx_flag;
    UW val_ltime;
    UW prfr_ltime;
    UW rsrvd2;
    UW prefix[IP6_ADDR_SZ/4];
} T_PREFIX_OPT;

/* Redirect Header Options */

typedef struct t_redir_hdr_opt_fixed {
    UB type;
    UB len;
    UB reserved[6];
} T_REDIR_HDR_OPT_FIXED;

typedef struct t_redir_hdr_opt {
    T_REDIR_HDR_OPT_FIXED fixed;
    UB *pkt_data;
} T_REDIR_HDR_OPT;

/* MTU Option */

typedef struct t_mtu_opt {
    UB type;
    UB len;
    UH reserved;
    UW mtu;
} T_MTU_OPT;

/* Neighbor Messages */

#define MAX_PREFIX_INFO_OPT     8

typedef struct t_neigh_msg_opts {
    T_LLADDR_OPT *src_lladdr_opt;
    T_LLADDR_OPT *dst_lladdr_opt;
    UW prefix_cnt;
    T_PREFIX_OPT *prefix_opt[MAX_PREFIX_INFO_OPT];
    T_MTU_OPT *mtu_opt;
    T_REDIR_HDR_OPT *redir_hdr_opt;
} T_NEIGH_MSG_OPTS;

typedef struct t_neigh_msg_fixed {
    T_ICMPV6_HEADER icmpv6;
    UW dst_addr[IP6_ADDR_SZ/4];
    T_LLADDR_OPT opt_lladdr;
} T_NEIGH_MSG_FIXED;

/* Router Advertisement Message */

typedef struct t_rtr_adv_msg_fixed {
    T_ICMPV6_HEADER icmpv6;
    UW rch_time;
    UW retr_timer;
} T_RTR_ADV_MSG_FIXED;

/* Neighbor Solicitation Message */

typedef struct t_neigh_sol_msg_fixed {
    T_ICMPV6_HEADER icmpv6;
    UW dst_addr[IP6_ADDR_SZ/4];
} T_NEIGH_SOL_MSG_FIXED;

/* Neighbor Advertisement Message */

typedef struct t_neigh_adv_msg_fixed {
    T_ICMPV6_HEADER icmpv6;
    UW dst_addr[IP6_ADDR_SZ/4];
} T_NEIGH_ADV_MSG_FIXED;

/* Redirect Message */

typedef struct t_redir_msg_fixed {
    T_ICMPV6_HEADER icmpv6;
    UW target_addr[IP6_ADDR_SZ/4];
    UW dst_addr[IP6_ADDR_SZ/4];
} T_REDIR_MSG_FIXED;

/* Neighbor Discovery Constants */

#define MAX_UCAST_SOL       3
#define RETRNS_TIME         MSEC2TICK(1 * 1000)
#define RCHBLE_TIME         MSEC2TICK(30 * 1000)
#define NS_SOL_TIME         4
#define DELAY_PROBE_TIME    MSEC2TICK(5 * 1000)
#define MAX_RTRSOL_DELAY    MSEC2TICK(1 * 1000)
#define RTR_SOL_INT         MSEC2TICK(4 * 1000)
#define MAX_RTR_SOL         3

/* Reachability State */

#define NEIGH_REACHABLE     1
#define NEIGH_STALE         2
#define NEIGH_DELAY         3
#define NEIGH_PROBE         4
#define NEIGH_INCOMPLETE    7

/* Neighbor Cache Entry */

typedef struct t_neigh_cache {
    T_NIF *nif;                 /* pointer to network interface control block */
    UW ipaddr[IP6_ADDR_SZ/4];   /* IPv6 address of neighbor */
    UB ll_addr[IPV6_LLADDR_BUF_MAX]; /* MAC address of neighbor */
    BOOL is_rtr;                /* router flag */
    UB rch_state;               /* reachability state */
    UW nud_time;                /* neighbor unreachability detection timer */
    UW retr_time;               /* retransmit timer */
    UH retr_cnt;                /* retransmission counter */
} T_NEIGH_CACHE;

/* Prefix List Entry */

typedef struct t_prefix_list {
    T_NIF *nif;                 /* pointer to network interface control block */
    UW prefix[IP6_ADDR_SZ/4];   /* prefix */
    UB prefix_len;              /* prefix length */
    BOOL is_onlnk;              /* on-link flag */
    UW val_time;                /* validity timer */
    UW prefer_time;             /* preferred time */
    BOOL aton_flg;              /* atonomous flag */
} T_PREFIX_LIST;

/* Default Router Entry */

typedef struct t_dflt_router {
    T_NIF *nif;                 /* pointer to network interface control block */
    UW ipaddr[IP6_ADDR_SZ/4];   /* IPv6 address of router */
    UH l_time;                  /* router lifetime */
    UB hop_lim;                 /* current hop limit */
    UW rch_time;                /* reachable time */
    UW retr_timer;              /* retransmission timer */
    BOOL rch_flag;              /* reachable flag */
} T_DFLT_ROUTER;

/* Destination Cache */

typedef struct t_dst_cache {
    T_NIF *nif;                 /* pointer to network interface control block */
    UW dst_addr[IP6_ADDR_SZ/4]; /* IPv6 address of destination */
    UW nxt_hop[IP6_ADDR_SZ/4];  /* IPv6 address of next hop */
} T_DST_CACHE;

#endif
/*****************************************************************************/
/* Definitions for UDP                                                       */
/*****************************************************************************/

/* UDP Header */

typedef struct t_udp_header {
    UH sp;                      /* source port number */
    UH dp;                      /* destination port number */
    UH len;                     /* packet length */
    UH cs;                      /* checksum */
} T_UDP_HEADER;

#define UDP_HEADER_SZ   ((int) sizeof (T_UDP_HEADER))

/* UDP Packet */

typedef struct t_udp_pkt {
    struct t_udp_pkt *next;     /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    T_IP4_HEADER ip;            /* IPv4 header (without option data) */
    T_UDP_HEADER udp;           /* UDP header */
    UB *data;                   /* pointer to UDP data + IP header */
} T_UDP_PKT;

#ifdef DUAL_STK
typedef struct t_udp6_pkt {
    struct t_udp6_pkt *next;    /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    T_IP6_HEADER ip6;           /* IPv6 header (without option data) */
    T_UDP_HEADER udp;           /* UDP header */
    UB *data;                   /* pointer to UDP data + IP header */
} T_UDP6_PKT;
#endif

/* Options */

#define UDP_UNICAST   0x0000
#define UDP_BROADCAST 0x0001
#define UDP_MULTICAST 0x0002
#define UDP_USE_RMSG  0x0004
#define UDP_BROADDHCP 0x0010    /* subnet-broadcast for DHCP */
#define UDP_REUSEPORT 0x0020    /* allow CEPs with duplicate IP address and port */

/* UDP Communication End Point Control Block */

typedef struct t_udp_rpkt {
    T_NIF *nif;
} T_UDP_RPKT;

typedef struct t_udp_cep {
    struct t_udp_cep *next;     /* pointer to next block */
    UB tos;                     /* IP TOS value used for this CEP connections */
    UB ttl;                     /* IP TTL value used for this CEP connections */
    UB mode;                    /* MCAST_INCLUDE or MCAST_EXCLUDE */
  #ifdef DUAL_STK
    UB type;                    /* address type */
  #else
    UB pad1;
  #endif
    UH portno;                  /* port number */
    UH cepid;                   /* UDP communication end point ID */
    UH options;                 /* option flag */
    UH id_udp_mbx;
    UH id_udp_mpf;
    UH pad2;
    UW ipaddr;                  /* IP address */
    T_UDP_PKT *pkt;
    TCP_CALLBACK callback;      /* function pointer to callback */
    T_NIF *nif;                 /* pointer to network interface control block */
    T_UDP_RPKT rmsg;            /* information of incoming packet */
    UB d_ipaddr[4];             /* directed-broadcast ip address */
    UB d_ipmask[4];             /* directed-broadcast ip mask */
    ER ercd;                    /* status of the interface */
  #ifdef DUAL_STK
    UW ip6addr[4];              /* IPv6 address */
    UW m_ip6addr[4];            /* IPv6 multicast address */
    T_MLD2_SRC *src_list;       /* source list */
  #endif
} T_UDP_CEP;

/* UDP Reception Packet */

typedef struct t_udp_rcv {
    struct t_udp_rcv *next;     /* queuing pointer for mailbox internal use */
    T_IPEP *p_dstaddr;
    ER *p_ercd;
    VP buf;
    UH len;
    UH tskid;
} T_UDP_RCV;

/*****************************************************************************/
/* Definitions for TCP                                                       */
/*****************************************************************************/

/* Constants */

#define TCP_MTU4        (ETHERNET_MTU - IP4_HEADER_SZ - TCP_HEADER_SZ)

#ifdef DUAL_STK
#ifdef IPSEC
#define TCP_MTU6        (ETHERNET_MTU - IP6_HEADER_SZ - TCP_HEADER_SZ - 68)
#else
#define TCP_MTU6        (ETHERNET_MTU - IP6_HEADER_SZ - TCP_HEADER_SZ)
#endif
#endif

#define KTIME_PRES  MSEC2TICK(1000) /* keep alive timer precision */

/* Flags */

#define FIN_FLAG        0x01    /* finish flag */
#define SYN_FLAG        0x02    /* synchronize flag */
#define RST_FLAG        0x04    /* reset flag */
#define PSH_FLAG        0x08    /* push flag */
#define ACK_FLAG        0x10    /* acknowledgement flag */
#define URG_FLAG        0x20    /* urgent flag */

/* TCP Header */

typedef struct t_tcp_header {
    UH sp;                      /* source port number */
    UH dp;                      /* destination port number */
    UW seq;                     /* sequence number */
    UW ack;                     /* acknowledgment number */
    UH flag;                    /* header length (data offset), flags */
    UH win;                     /* window size */
    UH cs;                      /* checksum */
    UH urgp;                    /* urgent pointer */
                                /* option */
} T_TCP_HEADER;

#define TCP_HEADER_SZ   ((int) sizeof (T_TCP_HEADER)) /* 20 */

/* TCP Packet */

typedef struct t_tcp_pkt {
    struct t_tcp_pkt *next;     /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    T_IP4_HEADER ip;            /* IPv4 header (without option data) */
    T_TCP_HEADER tcp;           /* TCP header */
    UB data[TCP_MTU4];          /* TCP data */
} T_TCP_PKT;

#ifdef DUAL_STK
typedef struct t_tcp6_pkt {
    struct t_tcp6_pkt *next;    /* queuing pointer for mailbox internal use */
    T_CTL_HEADER ctl;           /* header for internal control */
    T_ETH_HEADER eth;           /* Ethernet header */
    T_IP6_HEADER ip6;           /* IPv6 header (without option data) */
    T_TCP_HEADER tcp;           /* TCP header */
    UB data[ETHERNET_MTU-IP6_HEADER_SZ-TCP_HEADER_SZ]; /* TCP data */
} T_TCP6_PKT;
#endif

/* TCP/IP Configuration Information */

typedef struct t_tcp_cfg {
    UH tcp_repid_max;           /* maximum number of TCP REP ID */
    UH tcp_cepid_max;           /* maximum number of TCP CEP ID */
    UH udp_cepid_max;           /* maximum number of UDP CEP ID */
    UH raw_cepid_max;           /* maximum number of RAW CEP ID */
    UH tcp_tskid_top;           /* top number of task ID */
    UH tcp_semid_top;           /* top number of semaphore ID */
    UH tcp_mbxid_top;           /* top number of mailbox ID */
    UH tcp_mpfid_top;           /* top number of fixed memory pool ID */
    UH arp_table_cnt;           /* count of ARP table */
    UH arp_nif_cnt;             /* max number of interfaces using ARP table */
    UH route_table_cnt;         /* count of IPv4 routing table entries */
    UH tcp_ephem_port;
    UH eth_qcnt;                /* send/receive queue count */
    UH tcp_syn_ret;             /* max of TCP SYN retransmission */
    UH tcp_dat_ret;             /* max of TCP data retransmission */
    UH tcp_rto_ini;             /* TCP initial retransmission timeout */
    UH tcp_rto_ubound;          /* TCP max retransmission timeout */
    UH tcp_rto_lbound;          /* TCP min retransmission timeout */
    UH tcp_ktime_ini;           /* TCP initial keep alive timeout */
    UH tcp_ktime_pro;           /* TCP total timeout for keep alive probe */
    UH tcp_ktime_suc;           /* TCP keep alive probe interval */
    UH tcp_dack_tmo;            /* TCP delay ACK timeout */
    UH tcp_dup_ack;             /* TCP duplicate ACK count */
    UH arp_ret_intval;          /* ARP request retransmission timeout */
    UH ip_def_ttl;              /* TTL value for IP packets */
    UH ip_reasm_tmo;            /* IP reassembly process timeout */
    UH neigh_cache_cnt;         /* count of neighbor cache table */
    UH prefix_list_cnt;         /* count of prefix list */
    UH def_rtr_cnt;             /* count of default router list */
    UH dst_cache_cnt;           /* count of destination cache table */
    UH route6_table_cnt;        /* count of IPv6 routing table entries */
    UH ip6_reasm_tmo;           /* IPv6 reassembly process timeout */
    UH dad_tmo;                 /* duplicate address detection timeout */
    UH igmp_group_cnt;          /* multicast group count */
    UH igmpv1_present_tmo;      /* IGMPv1 router present timeout */
    UH max_ipsec_entries;       /* count of entries in IPsec database */
    UH addr_conf;
    UH mld2_src_cnt;            /* max number of MLDv2 sources */
    UH igmp3_src_cnt;           /* max number of IGMPv3 sources */
    UH igmp3_adr_cnt;           /* max number of IGMPv3 addresses */
    UW arp_cache_tout;          /* ARP cache timeout */
    UW arp_flush_tout;          /* ARP flush timeout */
    UW icmp_du_rate;            /* rate of ICMP destination unreachable reply */
} T_TCP_CFG;

/* TCP Reception Point Control Block */

typedef struct t_tcp_rep {
    struct t_tcp_rep *next;     /* pointer to next block */
    UW ipaddr;                  /* IP address */
    UH portno;                  /* port number (0:REP not created) */
    UH repid;                   /* TCP reception point ID */
  #ifdef DUAL_STK
    UW ip6addr[4];              /* IPv6 address */
    UB type;                    /* address type */
    UB pad1;
    UH pad2;
  #endif
} T_TCP_REP;

/* Configurable Entities for TCP Timeout/Retransmission */

typedef struct t_tcp_tmo {
    UH syn_rcnt;                /* max of TCP SYN retransmission [number of retry count] */
    UH dat_rcnt;                /* max of TCP data retransmission [number of retry count] */
    UW rto_ini;                 /* TCP initial retransmission timeout [TMO(=msec/MSEC)] */
    UW rto_min;                 /* TCP max retransmission timeout [TMO(=msec/MSEC)] */
    UW rto_max;                 /* TCP min retransmission timeout [TMO(=msec/MSEC)] */
    UW ktime_tmo;               /* TCP initial keep alive timeout [msec] */
    UW ktime_pro;               /* TCP keep alive probing timeout [msec] */
    UW ktime_suc;               /* TCP keep alive probe interval [msec] */
} T_TCP_TMO;

/* TCP Retransmission Structure */

typedef struct t_tcp_retrans{
    UW srtt;                    /* smooth round trip time */
    UW rttvar;                  /* round trip time variance */
    UW rto;                     /* retransmission timeout value for next segment */
    UW seq;                     /* sequence number of retransmitting segment */
    UW rtime;                   /* used for rtt calculation */
    UW retries;                 /* number of retransmission occured */
    UW retry_cnt;               /* max number of retransmission allowed */
#define TCP_RET_ON        0x01  /* TCP timer ON */
#define TCP_RET_SEQ_VALID 0x02  /* SEQ valid */
    B stat;                     /* status of retransmission */
    B ref;
    UH flag;                    /* used to avoid retransmission of ACK segment */
    UH on;
    UH pad;
    UW rseq;
} T_TCP_RETRANS;

/* TCP Connection State */

#define CEP_UNUSED       0x01   /* unused */
#define CEP_WAIT_P_OPEN  0x02   /* waiting for passive open */
#define CEP_WAIT_A_OPEN  0x04   /* waiting for active open */
#define CEP_CONNECTING   0x10   /* connecting */
#define CEP_TERMINATED   0x20   /* terminated (FIN sent) */
#define CEP_DISCONNECTED 0x40   /* disconnected (RST received) */
#define CEP_CLOSING      0x08   /* closing */
#define CEP_CLOSED       0x80   /* closed */

#define IS_CREATED(s)   ((s) != 0)
#define IS_USED(s)      ((s) > CEP_UNUSED)

/* Delay ACK Flags */

#define TCP_ACK_DELAY   0x01
#define TCP_ACK_NOW     0x02
#define TCP_ACK_OUTD    0x04
#define TCP_ZERO_PROBE  0x08

/* Time Stamp Option */

#define TSOPT_REQUEST   0x01
#define TSOPT_ENABLE    0x02

/* TCP Communication End Point Control Block */

typedef struct t_tcp_cep {
    struct t_tcp_cep *next;     /* pointer to next block */
    UB state;                   /* TCP connection state */
    UB sflag;                   /* sending flags */
    UB rflag;                   /* received flags */
    UB hseq;                    /* max sent SEQ number in 'hsqn' is valid */
    UB dackcnt;                 /* number of delay ACK received */
    UB dackflag;                /* delay ACK flag */
    UB tos;                     /* IP TOS value used for this CEP connections */
    UB ttl;                     /* IP TTL value used for this CEP connections */
    UB dackmd;                  /* receive ACK of retransmit packet */
    UB tsopt;                   /* time stamp option */
    UB qlack;                   /* lack of memory to queue Ethernet frames */
  #ifndef DUAL_STK
    UB pad1;
    UH pad2;
  #else
    UB type;                    /* address type */
    UH pad2;
  #endif
    UH portno;                  /* local port number */
    UH dstpor;                  /* remote port number */
    UH repid;                   /* TCP reception point ID */
    UH cepid;                   /* TCP communication end point ID */
    UH stskid;                  /* send waiting task ID */
    UH rtskid;                  /* receive waiting task ID */
    UH win0;                    /* initial remote window size */
    UH win;                     /* window size */
    UH win1;                    /* current remote window size */
    UH sgeti;                   /* index of send buffer to get */
    UH sputi;                   /* index of send buffer to put */
    UH rgeti;                   /* index of receive buffer to get */
    UH rputi;                   /* index of receive buffer to put */
    UH seqi;                    /* index of send buffer to retransmit */
    UH sbufsz;                  /* size of sending window buffer */
    UH rbufsz;                  /* size of receiving window buffer */
    H dcls_id;                  /* delayed send FIN */
    UW ipaddr;                  /* local IP address */
    UW dstipa;                  /* remote IP address */
    UW mss;                     /* max transmission segment size */
    UW isn;                     /* local init sequence number */
    UW seq;                     /* local sequence number */
    UW seq1;                    /* ACK number received last time */
    UW mseq;                    /* max sequence TCP has send */
    UW risn;                    /* remote init sequence number */
    UW rseq;                    /* remote sequence number (ACK number) */
    UB *sbuf;                   /* top address of sending window buffer */
    UB *rbuf;                   /* top address of receiving window buffer */
    UW sgetp;                   /* send buffer get pointer */
    UW sputp;                   /* send buffer put pointer */
    UW rgetp;                   /* receive buffer get pointer */
    UW rputp;                   /* receive buffer put pointer */
    UW tmout;                   /* timeout time */
    FN sfncd;                   /* send function code */
    FN rfncd;                   /* receive function code */
    INT slen;
    INT rlen;
    VP spar;
    VP rpar;
    TCP_CALLBACK callback;      /* function pointer to callback */
    UW time;                    /* retry time */
    T_TCP_PKT *ackpkt;          /* sending ACK packet */
    UW dtime;                   /* delay ACK time */
    T_NIF *nif;                 /* pointer to network interface control block */
    T_NIF *unif;                /* user defined interface */
    UW hsqn;                    /* max sent SEQ number when retransmission occurs */
    UW sgetpf;                  /* sequence of first delay ACK */
    UW cwnd;                    /* congestion window size */
    UW ssth;                    /* slow start threshold value */
    T_TCP_TMO tmo;              /* used for timeout/retransmission */
    T_TCP_RETRANS retry;        /* used for retransmission */
    UW ktime;                   /* keep alive time */
    UW itime;                   /* connection idle time */
    UW umtu;                    /* user defined TCP MTU */
    W smax;                     /* usuable window size */
    ER ercd;                    /* status of interface */
    UW tsecr;
  #ifdef DUAL_STK
    UW ip6addr[4];              /* local IPv6 address */
    UW dst6ipa[4];              /* remote IPv6 address */
  #endif
} T_TCP_CEP;

/*****************************************************************************/
/* Definitions for IGMP                                                      */
/*****************************************************************************/

/* Constants */

#define IGMP_UNSOL_DLY  2       /* retransmit delay for unsolicited report */

/* IGMP Types */

#define IGMP_UNUSED     0x00
#define IGMP_INQUERY    0x11
#define IGMP_REPORT     0x12
#define IGMPV2_REPORT   0x16
#define IGMPV2_LEAVE    0x17

/* IGMP Message */

typedef struct t_igmp_msg {
    UB type;                    /* IGMP type */
    UB rpt;                     /* IGMPv2 report time */
    UH cs;                      /* checksum */
    UW group;                   /* group address */
} T_IGMP_MSG;

/* IGMPv3 Group Record */

typedef struct t_igmp3_rec {
    UB rec_type;                /* record type */
    UB aux_dat_len;             /* auxiliary data length */
    UH num_src;                 /* number of sources */
    UW group;                   /* multicast address */
} T_IGMP3_REC;

/* IGMPv3 Types */

#define IGMPV3_REPORT   0x22
#define IGMPV3_QUERY    0x11

/* IGMPv3 Report Message */

typedef struct t_igmp3_rep {
    UB type;                    /* IGMPv3 type */
    UB res1;                    /* reserved */
    UH cs;                      /* checksum */
    UH res2;                    /* reserved */
    UH num_rec;                 /* number of records */
} T_IGMP3_REP;

/* IGMPv3 Query Message */

typedef struct t_igmp3_qry {
    UB type;                    /* IGMPv3 type */
    UB mrc;                     /* IGMPv3 max response code */
    UH cs;                      /* checksum */
    UW group;                   /* group address */
    UB info;                    /* resv, S flag, querier robustnes value */
    UB qqic;                    /* querier`s query interval code */
    UH numsrc;                  /* number of sources */
    UW saddr[1];                /* source addresses */
} T_IGMP3_QRY;

/* Argument Structure for IP_ADD_MEMBERSHIP and IP_DROP_MEMBERSHIP */

typedef struct t_ip_mreq {
    UW imr_multiaddr;           /* IP multicast address of group */
    UW imr_interface;           /* local IP address of interface */
} T_IP_MREQ;

/* IGMPv3 Group-Source List Structure for User Input in udp_set_opt() */

typedef struct t_igmp3_usl {
    T_IPEP *mgrp_addr;          /* IGMP multicast group address */
    UW num_src;                 /* number of sources in source list */
    UW *src_list;               /* pointer to source list */
} T_IGMP3_USL;

/* Multicast Group Control Block */

typedef struct t_mgrp_cb {
    T_NIF *nif;                 /* interface to bind */
    T_NIF *tif;                 /* interface used for transmission */
    T_UDP_CEP *cep;             /* pointer to UDP control end point */
    UW ipaddr;                  /* IP address */
    T_IGMP3_SRC *igmp_slist;    /* IGMPv3 source list */
    UH portno;                  /* port number */
    UH rptime;                  /* time elapse to send report */
    UB mode;                    /* MCAST_INCLUDE or MCAST_EXCLUDE */
} T_MGRP_CB;

/* Common to MLDv2 and IGMPv3 */

#define NOT_APPLICABLE                      0
#define PEND_RESP_GRP_SPECIFIC_QUERY        1
#define PEND_RESP_GRP_SRC_SPECIFIC_QUERY    2
#define QUERIED                             1
#define NOT_QUERIED                         0
#define NOT_IN_USE                          0
#define MODE_IS_INCLUDE                     1
#define MODE_IS_EXCLUDE                     2
#define ALLOW_NEW_SOURCES                   5
#define BLOCK_OLD_SOURCES                   6
#define ALLOW                               1
#define BLOCK                               2
#define CHANGE_TO_INCLUDE_MODE              3
#define CHANGE_TO_EXCLUDE_MODE              4

/*****************************************************************************/
/* Definitions for MLD                                                       */
/*****************************************************************************/
#ifdef DUAL_STK

#define max_rsp_dly     icmpv6.info.mld.max_resp_dly

/* MLD Messages */

typedef struct t_mld_msg {
    T_ICMPV6_HEADER icmpv6;
    UW mcast_addr[4];
} T_MLD_MSG;

/* MLDv2 Query */

typedef struct t_mld2_query {
    T_ICMPV6_HEADER icmpv6;
    UW maddr[4];
    UB info;                    /* this field contains bit fields queriers robust value, */
                                /* suppress value and reserved value */
    UB qqic;
    UH numsrc;
    UW saddr[1][4];
} T_MLD2_QUERY;

/* MLDv2 Messages */

typedef struct t_mld2_rec {
    UB rec_type;                /* this can be MODE_IS_INCLUDE/MODE_IS_EXCLUDE/CHANGE_*/
                                /* TO_INCLUDE/CHANGE_TO_EXCLUDE/ALLOW_NEW_SOURCES/BLOCK_OLD_SOURCES */
    UB aux_dat_len;             /* not yet defined its value is always zero */
    UH num_src;                 /* indicates the number of sources the record contains */
    UW maddr[4];                /* multicast address to which the record corresponds to */
} T_MLD2_REC;

#endif
/*****************************************************************************/
/* TCP/IP Stack Internal Functions                                           */
/*****************************************************************************/

/* Error Handling */

#ifdef DEBUG
void trouble_shooter(ER, char *, int);
#define tcpip_internal_error(er)  trouble_shooter(er, __FILE__, __LINE__)
#define tcp_internal_error(er)    trouble_shooter(er, __FILE__, __LINE__)
#define arp_internal_error(er)    trouble_shooter(er, __FILE__, __LINE__)
#define ip_internal_error(er)     trouble_shooter(er, __FILE__, __LINE__)
#define udp_internal_error(er)    trouble_shooter(er, __FILE__, __LINE__)
#define icmp_internal_error(er)   trouble_shooter(er, __FILE__, __LINE__)
#define raw_internal_error(er)    trouble_shooter(er, __FILE__, __LINE__)
#else
ER tcpip_internal_error(ER);
ER tcp_internal_error(ER);
ER arp_internal_error(ER);
ER ip_internal_error(ER);
ER udp_internal_error(ER);
ER icmp_internal_error(ER);
ER raw_internal_error(ER);
#endif

/* Common Functions */

ER tcpip_critical(BOOL, PRI *);
void remove_queued_packet(ID, T_ETH *, VP);
BOOL remove_sndque_udppkt(ID, T_ETH *, VP, ER);
void remove_rcvque_udppkt(ID, VP);
BOOL remove_mbx_pkt(ID, T_ETH *, VP, T_ETH *);
BOOL remove_sndque_rawpkt(ID, T_ETH *, VP, ER);
void remove_rcvque_rawpkt(ID, VP);
W ring_sub(UW, UW);

/* Network I/F Functions */

BOOL is_same_network(T_NIF *, UW);
BOOL chk_ip_nif(T_NIF *, UW);
B is_nif_exists(T_NIF *);
#ifdef DUAL_STK
ER ipv6_ini(T_NIF *);
BOOL is_same_network6(T_NIF *, const UW *);
BOOL chk_ip6_nif(T_NIF *, const UW *);
ER ipv6_ini_cyc(RELTIM, RELTIM);
ER ipv6_sta_cyc(void);
void ipv6_tmr_tsk(void);
TASK ipv6_cyc_tsk(void);
void ipv6_free_rsrc(void);
#endif

/* RAW Communication Functions */

VP raw_reception(T_RAW_PKT *, UH);
BOOL raw_check_protocol(UH, UH);
BOOL is_raw_pkt(T_RAW_PKT *, UH);

/* ARP Functions */

void nif_ini_arp(T_NIF *);
ER ref_arp_table(T_NIF *, UB *, UW);
ER ref_macaddr(T_NIF *, UB *, UW);
void set_arp_table(T_NIF *, UW, const UB *);
VP arp_reception(T_ARP *);
BOOL arp_request(T_NIF *, UW);
void val_arp_table(void);
void ini_route_table(void);

ER arp_def_cbk(T_ARP_CB *, ARP_CALLBACK);
ER arp_rel_pkt(T_ARP *);

/* IP Functions */

void tcpip_timer_func(void);
void wup_snd_tsk(T_NIF *);
void arp_retry_over(T_NIF *, UW);

TASK ip_snd_tsk(int);
TASK ip_rcv_tsk(int);
ER ip_def_cbk(T_IP_CB *, IP_CALLBACK);
UH ip_opt_checksum(T_IP4 *, UH *);
T_CTL_PKT *net_get_transmission_pkt(T_NIF *);
void net_set_transmission_pkt(T_NIF *, T_CTL_PKT *);

/* IPv4 Functions */

BOOL is_nif_ipaddr(T_NIF *, UW);
BOOL is_my_ipaddr(T_NIF *, UW, UW);
BOOL is_broadcast(T_NIF *, UW);

/* IP Reassembly Internal Functions */

void reass_ini(void);
BOOL receive_all_frag(T_IPF *);
BOOL get_reassembly_data(VP, T_IPF *, UH, UH);
BOOL get_reassembly_buffer(T_IPF *, UH, VP *, UH *);
void deq_frag_list(T_IPF *);
void clr_frag_list(T_IPF *, BOOL);
void ip_evictor(void);
void release_ipf_que(T_NIF *);
void ip_frag_timeout(void);
T_IP4 *ip_reassembling(T_IP4 *);
T_IP4 *icmp_reception(T_IP4 *);

#ifdef DUAL_STK
void reass6_ini(void);
BOOL get_reassembly6_data(VP, T_IPF *, UH, UH);
BOOL get_reassembly6_buffer(T_IPF *, UH, VP *, UH *);
void ip6_evictor(void);
void release_ip6f_que(T_NIF *);
void ip6_frag_timeout(void);
T_IP6 *ip6_reassembling(T_IP6 *, BOOL *);
T_IP6 *ip6_frag_pkt(T_NIF *, T_IP6 *);
T_IP6 *icmpv6_reception(T_IP6 *);
VP ip6_reception(T_IP6 *);
BOOL ip_set_hdr6(T_NIF *, T_IP6 **, T_DATA *, int *);
UH ip6_set_hophdr(UB *, UB, UH, UB);
#endif

/* ICMP Functions */

ER icmp_def_cbk(T_ICMP_CB *, ICMP_CALLBACK);
ER icmp_snd_dat(UW, UW, T_ICMP_HEADER *, VP, INT);
ER icmp_can_snd(T_ICMP_HEADER *);
ER icmp_snd_data(UW, UW, T_ICMP_HEADER *, VP, INT);

/* IPv6 Functions */

#ifdef DUAL_STK
void set_ip6_addr(UW *, const UW *);
BOOL is_ip6_addr_any(const UW *);
VP is_myip6addr(T_NIF *, UW *);
INT is_tentative(T_NIF *, UW *);
ER addr_ipv6_conf(T_NIF *);
void dad_proc(T_UADDR *);
VP update_addr(T_NIF *, UW *, UH, B);
UW *set_src_addr(T_NIF *, const UW []);
UW* get_lladdr(T_NIF *);
T_NIF *ipv6_get_first_nif(void);    /* PPP does not support IPv6 */
T_NIF *ipv6_get_next_nif(T_NIF *);  /* " */
ER ipv6_check_nif(T_NIF *);         /* " */
#ifdef DEBUG
#define ip6_internal_error(er)  trouble_shooter(er, __FILE__, __LINE__)
#else
ER ip6_internal_error(ER);
#endif
BOOL addr_resolve(T_NIF *, UW [], UW *);
void set_nxt_hop(T_NIF *, UW []);

/* ICMPv6 Functions */

BOOL router_sol_output(T_NIF *, UW *);
BOOL neigh_sol_output(T_NIF *, UW *, UW *, UW *);
BOOL neigh_adv_output(T_NIF *, UW *, UW *, T_NEIGH_SOL_MSG_FIXED *, UB);
T_IP6 *neigh_sol_input(T_IP6 *, UW);
T_IP6 *neigh_adv_input(T_IP6 *, UW);
T_IP6 *router_adv_input(T_IP6 *, UW);
T_IP6 *redirect_input(T_IP6 *, UW);
void router_detect(T_NIF *);
void del_dst_cache(T_NIF *, UW []);
T_NEIGH_CACHE *ref_neigh_cache(UW []);
T_NEIGH_CACHE *update_neigh_cache(T_NIF *, UW [], UB [], UB, BOOL);
ER icmpv6_def_cbk(T_ICMP6_CB *, ICMP6_CALLBACK);
ER icmpv6_snd_dat(UW *, UW *, T_ICMPV6_HEADER *, VP, int);
ER icmpv6_internal_snd(UW *, UW *, T_ICMPV6_HEADER *, VP, int);
ER icmpv6_snd_out(T_NIF *, UW *, UW *, T_ICMPV6_HEADER *, VP, int);
UH icmpv6_chksum(T_IP6 *, B *, UH);
ER icmpv6_can_snd(T_ICMPV6_HEADER *, T_NIF *);
#endif

/* UDP Functions */

VP udp_reception(T_UDP_PKT *);

/* TCP Functions */

INT tcp_put_sdat(T_TCP_CEP *, const UB *, INT);
INT tcp_get_sbuf(UB **, T_TCP_CEP *);
ER tcp_put_sbuf(T_TCP_CEP *, INT);
INT tcp_get_rdat(UB *, T_TCP_CEP *, INT);
INT tcp_get_rbuf(UB **, T_TCP_CEP *);
ER tcp_rel_rbuf(T_TCP_CEP *, INT);
VP tcp_reception(T_TCP_PKT *);
void tcp_transmit(T_TCP_CEP *);
void tcp_transmit_ack(T_TCP_CEP *);
void tcp_recover_retrans(void);
void tcp_timeout_process(T_TCP_CEP *);
void tcp_timeout_update(T_TCP_CEP *);
ER tcp_can_cep2(T_TCP_CEP *, FN);
BOOL can_ack_delay(W, T_TCP_CEP *, T_TCP_PKT *);
void tcp_cep_unused(T_TCP_CEP *);
void tcp_cep_ktime_init(T_TCP_CEP *);
void tcp_cep_set_default_opt(T_TCP_CEP *, T_NIF *);

/* IGMP Functions */

T_IP4 *igmp_reception(T_IP4 *);
ER igmp_snd_dat(UB, ID, UW, UW, UW);
int search_igmp_group(T_NIF *, T_IPV4EP *);
void clr_mgrp_cb(T_UDP_CEP *);
BOOL search_igmp_ip(T_NIF *, UW, UW);
void leave_igmp_group(T_MGRP_CB *);
void send_igmp_report(T_MGRP_CB *);
void check_igmp_tmo(void);

ER igmp3_util_chksrc(T_IGMP3_SRC *, UW);
ER igmp3_if_jgrp(T_NIF *, T_MGRP_CB *);
ER igmp3_if_upgrp(T_NIF *, UW, UW, T_IGMP3_SRC *);
ER igmp3_if_lgrp(T_NIF *, T_MGRP_CB *);
T_IP4 *igmp3_reception(T_IP4 *);
void igmp3_tmr_check(void);
ER igmp3_free_src(T_IGMP3_SRC *);
ER igmp3_ini(T_NIF *);
ER igmp3_rel_addrlist(T_NIF *);
ER igmp3_setv2_mod(T_NIF *);

/* MLD Functions */

#ifdef DUAL_STK
void set_sol_maddr(UW *, UW *);
void set_all_maddr(UW *);
BOOL is_all_ll_mcast(UW *);
ER join_all_mcast(T_NIF *);
ER join_sol_mcast(T_NIF *, UW *);
ER mld_join_group(T_NIF *, UW *);
ER mld_leave_group(T_NIF *, UW *);
void mld_query_input(T_IP6 *);
T_IP6 *mld_report_input(T_IP6 *, UW);
void mld_tmr_check(T_NIF *);
ER mld_add(T_NIF *, T_MADDR *);
ER mld_remove(T_NIF *, T_MADDR *);
ER mld2_join_all_mcast(T_NIF *);
ER mld2_leave_sol_mcast(T_NIF *, UW *);
ER mld2_snd_curr_report(T_NIF *, T_MADDR *);
ER mld2_snd_state_change_report(T_NIF *, T_MADDR *);
ER mld2_snd_curr_report_all(T_NIF *);
ER mld2_join_group(T_NIF *, UW *);
ER mld2_join_sol_mcast(T_NIF *, UW *);
ER mld2_set_filter(T_NIF *, UW *, UB, T_MLD2_SRC *);
ER mld2_leave_group(T_NIF *, UW *);
ER mld2_free_src(T_MLD2_SRC *);
T_IP6 *mld2_query_input(T_IP6 *, UW);
void mld2_tmr_check(T_NIF *, UH);
void get_updted_info(T_NIF *, UW *, UH *, T_MLD2_SRC **);
T_MLD2_SRC *prepare_list(T_NIF *, T_UDP_CEP *, UH, UH *);
UH get_final_mode(T_NIF *, UW *, UH *);
UH check_cep_entry(ID);
ER update_cep_entry(ID, UH, UW *, INT);
#endif

/* SNMP Functions */

#ifdef SNMP
#define INCLUDED_FROM_NOSNMP
#include "nonsnmp.h"
#include "nonsnmpc.h"
#define SNMP_UPD_IF(p,c)                      snmp_upd_if(p,c)
#define SNMP_UPDNTM(t,i,n,p)                  snmp_upd_ip_ntm(t,i,n,p)
#ifndef DUAL_STK
#define SNMP_UPDTCP(s,la,lp,ra,rp)            snmp_upd_tcp(s,la,lp,ra,rp)
#define SNMP_UPDUDP(s,a,p)                    snmp_upd_udp(s,a,p)
#else
#define SNMP_UPD_TCPLISTEN(s,t,a,p)           snmp_upd_tcp_listener(s,t,a,p)
#define SNMP_UPDTCP(s,lt,la,lp,rt,ra,rp,p)    snmp_upd_tcp(s,lt,la,lp,rt,ra,rp,p)
#define SNMP_UPDUDP(s,lt,la,lp,rt,ra,rp,i,p)  snmp_upd_udp(s,lt,la,lp,rt,ra,rp,i,p)
#define SNMP_MLD_QUERIER_UPD(o,i,v)           snmp_set_mib_mldinterfacetbl(o,i,v);
#define SNMP_UPDNTM_IPV6(t,a,p,s,l,v,i)       snmp_upd_ipv6_ntm(t,a,p,(SNMP_NTMSTATE)s,l,v,i)
#define SNMP_UPD_MLD_CACHE(t,a,i,v,s)         snmp_upd_mld_cache(t,a,i,v,s)
#define SNMP_UPD_IPV6ATBL(in,ix,a,l,t,f,s)    snmp_upd_ipv6_addrtable(in,ix,a,l,t,f,s)
#define SNMP_UPD_IPV6APRFTBL(i,x,p,l,o,a,t,v) snmp_upd_ipv6prefixTable(i,x,p,l,(SNMP_TRUEVALUE)o,(SNMP_TRUEVALUE)a,t,v)
#endif
#define SNMP_BYPCNT(t,v)   do { if (snmp_mib.iniflg == SNMP_FLG_INIT) (*(t)) = (*(t)) + (v); } while (0)
#define SNMP_BYPDEC(t,v)   do { if (snmp_mib.iniflg == SNMP_FLG_INIT) (*(t)) = (*(t)) - (v); } while (0)
#define SNMP_BYPASG(t,v)   do { if (snmp_mib.iniflg == SNMP_FLG_INIT) (*(t)) = (v); } while (0)
#define SNMP_BYPCNT64(t,v) do { if (snmp_mib.iniflg == SNMP_FLG_INIT) \
                                    if (((t)->l_cnt = (t)->l_cnt + (v)) < (v)) \
                                        ++(t)->u_cnt; \
                           } while (0)
#else
#define SNMP_UPD_IF(p,c)
#define SNMP_UPDNTM(t,i,n,p)
#ifndef DUAL_STK
#define SNMP_UPDTCP(s,la,lp,ra,rp)
#define SNMP_UPDUDP(s,a,p)
#else
#define SNMP_UPD_TCPLISTEN(s,t,a,p)
#define SNMP_UPDTCP(s,lt,la,lp,rt,ra,rp,p)
#define SNMP_UPDUDP(s,lt,la,lp,rt,ra,rp,i,p)
#define SNMP_MLD_QUERIER_UPD(o,i,v)
#define SNMP_UPDNTM_IPV6(t,a,p,s,l,v,i)
#define SNMP_UPD_MLD_CACHE(t,a,i,v,s)
#define SNMP_UPD_IPV6ATBL(in,ix,a,l,t,f,s)
#define SNMP_UPD_IPV6APRFTBL(i,x,p,l,o,a,t,v)
#endif
#define SNMP_BYPCNT(t,v)
#define SNMP_BYPDEC(t,v)
#define SNMP_BYPASG(t,v)
#define SNMP_BYPCNT64(t,v)
#endif /* SNMP */

#ifdef __cplusplus
}
#endif
#endif /* NONETS_H */
