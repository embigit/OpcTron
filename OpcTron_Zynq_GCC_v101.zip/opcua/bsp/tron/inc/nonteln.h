/******************************************************************************
* Telnet Server/Client Header                                                 *
******************************************************************************/

#ifndef NONTELN_H
#define NONTELN_H
#ifdef __cplusplus
extern "C" {
#endif

/* Customization Macros */

#define TELNETD_PRI     5       /* Telnet server task priority */
#define SHELL_PRI       5       /* command shell task priority */
#ifndef TELNETD_SSZ
#define TELNETD_SSZ     592     /* Telnet server task stack size */
#endif
#ifndef SHELL_SSZ
#define SHELL_SSZ       2048    /* command shell task stack size */
#endif

#define LOGIN_NAME_LEN   10     /* login name maximum length */
#define PASSWORD_LEN     10     /* password maximum length */
#define COMMAND_LINE_LEN 80     /* command line maximum length */

#define TELNETD_SBUFSZ  256     /* sending window buffer size */
#define TELNETD_RBUFSZ  256     /* receiving window buffer size */

/* Telnet Server Control Block */

typedef struct t_telnetd T_TERMINAL;

typedef struct t_telnetd {
    BOOL (*term_print)(T_TERMINAL *, const char *);
    INT (*term_getch)(T_TERMINAL *);
    UH telnetd_tskid;
    UH shell_tskid;
    UH rx_mbfid;
    B logged_in;
    B echo_on;
    FP sigint;
    FP passwd_check;
    TMO tmo;
    const char *prompt;
    UH cepid;
    UH repid;
    T_IPV4EP dstaddr;
    UH sbuf[TELNETD_SBUFSZ/2];  /* sending window buffer */
    UH rbuf[TELNETD_RBUFSZ/2];  /* receiving window buffer */
} T_TELNETD;

extern T_TERMINAL *current_terminal;

/* Command Processing Routine Implemented in User Program */

BOOL telnetd_callback(T_TERMINAL *, char *);

/* Telnet Client Functions */

int telnet_command(int, char **);
int telnet6_command(int, char **);

/* Command Shell Functions */

ER shell_ini(VP, ID, ID, FP);
#define shell_ini(t,i,m,f) (shell_ini)(t,i,m,(FP)(f))
void shell_ext(VP);
BOOL login_proc(T_TERMINAL *, char *, char *, FP);

/* Telnet Server Functions */

ER telnetd_ini(T_TELNETD *, ID, ID, ID, ID, int);
#define telnetd_ini(t,i,m,c,r)  (telnetd_ini)(t,i,m,c,r,4)
#define telnetd6_ini(t,i,m,c,r) (telnetd_ini)(t,i,m,c,r,6)
void telnetd_ext(T_TELNETD *);
BOOL telnetd_print(T_TELNETD *, const char *);
INT telnetd_input(T_TELNETD *, char *, INT);

/* Alternate Functions to stdio.h and conio.h */

BOOL terminal_puts(T_TERMINAL *, const char *);
BOOL terminal_rputs(T_TERMINAL *, const char *);
BOOL terminal_print(T_TERMINAL *, const char *);
INT terminal_input(T_TERMINAL *, char *, INT, TMO);
char *terminal_gets(T_TERMINAL *, char *, INT);
BOOL terminal_putch(T_TERMINAL *, INT);
INT terminal_getch(T_TERMINAL *);
BOOL terminal_kbhit(T_TERMINAL *);

#define puts(s)     terminal_puts(NULL,s)
#define rputs(s)    terminal_rputs(NULL,s)
#define print(s)    terminal_print(NULL,s)
#define input(s,n)  terminal_input(NULL,s,n,TMO_FEVR)
#define gets(s)     terminal_gets(NULL,s,sizeof(s))
#define putch(c)    terminal_putch(NULL,c)
#define getch()     terminal_getch(NULL)
#define kbhit()     terminal_kbhit(NULL)

/* Alternate Functions to signal.h */

typedef void (*SIGNAL_FUNC)(int);
SIGNAL_FUNC terminal_signal(T_TERMINAL *, int, SIGNAL_FUNC);
#define signal(s,f) terminal_signal(NULL,s,f)

#define CTRL_C      0x03             /* Ctrl-C character code */
#define SIGINT      2                /* Ctrl-C signal */
#define SIGBREAK    21               /* Ctrl-Break sequence */
#define SIG_DFL ((void(*)(int))0)    /* default signal action */
#define SIG_ERR ((void(*)(int))(-1)) /* represents a signal error */

/* Additional Functions to string.h for some Compilers */

int stricmp(const char *, const char *);
char *strlwr(char *);

#ifdef __cplusplus
}
#endif
#endif /* NONTELN_H */
