/******************************************************************************
* TCP/IP Protocol Stack Configuration Header                                  *
******************************************************************************/

#ifndef NONETC_H
#define NONETC_H
#ifdef __cplusplus
extern "C" {
#endif

#include "nonets.h"
#include "nosys4.h"

/* Network Object ID Definition */

#ifndef INCLUDED_FROM_NONET
#ifndef TCP_REPID_MAX
#define TCP_REPID_MAX       4
#endif
#ifndef TCP_CEPID_MAX
#define TCP_CEPID_MAX       4
#endif
#ifndef UDP_CEPID_MAX
#define UDP_CEPID_MAX       4
#endif
#ifndef RAW_CEPID_MAX
#define RAW_CEPID_MAX       0
#endif
#endif

/* RTOS Object Top ID Definition */

#ifndef INCLUDED_FROM_NONET
#ifndef TCP_TSKID_TOP
#define TCP_TSKID_TOP       0
#endif
#ifndef TCP_SEMID_TOP
#define TCP_SEMID_TOP       0
#endif
#ifndef TCP_MBXID_TOP
#define TCP_MBXID_TOP       0
#endif
#ifndef TCP_MPFID_TOP
#define TCP_MPFID_TOP       0
#endif
#endif

/* The Number of Object used in TCP/IP Protocol Stack */

#define TCP_NTSK            5
#define TCP_NSEM            1
#define TCP_NFLG            0
#define TCP_NMBX            (3+(UDP_CEPID_MAX))
#define TCP_NMBF            0
#define TCP_NPOR            0
#define TCP_NMPL            0
#define TCP_NMPF            (4+(UDP_CEPID_MAX))
#define TCP_NDTQ            0
#define TCP_NMTX            0
#define TCP_NISR            0
#define TCP_NCYC            2
#define TCP_NALM            0

/* Multicast Control Block */

#ifndef INCLUDED_FROM_NONET
#ifndef MULTICAST_GROUP_CNT
#define MULTICAST_GROUP_CNT 10
#endif
#endif

/* Constants to Create RTOS Object */

#ifndef INCLUDED_FROM_NONET
#ifndef PRI_IP_SND_TSK
#ifdef DUAL_STK
#define PRI_IP_SND_TSK      4
#else
#define PRI_IP_SND_TSK      4
#endif
#endif
#ifdef PRI_IP_RCV_TSK
#undef PRI_IP_RCV_TSK
#endif
#define PRI_IP_RCV_TSK      PRI_IP_SND_TSK
#ifndef SSZ_IP_SND_TSK
#ifdef IPSEC
#define SSZ_IP_SND_TSK      1304
#else
#define SSZ_IP_SND_TSK      1024
#endif
#endif
#ifndef SSZ_IP_RCV_TSK
#ifdef IPSEC
#define SSZ_IP_RCV_TSK      1304
#else
#define SSZ_IP_RCV_TSK      1024
#endif
#endif
#ifndef ETH_QCNT
#define ETH_QCNT            16
#endif
#ifndef UDP_QCNT
#define UDP_QCNT            2
#endif
#ifndef RAW_PKT_SND_CNT
#define RAW_PKT_SND_CNT     2
#endif

#ifndef MLD2_SRC_CNT
#define MLD2_SRC_CNT        32
#endif

#ifndef IGMP3_SRC_CNT
#define IGMP3_SRC_CNT       12
#endif

#ifndef IGMP3_ADR_CNT
#define IGMP3_ADR_CNT       6
#endif

#ifdef DUAL_STK
#ifndef PRI_IPV6_CYC_TSK
#define PRI_IPV6_CYC_TSK    4
#endif
#ifndef SSZ_IPV6_CYC_TSK
#define SSZ_IPV6_CYC_TSK    1024
#endif
#endif

#endif

#ifndef INCLUDED_FROM_NONET
#ifndef TCP_PORT_EPHEMERAL
#define TCP_PORT_EPHEMERAL  49152    /* Top Number of Ephemeral Port */
#endif
#endif

/*********************************************************************************/
/* TCP Retransmission:                                                          */
/*      TCP_RTO_INI     - Timeout Value used for retransmission before          */
/*                          rtt calculations. (secs)                            */
/*      TCP_RTO_LBOUND  - Minimum value of retransmission timeout (secs)        */
/*      TCP_RTO_UBOUND  - Maximum value of retransmission timeout (secs)        */
/*      TCP_SYN_RETRY   - No. of SYN retransmission before connection failure   */
/*      TCP_DATA_RETRY  - No. of Data and FIN retry                              */
/*********************************************************************************/

#ifndef INCLUDED_FROM_NONET
#ifndef TCP_SYN_RETRY
#define TCP_SYN_RETRY       3       /* 3 retry */
#endif
#ifndef TCP_DATA_RETRY
#define TCP_DATA_RETRY      12      /* 12 retry */
#endif
#ifndef TCP_RTO_INI
#define TCP_RTO_INI         3000    /* 3 sec */
#endif
#ifndef TCP_RTO_UBOUND
#define TCP_RTO_UBOUND      64000   /* 64 sec */
#endif
#ifndef TCP_RTO_LBOUND
#define TCP_RTO_LBOUND      300     /* 300 msec */
#endif

/*********************************************************************************/
/* TCP Performance:                                                             */
/*      TCP_DACK_TMO  - Delay ACK timeout   (msec)                              */
/*      TCP_DUP_ACK   - No. of Duplicate ACK (TCP will trigger retransmission   */
/*                      when receive TCP_DUP_ACK duplicate ACK's)               */
/*********************************************************************************/

#ifndef TCP_DACK_TMO
#define TCP_DACK_TMO        200     /* 200 msec */
#endif
#ifndef TCP_DUP_ACK
#define TCP_DUP_ACK         3       /* 3 Duplicate ACK's */
#endif
#endif

/*********************************************************************************/
/* TCP Keep Alive Timer:                                                        */
/*      TCP_KTIME_INI   - Keep Alive Timeout (secs)                             */
/*                        Set this value zero will disable Keep Alive timer     */
/*      TCP_KTIME_SUC   - Timeout of successive Keep Alive probes (secs)        */
/*      TCP_KTIME_PRO   - Total probing timeout (secs)                          */
/*********************************************************************************/

#ifndef INCLUDED_FROM_NONET
#ifndef TCP_KTIME_INI
#define TCP_KTIME_INI       7200    /* 7200 seconds */
#endif
#ifndef TCP_KTIME_PRO
#define TCP_KTIME_PRO       600     /* 600 seconds */
#endif
#ifndef TCP_KTIME_SUC
#define TCP_KTIME_SUC       75      /* 75 seconds */
#endif
#endif

/*********************************************************************************/
/* ARP:                                                                         */
/*      ARP_TABLE_CNT   - ARP table size                                        */
/*      ARP_NIF_CNT     - Number of interfaces that using ARP                   */
/*      ARP_RET_INTVAL  - ARP request retransmission interval timeout (secs)    */
/*      ARP_CACHE_TOUT  - ARP Cache timeout (secs)                              */
/*      ARP_FLUSH_TOUT  - ARP Flush timeout (secs)                              */
/* IP:                                                                          */
/*      IP_DEF_TTL      - Time To Live value for IP packets                     */
/* IP Reassembly:                                                               */
/*      IPF_REASM_TMO   - Timeout for IP reassembly process (secs)              */
/* IGMP:                                                                        */
/*      IGMPV1_PRESENT_TMO - IGMP use version 1 until this timeout expires.     */
/*      ROUTE_TABLE_CNT    - IPv4 Routing Table Entry Count                     */
/* ICMP:                                                                        */
/*      ICMP_DU_RATE       - rate of ICMP destination unreachable reply         */
/*********************************************************************************/

#ifndef INCLUDED_FROM_NONET
#ifndef ARP_TABLE_CNT
#define ARP_TABLE_CNT       8       /* 8 entries */
#endif
#ifndef ARP_NIF_CNT
#define ARP_NIF_CNT         2       /* 2 interfaces */
#endif
#ifndef ARP_CACHE_TOUT
#define ARP_CACHE_TOUT      120     /* 120 sec (2 min) */
#endif
#ifndef ARP_FLUSH_TOUT
#define ARP_FLUSH_TOUT      1200    /* 1200 sec (20 min) */
#endif
#ifndef ARP_RET_INTVAL
#define ARP_RET_INTVAL      2       /* 2 sec */
#endif
#ifndef IP_DEF_TTL
#define IP_DEF_TTL          32      /* 32 hops */
#endif
#ifndef IPF_REASM_TMO
#define IPF_REASM_TMO       2       /* 2 sec */
#endif
#ifndef IGMPV1_PRESENT_TMO
#define IGMPV1_PRESENT_TMO  400     /* 400 sec */
#endif
#ifndef ROUTE_TABLE_CNT
#define ROUTE_TABLE_CNT     2       /* 2 entries */
#endif
#ifndef ICMP_DU_RATE
#define ICMP_DU_RATE        1000    /* 1000 msec */
#endif
#endif

/*********************************************************************************/
/* ND:                                                                          */
/*      NEIGH_CACHE_CNT  - Neighbor Cache size                                  */
/*      PREFIX_LIST_CNT  - Prefix List Count                                    */
/*      DFLT_ROUTER_CNT  - Default Router Count                                 */
/*      DST_CACHE_CNT    - Destination Cache Count                              */
/*      ROUTE6_TABLE_CNT - IPv6 Routing Table Entry Count                       */
/*      DAD_TMO          - Duplicate Address Detection Timeout (msec)           */
/* IP Reassembly:                                                               */
/*      IP6F_REASM_TMO   - Timeout for IPv6 reassembly process (secs)           */
/* IPsec:                                                                       */
/*      MAX_IPSEC_ENTRIES - Maximum entries in IPsec database                   */
/*********************************************************************************/

#ifndef INCLUDED_FROM_NONET
#ifndef NEIGH_CACHE_CNT
#define NEIGH_CACHE_CNT     8
#endif

#ifndef PREFIX_LIST_CNT
#define PREFIX_LIST_CNT     8
#endif

#ifndef DFLT_ROUTER_CNT
#define DFLT_ROUTER_CNT     2
#endif

#ifndef DST_CACHE_CNT
#define DST_CACHE_CNT       8
#endif

#ifndef ROUTE6_TABLE_CNT
#define ROUTE6_TABLE_CNT    2
#endif

#ifndef DAD_TMO
#define DAD_TMO             1000
#endif

#ifndef IP6F_REASM_TMO
#define IP6F_REASM_TMO      60
#endif

#ifndef MAX_IPSEC_ENTRIES
#define MAX_IPSEC_ENTRIES   15
#endif

#ifdef MANUAL_ADDR_CONF
#define ADDR_CONF           1
#else
#define ADDR_CONF           0
#endif

#endif

/* Packets to Refer TCP/IP Configuration Information */

#ifndef INCLUDED_FROM_NONET
const T_TCP_CFG TCP_CFG = {
    TCP_REPID_MAX,
    TCP_CEPID_MAX,
    UDP_CEPID_MAX,
    RAW_CEPID_MAX,
    TCP_TSKID_TOP,
    TCP_SEMID_TOP,
    TCP_MBXID_TOP,
    TCP_MPFID_TOP,
    ARP_TABLE_CNT,
    ARP_NIF_CNT,
    ROUTE_TABLE_CNT,
    TCP_PORT_EPHEMERAL,
    ETH_QCNT,
    TCP_SYN_RETRY,
    TCP_DATA_RETRY,
    TCP_RTO_INI,
    TCP_RTO_UBOUND,
    TCP_RTO_LBOUND,
    TCP_KTIME_INI,
    TCP_KTIME_PRO,
    TCP_KTIME_SUC,
    TCP_DACK_TMO,
    TCP_DUP_ACK,
    ARP_RET_INTVAL,
    IP_DEF_TTL,
    IPF_REASM_TMO,
    NEIGH_CACHE_CNT,
    PREFIX_LIST_CNT,
    DFLT_ROUTER_CNT,
    DST_CACHE_CNT,
    ROUTE6_TABLE_CNT,
    IP6F_REASM_TMO,
    DAD_TMO,
    MULTICAST_GROUP_CNT,
    IGMPV1_PRESENT_TMO,
    MAX_IPSEC_ENTRIES,
    ADDR_CONF,
    MLD2_SRC_CNT,
    IGMP3_SRC_CNT,
    IGMP3_ADR_CNT,
    ARP_CACHE_TOUT,
    ARP_FLUSH_TOUT,
    ICMP_DU_RATE
};
#else
extern const T_TCP_CFG TCP_CFG;
#define TCP_REPID_MAX       (TCP_CFG.tcp_repid_max)
#define TCP_CEPID_MAX       (TCP_CFG.tcp_cepid_max)
#define UDP_CEPID_MAX       (TCP_CFG.udp_cepid_max)
#define RAW_CEPID_MAX       (TCP_CFG.raw_cepid_max)
#define TCP_TSKID_TOP       (TCP_CFG.tcp_tskid_top)
#define TCP_SEMID_TOP       (TCP_CFG.tcp_semid_top)
#define TCP_MBXID_TOP       (TCP_CFG.tcp_mbxid_top)
#define TCP_MPFID_TOP       (TCP_CFG.tcp_mpfid_top)
#define ARP_TABLE_CNT       (TCP_CFG.arp_table_cnt)
#define ARP_NIF_CNT         (TCP_CFG.arp_nif_cnt)
#define ROUTE_TABLE_CNT     (TCP_CFG.route_table_cnt)
#define TCP_PORT_EPHEMERAL  (TCP_CFG.tcp_ephem_port)
#define ETH_QCNT            (TCP_CFG.eth_qcnt)
#define TCP_SYN_RETRY       (TCP_CFG.tcp_syn_ret)
#define TCP_DATA_RETRY      (TCP_CFG.tcp_dat_ret)
#define TCP_RTO_INI         (TCP_CFG.tcp_rto_ini)
#define TCP_RTO_UBOUND      (TCP_CFG.tcp_rto_ubound)
#define TCP_RTO_LBOUND      (TCP_CFG.tcp_rto_lbound)
#define TCP_KTIME_INI       (TCP_CFG.tcp_ktime_ini)
#define TCP_KTIME_PRO       (TCP_CFG.tcp_ktime_pro)
#define TCP_KTIME_SUC       (TCP_CFG.tcp_ktime_suc)
#define TCP_DACK_TMO        (TCP_CFG.tcp_dack_tmo)
#define TCP_DUP_ACK         (TCP_CFG.tcp_dup_ack)
#define ARP_RET_INTVAL      (TCP_CFG.arp_ret_intval)
#define IP_DEF_TTL          (TCP_CFG.ip_def_ttl)
#define IPF_REASM_TMO       (TCP_CFG.ip_reasm_tmo)
#define NEIGH_CACHE_CNT     (TCP_CFG.neigh_cache_cnt)
#define PREFIX_LIST_CNT     (TCP_CFG.prefix_list_cnt)
#define DFLT_ROUTER_CNT     (TCP_CFG.def_rtr_cnt)
#define DST_CACHE_CNT       (TCP_CFG.dst_cache_cnt)
#define ROUTE6_TABLE_CNT    (TCP_CFG.route6_table_cnt)
#define IP6F_REASM_TMO      (TCP_CFG.ip6_reasm_tmo)
#define DAD_TMO             (TCP_CFG.dad_tmo)
#define MULTICAST_GROUP_CNT (TCP_CFG.igmp_group_cnt)
#define IGMPV1_PRESENT_TMO  (TCP_CFG.igmpv1_present_tmo)
#define MAX_IPSEC_ENTRIES   (TCP_CFG.max_ipsec_entries)
#define ADDR_CONF           (TCP_CFG.addr_conf)
#define MLD2_SRC_CNT        (TCP_CFG.mld2_src_cnt)
#define IGMP3_SRC_CNT       (TCP_CFG.igmp3_src_cnt)
#define IGMP3_ADR_CNT       (TCP_CFG.igmp3_adr_cnt)
#define ARP_CACHE_TOUT      (TCP_CFG.arp_cache_tout)
#define ARP_FLUSH_TOUT      (TCP_CFG.arp_flush_tout)
#define ICMP_DU_RATE        (TCP_CFG.icmp_du_rate)
extern UH ID_IP_SND_MBX;
extern UH ID_ETH_MPF;
extern UH ID_IP_TIM;
#ifdef DUAL_STK
extern UH ID_MLDV2_MPF;
#endif
extern UH ID_IGMP3_SRC_MPF;
extern UH ID_IGMP3_ADR_MPF;
#ifdef DUAL_STK
extern UH ID_IPV6_TIM;
extern UH ID_IPV6_CYC;
#endif
#endif

/* Network Interface Information */

#ifdef INCLUDED_FROM_NONET
extern T_NIF default_inet;             /* default network interface control block */
extern const char default_inet_name[]; /* default network interface name */
extern NIF_FP default_inet_func;       /* default network interface function */
#define MULTI_NIF                      /* TCP/IP stack supporting multi network interface */
#else
T_NIF  default_inet;
#ifndef PPP
const char  default_inet_name[] = "eth0";

/* Set Default Value of NIF_NUM/DIF_NUM/ETH_CH */

#if (defined(NIF_NUM) && defined(DIF_NUM) && !defined(ETH_CH))
#define ETH_CH  DIF_NUM
#undef DIF_NUM
#endif

#ifndef NIF_NUM
#if defined(DIF_NUM)
#define NIF_NUM DIF_NUM
#elif defined(ETH_CH)
#define NIF_NUM ETH_CH
#else
#define NIF_NUM 0
#endif
#endif

#ifndef DIF_NUM
#define DIF_NUM NIF_NUM
#endif

#ifndef ETH_CH
#define ETH_CH DIF_NUM
#endif

#if NIF_NUM == 0
extern ER lan_nif_dev(T_NIF *nif,  FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev;
#elif NIF_NUM == 1
extern ER lan_nif_dev1(T_NIF *nif,  FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev1;
#elif NIF_NUM == 2
extern ER lan_nif_dev2(T_NIF *nif,  FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev2;
#elif NIF_NUM == 3
extern ER lan_nif_dev3(T_NIF *nif,  FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev3;
#endif
#else
ER   ppp_nif_dev(T_NIF *nif, FN fncd, ...);
const char  default_inet_name[] = "ppp";
NIF_FP default_inet_func = ppp_nif_dev;
#endif
#endif

/* Definition of p_host_id */

#ifndef INCLUDED_FROM_NONET
#if (ADDR_CONF == 1)
extern UB host_id[6];
const UB * const p_host_id = host_id;
#else
const UB * const p_host_id = NULL;
#endif
#else
extern const UB * const p_host_id;
#endif

/* Packets to Create RTOS Object */

#ifndef INCLUDED_FROM_NONET
const T_CSEM c_tcpip_sem = { TA_TFIFO, 0, 1, "tcpip_sem" };
const T_CMBX c_tcpip_mbx = { TA_TFIFO|TA_MFIFO, 0, NULL, "tcpip_mbx" };
const T_CMPF c_eth_mpf = { TA_TFIFO, ETH_QCNT, sizeof (T_ETH), NULL, "eth_mpf" };
const T_CMPF c_udp_mpf = { TA_TFIFO, UDP_QCNT, sizeof (T_UDP_PKT), NULL, "udp_mpf" };
#ifdef DUAL_STK
#ifdef IPSEC
const T_CMPF c_udp6_mpf = { TA_TFIFO, UDP_QCNT, sizeof (T_ETH), NULL, "udp_mpf" };
#else
const T_CMPF c_udp6_mpf = { TA_TFIFO, UDP_QCNT, sizeof (T_UDP6_PKT), NULL, "udp_mpf" };
#endif
#endif
const T_CTSK c_ip_snd_tsk = { TA_HLNG, NULL, (FP)ip_snd_tsk, PRI_IP_SND_TSK, SSZ_IP_SND_TSK, NULL, "ip_snd_tsk" };
const T_CTSK c_ip_rcv_tsk = { TA_HLNG, NULL, (FP)ip_rcv_tsk, PRI_IP_RCV_TSK, SSZ_IP_RCV_TSK, NULL, "ip_rcv_tsk" };
#ifdef DUAL_STK
const T_CMPF c_mldv2_mpf = { TA_TFIFO, MLD2_SRC_CNT, sizeof (T_MLD2_SRC), NULL, "mldv2_mpf" };
const T_CTSK c_ipv6_cyc_tsk = { TA_HLNG, NULL, (FP)ipv6_cyc_tsk, PRI_IPV6_CYC_TSK, SSZ_IPV6_CYC_TSK, NULL, "ipv6_cyc_tsk" };
#endif
const T_CMBX c_raw_rcv_mbx = { TA_TFIFO|TA_MFIFO, 0, NULL, "raw_rcv_mbx" };
const T_CMPF c_raw_snd_mpf = { TA_TFIFO, RAW_PKT_SND_CNT, sizeof (T_RAW_PKT), NULL, "raw_snd_mpf" };
const T_CMPF c_igmp3_src_mpf = { TA_TFIFO, IGMP3_SRC_CNT, sizeof (T_IGMP3_SRC), NULL, "igmp3_src_mpf" };
const T_CMPF c_igmp3_adr_mpf = { TA_TFIFO, IGMP3_ADR_CNT, sizeof (T_GADDR), NULL, "igmp3_addr_mpf" };
#else
extern const T_CSEM c_tcpip_sem;
extern const T_CMBX c_tcpip_mbx;
extern const T_CMPF c_eth_mpf;
extern const T_CMPF c_udp_mpf;
#ifdef DUAL_STK
extern const T_CMPF c_udp6_mpf;
#endif
extern const T_CTSK c_ip_snd_tsk;
extern const T_CTSK c_ip_rcv_tsk;
#define PRI_TCPIP   c_ip_rcv_tsk.itskpri
#ifdef DUAL_STK
extern const T_CMPF c_mldv2_mpf;
extern const T_CTSK c_ipv6_cyc_tsk;
#endif
extern const T_CMBX c_raw_rcv_mbx;
extern const T_CMPF c_raw_snd_mpf;
extern const T_CMPF c_igmp3_src_mpf;
extern const T_CMPF c_igmp3_adr_mpf;
#endif

/* Internal Data Definition */

#ifndef INCLUDED_FROM_NONET
T_TCP_REP TCP_REP[TCP_REPID_MAX];
T_TCP_CEP TCP_CEP[TCP_CEPID_MAX];
T_UDP_CEP UDP_CEP[UDP_CEPID_MAX];
#if RAW_CEPID_MAX
T_RAW_CEP RAW_CEP_ORG[RAW_CEPID_MAX];
T_RAW_CEP * const RAW_CEP = RAW_CEP_ORG;
#else
T_RAW_CEP * const RAW_CEP = NULL;
#endif
T_TCP_REP *pTCP_REP;
T_TCP_CEP *pTCP_CEP;
T_UDP_CEP *pUDP_CEP;
T_RAW_CEP *pRAW_CEP;
T_ARP_TABLE arp_table[ARP_TABLE_CNT * ARP_NIF_CNT];
T_ROUTE_INFO route_table[ROUTE_TABLE_CNT];
T_MGRP_CB mgrp_cb[MULTICAST_GROUP_CNT];
const T_TCP_REP * const TCP_REP_END = &TCP_REP[TCP_REPID_MAX];
const T_TCP_CEP * const TCP_CEP_END = &TCP_CEP[TCP_CEPID_MAX];
const T_UDP_CEP * const UDP_CEP_END = &UDP_CEP[UDP_CEPID_MAX];
#if RAW_CEPID_MAX
const T_RAW_CEP * const RAW_CEP_END = &RAW_CEP_ORG[RAW_CEPID_MAX];
#else
const T_RAW_CEP * const RAW_CEP_END = NULL;
#endif
UB nif_loop_back;
UH ip_ident;
UW tcp_iss = 0;
UH port_any;
UW ip_timer;
UB ip_miscflag;
UB tcpip_timer_flag;
UB wup_stsk_inuse;
B in_tcp_callback;
T_ICMP_CB *pICMP_CB;
T_IP_CB *pIP_CB;
T_ARP_CB *pARP_CB;
#ifdef DUAL_STK
T_NEIGH_CACHE neigh_cache[NEIGH_CACHE_CNT];
T_PREFIX_LIST prefix_list[PREFIX_LIST_CNT];
T_DFLT_ROUTER deflt_router[DFLT_ROUTER_CNT];
T_DST_CACHE dst_cache[DST_CACHE_CNT];
T_ROUTE6_INFO route6_table[ROUTE6_TABLE_CNT];
T_ICMP6_CB *pICMP6_CB;
#endif
#else
extern T_TCP_REP TCP_REP[];
extern T_TCP_CEP TCP_CEP[];
extern T_UDP_CEP UDP_CEP[];
extern T_RAW_CEP * const RAW_CEP;
extern T_TCP_REP *pTCP_REP;
extern T_TCP_CEP *pTCP_CEP;
extern T_UDP_CEP *pUDP_CEP;
extern T_RAW_CEP *pRAW_CEP;
extern T_ARP_TABLE arp_table[];
extern T_ROUTE_INFO route_table[];
extern T_MGRP_CB mgrp_cb[];
extern const T_TCP_REP * const TCP_REP_END;
extern const T_TCP_CEP * const TCP_CEP_END;
extern const T_UDP_CEP * const UDP_CEP_END;
extern const T_RAW_CEP * const RAW_CEP_END;
extern UB nif_loop_back;
extern UH ip_ident;
extern UW tcp_iss;
extern UH port_any;
extern UW ip_timer;
extern UB ip_miscflag;
extern UB tcpip_timer_flag;
extern UB wup_stsk_inuse;
extern B in_tcp_callback;
extern T_ICMP_CB *pICMP_CB;
extern T_IP_CB *pIP_CB;
extern T_ARP_CB *pARP_CB;
#ifdef DUAL_STK
extern T_NEIGH_CACHE neigh_cache[];
extern T_PREFIX_LIST prefix_list[];
extern T_DFLT_ROUTER deflt_router[];
extern T_DST_CACHE dst_cache[];
extern T_ROUTE6_INFO route6_table[];
extern T_ICMP6_CB *pICMP6_CB;
#endif
#endif

#ifdef __cplusplus
}
#endif
#endif /* NONETC_H */
