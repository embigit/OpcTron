/* This work is licensed under a Creative Commons CCZero 1.0 Universal License.
 * See http://creativecommons.org/publicdomain/zero/1.0/ for more information.
 *
 *    Copyright 2021 (c) TRONKit
 */

#ifdef UA_ARCHITECTURE_ITRON

#ifndef PLUGINS_ARCH_ITRON_UA_ARCHITECTURE_H_
#define PLUGINS_ARCH_ITRON_UA_ARCHITECTURE_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <kernel.h>
#include <nonet.h>
#include <trnsock.h>

#define ssize_t int
#define OPTVAL_TYPE int

#define UA_fd_set(fd, fds)          FD_SET(fd, fds)
#define UA_fd_isset(fd, fds)        FD_ISSET(fd, fds)

#define UA_access(x,y)              0

#define UA_IPV6                     0 // Not supported now
#define UA_SOCKET                   int
#define UA_INVALID_SOCKET           -1
#define UA_ERRNO                    sock_errno()
#define UA_INTERRUPTED              EAI_INTR
#define UA_AGAIN                    EAI_AGAIN
#define UA_EAGAIN                   EAI_AGAIN
#define UA_WOULDBLOCK               E_WOULDBLOCK
#define UA_ERR_CONNECTION_PROGRESS  EAI_INPROGRESS

#define UA_send send
#define UA_recv recv
#define UA_sendto sendto
#define UA_recvfrom recvfrom
#define UA_htonl htonl
#define UA_ntohl ntohl
#define UA_close close
#define UA_select select
#define UA_shutdown shutdown
#define UA_socket socket
#define UA_bind bind
#define UA_listen listen
#define UA_accept accept
#define UA_connect connect
#define UA_getaddrinfo getaddrinfo
#define UA_getsockopt getsockopt
#define UA_setsockopt setsockopt
#define UA_freeaddrinfo freeaddrinfo
#define UA_gethostname gethostname
#define UA_getsockname getsockname
#define UA_inet_pton(af,src,dst) inet_pton(af, src, dst)
#if UA_IPV6
# define UA_if_nametoindex if_nametoindex
#endif

#define UA_free free
#define UA_malloc malloc
#define UA_calloc calloc
#define UA_realloc realloc

#define UA_snprintf snprintf
#define UA_strncasecmp strncasecmp

#define UA_LOG_SOCKET_ERRNO_WRAP(LOG) { \
    char *errno_str = ""; \
    LOG; \
}
#define UA_LOG_SOCKET_ERRNO_GAI_WRAP(LOG) { \
    const char *errno_str = ""; \
    LOG; \
}

#if UA_MULTITHREADING >= 100
#error Multithreading unsupported
#else
#define UA_LOCK_TYPE(mutexName)
#define UA_LOCK_TYPE_POINTER(mutexName)
#define UA_LOCK_INIT(mutexName)
#define UA_LOCK_DESTROY(mutexName)
#define UA_LOCK(mutexName)
#define UA_UNLOCK(mutexName)
#define UA_LOCK_ASSERT(mutexName, num)
#endif

#include <open62541/architecture_functions.h>

#endif /* PLUGINS_ARCH_ITRON_UA_ARCHITECTURE_H_ */

#endif /* UA_ARCHITECTURE_ITRON */
