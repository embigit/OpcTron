/*
 * Interface between iTRON TCP/IP API and Posix style Sockets
 *
 *  Copyright (c) 2021, TRONKit
 *  All rights reserved.
 */

#ifndef TRNSOCK_H
#define TRNSOCK_H
#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdlib.h>

/* Configuration */

#ifndef MAX_SOCK
#define MAX_SOCK             8     /* Maximum supported sockets */
#endif

#ifndef RCV_BUF_SIZE
#define RCV_BUF_SIZE         8192  /* TCP Receive window size */
#endif

#ifndef SND_BUF_SIZE
#define SND_BUF_SIZE         8192  /* TCP Send window size */
#endif

/* Total no of sockets checked through select */
#ifndef MAX_SELECT_INFO
#define MAX_SELECT_INFO      8
#endif

/* Macro definitions */

/* Socket types */
#define SOCK_STREAM          1     /* Stream socket */
#define SOCK_DGRAM           2     /* Datagram socket */

/* Address family */
#define AF_UNSPEC            0     /* Unspecified */
#define AF_INET              2     /* IP Version 4 */
#define AF_INET6             10    /* IP Version 6 */

#define SOL_SOCKET           1     /* Options for socket level */

#define SO_BROADCAST         1     /* Permit to send broadcast messages */
#define SO_RCVBUF            2     /* Receive buffer size */
#define SO_SNDBUF            3     /* Send buffer size */
#define SO_RCVLOWAT          4     /* Receive buffer low water mark */
#define SO_SNDLOWAT          5     /* Send buffer low water mark */
#define SO_RCVTIMEO          6     /* Receive timeout */
#define SO_SNDTIMEO          7     /* Send timeout */
#define SO_TYPE              8     /* Get socket type */
#define SO_ERROR             9     /* Return error code by non-blocking call */
#define SO_REUSEADDR         16    /* Allow binding same port with different local address */
#define SO_REUSEPORT         32    /* Allow binding same multicast address and port */
#define IP_MULTICAST_IF      33    /* Set default interface for outgoing multicasts */
#define IP_MULTICAST_TTL     34    /* Set TTL value for outgoing multicasts */
#define TCP_NODELAY          35    /* Do not merge packets on the socket (disable Nagle's algorithm) */
#define SO_NONBLOCK          64    /* Non-blocking mode */

#define SHUT_RD              0x00  /* Shutdown read side of socket */
#define SHUT_WR              0x01  /* Shutdown write side of socket */
#define SHUT_RDWR            0x02  /* Shutdown both read & write sides */

/* TCP connection status */

#define STAT_CLSD            0x00000000
#define STAT_OPEN            0x00000001
#define STAT_BOUND           0x00000011
#define STAT_LSTN            0x00000111
#define STAT_CONN            0x00001111
#define STAT_SHUT            0x00011111
#define STAT_ERR             0x11111111

/* Error codes */

#define E_SOCKNOTINIT        1001
#define E_AFNOSUPPORT        1002
#define E_SOCKTNOSUPPORT     1003
#define E_PROTONOSUPPORT     1004
#define E_MFILE              1005
#define E_ADDRINUSE          1006
#define E_NOTSOCK            1007
#define E_INVAL              1008
#define E_ADDRNOTAVAIL       1009
#define E_CONNREFUSED        1010
#define E_ISCONN             1011
#define E_OPNOTSUPP          1012
#define E_SHUTDOWN           1013
#define E_NOTCONN            1014
#define E_NOPROTOOPT         1015
#define E_FAULT              1016
#define E_MEMORY             1017
#define E_NETDOWN            1018
#define E_WLDBLK             1019
#define E_CONNABRTD          1020
#define E_CONNRESET          1021
#define E_HOSTUNREACH        1022
#define E_TIMEDOUT           1023
#define E_NOSPC              1024
#define E_ACCESS             1025
#define E_WOULDBLOCK         1026

#define EAI_ADDRFAMILY       1
#define EAI_AGAIN            2
#define EAI_BADFLAGS         3
#define EAI_FAIL             4
#define EAI_FAMILY           5
#define EAI_MEMORY           6
#define EAI_NONAME           7
#define EAI_OVERFLOW         8
#define EAI_SERVICE          9
#define EAI_SOCKTYPE         10
#define EAI_SYSTEM           11
#define EAI_NODATA           12
#define EAI_INTR             13
#define EAI_INPROGRESS       14

/* Flags for getaddrinfo */
#define AI_NUMERICHOST       1
#define AI_CANONNAME         2
#define AI_PASSIVE           4

/* Address lengths in text format */
#define INET_ADDRSTRLEN      16
#define INET6_ADDRSTRLEN     46

#define INADDR_NONE          (-1L)
#define INADDR_ANY           0

/* IOCTL Commands */
#define FIONREAD             0x01
#define FIONBIO              0x02

/* Protocol types */
#define IPPROTO_IP           0
#define IPPROTO_TCP          6
#define IPPROTO_UDP          17

#ifndef fd_set
#define FD_ZERO(fd_set)      it_fdzero(fd_set)
#define FD_SET(fd, fd_set)   it_fdset(fd, fd_set)
#define FD_CLR(fd, fd_set)   it_fdclr(fd, fd_set)
#define FD_ISSET(fd, fd_set) it_fdisset(fd, fd_set)
#endif

#define IN6ADDR_ANY_INIT     {{{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}}
extern const struct in6_addr in6addr_any;

#define IN6ADDR_LOOPBACK_INIT {{{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}}}
extern const struct in6_addr in6addr_loopback;

/* Varibales and data strcuture definitions */

typedef unsigned char        u_char;
typedef unsigned short       in_port_t;

typedef uint32_t             ipaddr_t;
typedef uint32_t             in_addr_t;
typedef u_char               sa_family_t;
typedef uint32_t             socklen_t;

typedef struct {
    UH sockid;              /* socket ID */
    UH cepid;               /* communication end point */
    UH repid;               /* reception end point */
    UH kokki;               /* connection to cepid/repid */
    int type;               /* socket type */
    int state;              /* socket state */
    int af;                 /* socket address family */
    T_IPEP    p_myaddr;     /* local IP Address */
    T_IPEP    p_dstaddr;    /* remote IP address */
    B* snd_buf;             /* send buffer */
    B* rcv_buf;             /* receive buffer */
    int rcv_buf_size;       /* receive window buffer */
    int snd_buf_size;       /* send window buffer */
    TMO rcv_tmout;          /* receive time out */
    TMO snd_tmout;          /* send time out */
    int rcv_lowat;          /* receive low water mark */
    int snd_lowat;          /* send low water mark */
    int options;            /* option flags */
    int conreqs;            /* incoming connection requests */
    int atskid;             /* task ID waiting in accept */
    T_NIF *nif;             /* interface to be used */
} SOCK_INFO;

typedef struct sel_info {
    UH cepid;               /* communication end point ID */
    UH taskid;              /* task ID */
    int type;               /* socket type */
} SEL_INFO;

struct in_addr {
    union {
        struct { uint8_t s_b1, s_b2, s_b3, s_b4; } _S_un_b;
        struct { uint16_t s_w1, s_w2; } _S_un_w;
        uint32_t _S_addr;
    } _S_un;
#define s_addr  _S_un._S_addr
};

struct in6_addr {
    union {
        uint8_t  _S6_u8[16];
        uint32_t _S6_u32[4];
     /* uint64_t _S6_u64[2]; */
    } _S6_un;
#define s6_addr _S6_un._S6_u32
};

struct sockaddr_in {
    uint8_t        sin_len;
    sa_family_t    sin_family;
    in_port_t      sin_port;
    struct in_addr sin_addr;
    char           sin_zero[8];
};

#define SIN6_LEN  /* Must be defined, if length is supported in sockaddr_in6 */

struct sockaddr_in6 {
    uint8_t         sin6_len;      /* Length of this struct */
    sa_family_t     sin6_family;   /* AF_INET6 */
    in_port_t       sin6_port;     /* Transport layer port number */
    uint32_t        sin6_flowinfo; /* IPv6 flow information */
    struct in6_addr sin6_addr;     /* IPv6 address */
    uint32_t        sin6_scope_id; /* Scope zone */
};

struct sockaddr {
    uint8_t     sa_len;            /* Total length */
    sa_family_t sa_family;         /* Address family */
    char        sa_data[14];       /* Actually longer; address value */
};

/*
 *  Desired design of maximum size and alignment.
 */
/* Implementation-defined maximum size. */
#define _SS_MAXSIZE 128
/* Implementation-defined desired alignment. */
#define _SS_ALIGNSIZE (sizeof(int64_t))

/*
 *  Definitions used for sockaddr_storage structure paddings design.
 */
#define _SS_PAD1SIZE (_SS_ALIGNSIZE - sizeof(sa_family_t))
#define _SS_PAD2SIZE (_SS_MAXSIZE - (sizeof(sa_family_t)+ \
                      _SS_PAD1SIZE + _SS_ALIGNSIZE))
struct sockaddr_storage {
    sa_family_t  ss_family;  /* Address family. */
/*
 *  Following fields are implementation-defined.
 */
    char _ss_pad1[_SS_PAD1SIZE];
/* 6-byte pad; this is to make implementation-defined
   pad up to alignment field that follows explicit in
   the data structure. */
    int64_t _ss_align;  /* Field to force desired structure
                           storage alignment. */
    char _ss_pad2[_SS_PAD2SIZE];
/* 112-byte pad to achieve desired size,
   _SS_MAXSIZE value minus size of ss_family
   __ss_pad1, __ss_align fields is 112. */
};

struct addrinfo {
    int     ai_flags;              /* AI_PASSIVE, AI_NUMERICHOST */
    int     ai_family;             /* Address Family */
    int     ai_socktype;           /* Socket Type */
    int     ai_protocol;           /* 0 or Protocol for IPV4 and IPV6 */
    socklen_t  ai_addrlen;         /* Length of ai_addr */
    char   *ai_canonname;          /* Canonical name for nodename */
    struct sockaddr *ai_addr;      /* Binary address */
    struct addrinfo *ai_next;      /* Next structure in linked list */
};

struct hostent {
    char*   h_name;
    char**  h_aliases;
    int     h_addrtype;
    int     h_length;
    char**  h_addr_list;
};

#define h_addr  h_addr_list[0];

#ifndef FD_SETSIZE
#define FD_SETSIZE  256
#endif

#define FD_ARRSIZE  FD_SETSIZE/32

#ifndef fd_set
typedef struct fd_set {
    unsigned int    fd_count;
    B     fd_array[FD_ARRSIZE*4];
} fd_set;
#endif

struct ip_mreq {                   /* Multicast address structure */
    struct in_addr  imr_multiaddr; /* IPv4 multicast address of group */
    struct in_addr  imr_interface; /* IPv4 address of local interface */
};

#ifndef _TIMEVAL_DEFINED
 struct timeval {
    long  tv_sec;
    long  tv_usec;
 };
#endif

/* Function prototype definitions */

int *sock_errno_addr(void);
#define sock_errno() (*sock_errno_addr())
int sock_ini(void);
int socket(int af, int type, int protocol);
int shutdown(int sockfd, int howto);
#define close so_close
int close(int sockfd);
int bind(int sockfd, const struct sockaddr *myaddr, socklen_t addrlen);
int listen(int sockfd, int backlog);
int accept(int sockfd, struct sockaddr *dstaddr, socklen_t *addrlen);
int connect(int sockfd, const struct sockaddr *dstaddr, socklen_t addrlen);
int send(int sockfd, const void *buf, size_t len, int flags);
int recv(int sockfd, void * buf, size_t len, int flags);
int sendto(int sockfd, const void *msg, size_t len, int flags,
    const struct sockaddr *to, socklen_t tolen);
int recvfrom(int sockfd, void *msg, size_t len, int flags,
    struct sockaddr *from, socklen_t *fromlen);
int setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen);
int getsockopt(int sockfd, int level, int optname, void *optval, socklen_t *optlen);
ER  nsl_get_err(void);
in_addr_t inet_addr(const char *strptr);
char *inet_ntoa(struct in_addr inaddr);
int inet_aton(const char *src, struct in_addr *dst);
int inet_pton(int af, const char *src, void *dst);
const char *inet_ntop(int af, const void *src, char *dst, socklen_t size);
struct hostent *gethostbyname(const char *hostname);
int getpeername( int sockfd, struct sockaddr *peeraddr, socklen_t *addrlen);
int getsockname (int sockfd, struct sockaddr *localaddr, socklen_t *addrlen);
int getaddrinfo(const char *nodename, const char *servname, const struct addrinfo *hints, struct addrinfo **res);
int gethostname(char* name, size_t len);
void freeaddrinfo(struct addrinfo *ai);
int select(int maxfdp1, fd_set *readset, fd_set *writeset, fd_set *excepset, struct timeval *timeout);
void it_fdzero(fd_set *fd_set);
void it_fdset(int fd, fd_set *fdset);
void it_fdclr(int fd, fd_set *fdset);
int it_fdisset(int fd, fd_set *fdset);
int ioctl(int sockfd, unsigned long cmd, void *data);
ER wup_sel_tsk(ID cepid, int type);

extern ER dns_resolver(ID, UW, const char*, T_IPEP*);

#ifdef __cplusplus
};
#endif
#endif /* End trnsock.h */
